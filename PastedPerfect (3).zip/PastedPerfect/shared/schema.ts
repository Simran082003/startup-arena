import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email"),
  avatarUrl: text("avatar_url"),
  role: text("role", { enum: ["user", "founder", "investor", "mentor"] }).notNull().default("user"),
  bio: text("bio"),
  title: text("title"),
  company: text("company"),
  mfaEnabled: boolean("mfa_enabled").default(false).notNull(),
  mfaSecret: text("mfa_secret"),
  mfaBackupCodes: text("mfa_backup_codes").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Pitches table
export const pitches = pgTable("pitches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  status: text("status", { enum: ["draft", "active", "archived"] }).notNull().default("draft"),
  imageSrc: text("image_src"),
  videoSrc: text("video_src"),
  tags: text("tags").array(),
  views: integer("views").notNull().default(0),
  upvotes: integer("upvotes").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Comments table
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  pitchId: integer("pitch_id").references(() => pitches.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Upvotes table (to track who upvoted what)
export const upvotes = pgTable("upvotes", {
  id: serial("id").primaryKey(),
  pitchId: integer("pitch_id").references(() => pitches.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Live rooms table
export const liveRooms = pgTable("live_rooms", {
  id: serial("id").primaryKey(),
  pitchId: integer("pitch_id").references(() => pitches.id),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status", { enum: ["scheduled", "live", "ended"] }).notNull().default("scheduled"),
  thumbnailSrc: text("thumbnail_src"),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Live room participants
export const liveRoomParticipants = pgTable("live_room_participants", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").references(() => liveRooms.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  role: text("role", { enum: ["host", "viewer", "speaker"] }).notNull().default("viewer"),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  leftAt: timestamp("left_at"),
});

// Live room messages
export const liveRoomMessages = pgTable("live_room_messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").references(() => liveRooms.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  type: text("type", { enum: ["text", "reaction", "question", "system"] }).notNull().default("text"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Challenges table
export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  prize: text("prize"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status", { enum: ["upcoming", "active", "ended"] }).notNull().default("upcoming"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Challenge participants
export const challengeParticipants = pgTable("challenge_participants", {
  id: serial("id").primaryKey(),
  challengeId: integer("challenge_id").references(() => challenges.id).notNull(),
  pitchId: integer("pitch_id").references(() => pitches.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  submissionDate: timestamp("submission_date").defaultNow().notNull(),
  score: integer("score"),
  rank: integer("rank"),
});

// NFTs table
export const nfts = pgTable("nfts", {
  id: serial("id").primaryKey(),
  pitchId: integer("pitch_id").references(() => pitches.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  tokenId: text("token_id"),
  contractAddress: text("contract_address"),
  blockchain: text("blockchain"),
  metadata: jsonb("metadata"),
  mintedAt: timestamp("minted_at").defaultNow().notNull(),
});

// Connections table (followers, mentoring relationships, etc.)
export const connections = pgTable("connections", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").references(() => users.id).notNull(),
  followingId: integer("following_id").references(() => users.id).notNull(),
  type: text("type", { enum: ["follow", "mentor", "investor"] }).notNull().default("follow"),
  status: text("status", { enum: ["pending", "accepted", "rejected"] }).notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  pitches: many(pitches),
  comments: many(comments),
  upvotes: many(upvotes),
  liveRooms: many(liveRooms),
  liveRoomParticipations: many(liveRoomParticipants),
  followersConnections: many(connections, { relationName: "followers" }),
  followingConnections: many(connections, { relationName: "following" }),
}));

export const pitchesRelations = relations(pitches, ({ one, many }) => ({
  user: one(users, { fields: [pitches.userId], references: [users.id] }),
  comments: many(comments),
  upvotes: many(upvotes),
  liveRooms: many(liveRooms),
  nfts: many(nfts),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  pitch: one(pitches, { fields: [comments.pitchId], references: [pitches.id] }),
  user: one(users, { fields: [comments.userId], references: [users.id] }),
}));

export const upvotesRelations = relations(upvotes, ({ one }) => ({
  pitch: one(pitches, { fields: [upvotes.pitchId], references: [pitches.id] }),
  user: one(users, { fields: [upvotes.userId], references: [users.id] }),
}));

export const liveRoomsRelations = relations(liveRooms, ({ one, many }) => ({
  pitch: one(pitches, { fields: [liveRooms.pitchId], references: [pitches.id] }),
  user: one(users, { fields: [liveRooms.userId], references: [users.id] }),
  participants: many(liveRoomParticipants),
  messages: many(liveRoomMessages),
}));

export const liveRoomParticipantsRelations = relations(liveRoomParticipants, ({ one }) => ({
  liveRoom: one(liveRooms, { fields: [liveRoomParticipants.roomId], references: [liveRooms.id] }),
  user: one(users, { fields: [liveRoomParticipants.userId], references: [users.id] }),
}));

export const liveRoomMessagesRelations = relations(liveRoomMessages, ({ one }) => ({
  liveRoom: one(liveRooms, { fields: [liveRoomMessages.roomId], references: [liveRooms.id] }),
  user: one(users, { fields: [liveRoomMessages.userId], references: [users.id] }),
}));

export const challengesRelations = relations(challenges, ({ many }) => ({
  participants: many(challengeParticipants),
}));

export const challengeParticipantsRelations = relations(challengeParticipants, ({ one }) => ({
  challenge: one(challenges, { fields: [challengeParticipants.challengeId], references: [challenges.id] }),
  pitch: one(pitches, { fields: [challengeParticipants.pitchId], references: [pitches.id] }),
  user: one(users, { fields: [challengeParticipants.userId], references: [users.id] }),
}));

export const nftsRelations = relations(nfts, ({ one }) => ({
  pitch: one(pitches, { fields: [nfts.pitchId], references: [pitches.id] }),
  user: one(users, { fields: [nfts.userId], references: [users.id] }),
}));

export const connectionsRelations = relations(connections, ({ one }) => ({
  follower: one(users, { fields: [connections.followerId], references: [users.id], relationName: "following" }),
  following: one(users, { fields: [connections.followingId], references: [users.id], relationName: "followers" }),
}));

// Zod schemas for validation
export const userInsertSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
  role: (schema) => schema.refine(
    (val) => ["user", "founder", "investor", "mentor"].includes(val),
    "Role must be user, founder, investor, or mentor"
  )
});

export const pitchInsertSchema = createInsertSchema(pitches);
export const commentInsertSchema = createInsertSchema(comments);
export const upvoteInsertSchema = createInsertSchema(upvotes);
export const liveRoomInsertSchema = createInsertSchema(liveRooms);
export const liveRoomParticipantInsertSchema = createInsertSchema(liveRoomParticipants);
export const liveRoomMessageInsertSchema = createInsertSchema(liveRoomMessages);
export const challengeInsertSchema = createInsertSchema(challenges);
export const challengeParticipantInsertSchema = createInsertSchema(challengeParticipants);
export const nftInsertSchema = createInsertSchema(nfts);
export const connectionInsertSchema = createInsertSchema(connections);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof userInsertSchema>;
export type Pitch = typeof pitches.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Upvote = typeof upvotes.$inferSelect;
export type LiveRoom = typeof liveRooms.$inferSelect;
export type LiveRoomParticipant = typeof liveRoomParticipants.$inferSelect;
export type LiveRoomMessage = typeof liveRoomMessages.$inferSelect;
export type Challenge = typeof challenges.$inferSelect;
export type ChallengeParticipant = typeof challengeParticipants.$inferSelect;
export type NFT = typeof nfts.$inferSelect;
export type Connection = typeof connections.$inferSelect;
