import { User, Pitch, Comment, LiveRoom, Challenge, NFT } from "./schema";

// Extended types with relationships for API responses

export interface UserResponse extends Omit<User, "password"> {
  pitchCount?: number;
  followers?: number;
  following?: number;
}

export interface PitchWithUser extends Pitch {
  founder: UserResponse;
  commentCount: number;
}

export interface PitchDetailResponse extends PitchWithUser {
  comments?: CommentWithUser[];
  hasUserUpvoted?: boolean;
  similarPitches?: PitchWithUser[];
}

export interface CommentWithUser extends Comment {
  user: UserResponse;
}

export interface LiveRoomWithDetails extends LiveRoom {
  presenter: UserResponse;
  pitch?: Pitch;
  participants?: number;
  viewerCount?: number;
}

export interface MentorResponse extends UserResponse {
  expertise: string;
  rating: number;
  reviewCount: number;
}

export interface InvestorResponse extends UserResponse {
  firm: string;
  interests: string[];
}

export interface DashboardStats {
  // Common stats
  connectionCount: number;
  newConnections: number;
  upcomingPitchCount: number;
  nextPitchDate?: string;
  
  // Founder-specific stats
  pitchCount?: number;
  activePitches?: number;
  draftPitches?: number;
  totalViews?: number;
  viewsGrowth?: number;
  
  // Investor-specific stats
  investmentCount?: number;
  activeInvestments?: number;
  reviewedPitchCount?: number;
  newPitchesThisWeek?: number;
  
  // Mentor-specific stats
  menteeCount?: number;
  activeMentees?: number;
  sessionCount?: number;
  sessionHours?: number;
  upcomingSessionCount?: number;
  nextSessionDate?: string;
}

export interface DashboardResponse {
  user: UserResponse;
  stats: DashboardStats;
}

export interface ChallengeWithParticipants extends Challenge {
  participantCount: number;
  userIsParticipating?: boolean;
}

export interface ChallengeLeaderboardEntry {
  rank: number;
  pitch: PitchWithUser;
  score: number;
  submissionDate: string;
}

export interface NFTWithDetails extends NFT {
  pitch: Pitch;
  owner: UserResponse;
}

export interface SocketMessage {
  type: string;
  payload: any;
  timestamp: string;
}

export interface LiveRoomSocketMessage extends SocketMessage {
  senderId: number;
  senderName: string;
  senderAvatar?: string;
}

export type ChatMessage = {
  id: number | string;
  userId: number;
  username: string;
  avatarUrl?: string;
  content: string;
  type: 'text' | 'reaction' | 'question' | 'system';
  timestamp: string;
};

export type Reaction = {
  type: string;
  count: number;
  userIds: number[];
};

export type LiveRoomState = {
  id: number;
  title: string;
  status: 'scheduled' | 'live' | 'ended';
  presenterName: string;
  presenterAvatar?: string;
  presenterId: number;
  pitchId?: number;
  attendees: {
    userId: number;
    username: string;
    avatarUrl?: string;
    role: 'host' | 'viewer' | 'speaker';
  }[];
  messages: ChatMessage[];
  reactions: Record<string, Reaction>;
  startTime?: string;
  endTime?: string;
};
