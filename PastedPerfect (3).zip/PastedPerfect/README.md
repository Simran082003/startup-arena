# Startup Arena

A comprehensive startup ecosystem platform that empowers founders to create, refine, and showcase their business ideas while connecting with potential investors and mentors through intelligent matchmaking and feedback mechanisms.

## Core Features

- Interactive startup pitch creation and presentation
- NFT minting for idea protection
- Live pitch rooms with real-time feedback
- AI-powered recommendation systems
- Investor-founder matchmaking
- Mentor connection system
- Comprehensive dashboard with role-specific features

## Technologies Used

- **Frontend**: React.js, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express, WebSockets
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Session-based with Passport.js

## Local Development Setup

Follow these steps to run the project locally:

### Prerequisites

- Node.js (v16+)
- PostgreSQL database
- Git

### Setup Steps

1. **Clone the repository and install dependencies**

```bash
git clone <repository-url>
cd startup-arena
npm install
```

2. **Configure your environment**

Run the setup script to create your local environment:

```bash
node setup-local.js
```

This will create a `.env` file from the template. Edit this file with your database credentials and other configurations.

3. **Database setup**

Make sure your PostgreSQL server is running, then:

```bash
# Run database migrations
npm run db:push

# Seed the database with initial data
npm run db:seed

# To reset the database with fresh data (if needed):
FORCE_SEED=true npm run db:seed
```

4. **Start the development server**

```bash
npm run dev
```

Your application should now be running at `http://localhost:5000`

## Folder Structure

```
├── client/         # Frontend React application
│   ├── src/        # Source files
│   │   ├── components/   # UI components
│   │   ├── pages/        # Application pages
│   │   ├── lib/          # Utility functions
│   │   └── hooks/        # React hooks
├── server/         # Backend Express application
│   ├── routes.ts   # API routes
│   └── auth.ts     # Authentication logic
├── db/             # Database configuration
│   ├── index.ts    # DB connection setup
│   └── seed.ts     # Database seed script
├── shared/         # Shared types and schemas
│   ├── schema.ts   # Drizzle database schema
│   └── types.ts    # TypeScript type definitions
└── public/         # Static assets
    ├── avatars/    # Role-specific avatar SVGs (founder-1/2/3, investor-1/2/3, mentor-1/2/3)
    ├── pitch-thumbnail.svg  # Default pitch thumbnail
    ├── live-pitch.svg       # Live pitch room thumbnail
    ├── nft-placeholder.svg  # NFT image placeholder
    └── ...                  # Other static assets
```

## User Roles

- **Founder**: Create and pitch startup ideas, connect with investors and mentors
- **Investor**: Browse pitches, invest in startups, provide feedback
- **Mentor**: Provide expertise and guidance to founders

## API Routes

The backend API follows RESTful conventions and is structured by resource type:

- `/api/auth/*` - Authentication endpoints
- `/api/users/*` - User management
- `/api/pitches/*` - Pitch creation and management
- `/api/live-rooms/*` - Live pitch room functionality
- `/api/mentors/*` - Mentor-specific endpoints
- `/api/investors/*` - Investor-specific endpoints
- `/api/nfts/*` - NFT minting and management

## WebSocket Integration

Real-time features like live pitch rooms use WebSockets. The WebSocket server is initialized at `/ws` and handles events for:

- Live room joining/leaving
- Chat messaging
- Reactions
- Presenter controls

## Visual Assets

The platform uses custom SVG assets for consistent offline development:

- **User Avatars**: Role-specific avatar variations (founder-1/2/3, investor-1/2/3, mentor-1/2/3)
- **Pitch Thumbnails**: Default thumbnails for pitch cards
- **Live Room Visuals**: Graphics for live pitch rooms
- **NFT Placeholders**: Templates for NFT displays

All visual assets are stored locally as SVGs in the `/public` directory, ensuring consistent display without relying on external image services.

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request