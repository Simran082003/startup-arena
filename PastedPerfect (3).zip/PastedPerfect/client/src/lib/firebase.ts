import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, UserCredential } from "firebase/auth";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

// Firebase configuration - these values come from environment variables
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Google provider setup
const googleProvider = new GoogleAuthProvider();

// Function to sign in with Google using popup
export async function signInWithGoogle(): Promise<UserCredential> {
  try {
    // Set custom parameters to work around domain restrictions
    googleProvider.setCustomParameters({
      prompt: 'select_account'
    });
    
    return await signInWithPopup(auth, googleProvider);
  } catch (error: any) {
    console.error("Google authentication error:", error);
    
    // Add helpful error message for unauthorized domain
    if (error && error.code === 'auth/unauthorized-domain') {
      throw new Error('The Replit domain needs to be added to Firebase authorized domains. Please add your Replit domain to Firebase console > Authentication > Settings > Authorized domains.');
    }
    
    throw error;
  }
}

// Hook to handle Google authentication and server session creation
export function useGoogleAuth() {
  const { toast } = useToast();

  const handleGoogleSignIn = async () => {
    try {
      // Sign in with Google popup
      const result = await signInWithGoogle();
      
      // Get the ID token
      const idToken = await result.user.getIdToken();
      
      // Send the token to the backend to create a session
      const response = await fetch('/api/auth/google', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ idToken }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to authenticate with server');
      }

      // Invalidate auth query to refresh user data
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Successfully signed in",
        description: "You've been signed in with Google.",
      });
      
      return true;
    } catch (error) {
      console.error("Google authentication failed:", error);
      
      toast({
        variant: "destructive",
        title: "Authentication failed",
        description: error instanceof Error ? error.message : "Failed to sign in with Google",
      });
      
      return false;
    }
  };

  return { handleGoogleSignIn };
}

export default auth;