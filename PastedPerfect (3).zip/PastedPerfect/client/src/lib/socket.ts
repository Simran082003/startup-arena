import { useEffect, useState } from 'react';

interface UseWebSocketOptions {
  onMessage?: (data: any) => void;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
  reconnect?: boolean;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export function connectWebSocket(path = '/ws'): WebSocket {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}${path}`;
  return new WebSocket(wsUrl);
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('connecting');
  const {
    onMessage,
    onOpen,
    onClose,
    onError,
    reconnect = true,
    reconnectInterval = 3000,
    maxReconnectAttempts = 5
  } = options;

  useEffect(() => {
    console.log('Connecting to WebSocket...');
    const newSocket = connectWebSocket();
    setConnectionStatus('connecting');

    newSocket.onopen = () => {
      console.log('WebSocket connected successfully');
      setIsConnected(true);
      setConnectionStatus('connected');
      setReconnectAttempts(0);
      if (onOpen) onOpen();
    };

    newSocket.onmessage = (event) => {
      if (onMessage) {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message received:', data.type);
          onMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
          onMessage(event.data);
        }
      }
    };

    newSocket.onclose = (event) => {
      console.log('WebSocket closed, code:', event.code, 'reason:', event.reason);
      setIsConnected(false);
      setConnectionStatus('disconnected');
      if (onClose) onClose();
      
      if (reconnect && reconnectAttempts < maxReconnectAttempts) {
        console.log(`Attempting to reconnect (${reconnectAttempts + 1}/${maxReconnectAttempts})...`);
        setTimeout(() => {
          setReconnectAttempts(prev => prev + 1);
          setSocket(connectWebSocket());
        }, reconnectInterval);
      } else if (reconnectAttempts >= maxReconnectAttempts) {
        console.log('Max reconnect attempts reached, giving up');
      }
    };

    newSocket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setConnectionStatus('error');
      if (onError) onError(error);
    };

    setSocket(newSocket);

    return () => {
      console.log('Cleaning up WebSocket connection');
      newSocket.close();
    };
  }, [reconnectAttempts]);

  const sendMessage = (data: any) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(typeof data === 'string' ? data : JSON.stringify(data));
      return true;
    }
    return false;
  };

  return {
    socket,
    isConnected,
    connectionStatus,
    sendMessage
  };
}

export function formatSocketMessage(type: string, payload: any) {
  return JSON.stringify({
    type,
    payload,
    timestamp: new Date().toISOString()
  });
}
