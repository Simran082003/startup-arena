import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { 
  Alert, 
  AlertDescription, 
  AlertTitle 
} from "@/components/ui/alert";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { ShieldCheck, ShieldAlert, QrCode, Copy, ClipboardCheck } from "lucide-react";
import MobileNav from "@/components/common/mobile-nav";

// OTP verification schema
const otpSchema = z.object({
  token: z.string().min(6, "OTP code must be at least 6 digits").max(8)
});

type OtpFormValues = z.infer<typeof otpSchema>;

export default function SecuritySettings() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [tabValue, setTabValue] = useState("2fa");
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [setupState, setSetupState] = useState<"idle" | "setup" | "verify">("idle");
  const [setupData, setSetupData] = useState<any>(null);
  const [showBackupCodes, setShowBackupCodes] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isDisabling, setIsDisabling] = useState(false);

  // Check if user is authenticated and get MFA status
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['/api/auth/me'],
  });

  const { data: mfaStatusData, isLoading: mfaLoading } = useQuery({
    queryKey: ['/api/auth/mfa/status'],
    enabled: !!userData
  });
  
  // Update MFA status when data changes
  useEffect(() => {
    if (mfaStatusData && typeof mfaStatusData === 'object' && mfaStatusData !== null) {
      const data = mfaStatusData as { mfaEnabled?: boolean };
      if (typeof data.mfaEnabled === 'boolean') {
        setMfaEnabled(data.mfaEnabled);
      }
    }
  }, [mfaStatusData]);

  // Set document title
  useEffect(() => {
    document.title = "Security Settings | Startup Arena";
  }, []);

  // Redirect if not logged in
  useEffect(() => {
    if (!userLoading && !userData) {
      navigate("/auth/login");
      toast({
        variant: "destructive",
        title: "Not authenticated",
        description: "Please log in to view security settings.",
      });
    }
  }, [userLoading, userData, navigate, toast]);

  // Setup OTP form
  const otpForm = useForm<OtpFormValues>({
    resolver: zodResolver(otpSchema),
    defaultValues: {
      token: ""
    }
  });

  // Disable OTP form
  const disableForm = useForm<OtpFormValues>({
    resolver: zodResolver(otpSchema),
    defaultValues: {
      token: ""
    }
  });

  // Start the MFA setup process
  const startMfaSetup = async () => {
    try {
      const response = await apiRequest("POST", "/api/auth/mfa/setup");
      const data = await response.json();
      
      setSetupData(data);
      setSetupState("setup");
    } catch (error) {
      console.error("Error setting up MFA:", error);
      toast({
        variant: "destructive",
        title: "Setup failed",
        description: "There was a problem setting up MFA. Please try again."
      });
    }
  };

  // Verify OTP and enable MFA
  const verifyAndEnableMfa = async (values: OtpFormValues) => {
    try {
      const response = await apiRequest("POST", "/api/auth/mfa/verify", values);
      
      // Successfully enabled MFA
      setMfaEnabled(true);
      setSetupState("idle");
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/auth/mfa/status'] });
      
      toast({
        title: "MFA Enabled",
        description: "Two-factor authentication has been successfully enabled for your account."
      });
    } catch (error) {
      console.error("Error verifying MFA token:", error);
      toast({
        variant: "destructive",
        title: "Verification failed",
        description: "Invalid OTP code. Please try again."
      });
    }
  };

  // Disable MFA
  const disableMfa = async (values: OtpFormValues) => {
    try {
      await apiRequest("POST", "/api/auth/mfa/disable", values);
      
      // Successfully disabled MFA
      setMfaEnabled(false);
      setIsDisabling(false);
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/auth/mfa/status'] });
      
      toast({
        title: "MFA Disabled",
        description: "Two-factor authentication has been disabled for your account."
      });
      
      disableForm.reset();
    } catch (error) {
      console.error("Error disabling MFA:", error);
      toast({
        variant: "destructive",
        title: "Verification failed",
        description: "Invalid OTP code. Please try again."
      });
    }
  };

  // Copy backup codes to clipboard
  const copyBackupCodes = () => {
    if (setupData && setupData.backupCodes) {
      const codesText = setupData.backupCodes.join('\n');
      navigator.clipboard.writeText(codesText).then(() => {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      });
    }
  };

  // Show loading state
  if (userLoading || mfaLoading) {
    return (
      <div className="flex-1 p-6 lg:ml-64 pt-20">
        <div className="text-center py-16">
          <p className="text-slate-500">Loading security settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Security Settings</h1>
          <p className="text-slate-500 mt-1">
            Manage your account security and two-factor authentication
          </p>
        </div>

        <Tabs defaultValue="2fa" value={tabValue} onValueChange={setTabValue} className="max-w-3xl">
          <TabsList>
            <TabsTrigger value="2fa">Two-Factor Authentication</TabsTrigger>
            <TabsTrigger value="password">Password</TabsTrigger>
            <TabsTrigger value="sessions">Active Sessions</TabsTrigger>
          </TabsList>
          
          <TabsContent value="2fa" className="mt-6">
            {mfaEnabled ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                      <ShieldCheck className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <CardTitle>Two-Factor Authentication is Enabled</CardTitle>
                      <CardDescription>
                        Your account is secured with two-factor authentication
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-6">
                    With two-factor authentication, you'll need both your password and an authentication code from your phone to sign in. This adds an extra layer of security to your account.
                  </p>
                  
                  <Alert className="mb-6 bg-slate-50">
                    <ShieldCheck className="h-4 w-4" />
                    <AlertTitle>Your account is secure</AlertTitle>
                    <AlertDescription>
                      You're using an authenticator app to secure your account. Each time you sign in, you'll need to provide a code from the app.
                    </AlertDescription>
                  </Alert>
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline" 
                    className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                    onClick={() => setIsDisabling(true)}
                  >
                    Disable Two-Factor Authentication
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center">
                      <ShieldAlert className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <CardTitle>Two-Factor Authentication is Disabled</CardTitle>
                      <CardDescription>
                        Add an extra layer of security to your account
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-6">
                    Two-factor authentication adds an extra layer of security to your account by requiring both your password and a code from your phone when you sign in.
                  </p>
                  
                  <Alert className="mb-6 bg-amber-50 border-amber-200">
                    <ShieldAlert className="h-4 w-4 text-amber-600" />
                    <AlertTitle>Recommended Security Setting</AlertTitle>
                    <AlertDescription>
                      We strongly recommend enabling two-factor authentication to protect your account from unauthorized access.
                    </AlertDescription>
                  </Alert>
                  
                  <div className="bg-slate-50 p-5 rounded-lg">
                    <h3 className="font-medium text-lg mb-2">How it works</h3>
                    <ol className="list-decimal list-inside space-y-2 text-sm text-slate-600">
                      <li>Set up two-factor authentication using an authenticator app like Google Authenticator, Authy, or Microsoft Authenticator.</li>
                      <li>Each time you log in, you'll enter your password and a temporary code from your authenticator app.</li>
                      <li>Even if someone knows your password, they can't access your account without the code from your app.</li>
                    </ol>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={startMfaSetup}>
                    Enable Two-Factor Authentication
                  </Button>
                </CardFooter>
              </Card>
            )}
            
            {/* MFA Setup Process */}
            {setupState === "setup" && setupData && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Set Up Two-Factor Authentication</CardTitle>
                  <CardDescription>
                    Follow these steps to enable two-factor authentication
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-2">1. Scan the QR Code</h3>
                    <p className="text-sm text-slate-600 mb-4">
                      Scan this QR code with your authenticator app (like Google Authenticator, Authy, or Microsoft Authenticator).
                    </p>
                    
                    <div className="flex flex-col md:flex-row gap-6 items-center">
                      <div className="w-48 h-48 bg-white p-2 border rounded-lg">
                        <img 
                          src={setupData.qrCodeDataUrl} 
                          alt="QR Code for MFA setup" 
                          className="w-full h-full"
                        />
                      </div>
                      
                      <div className="flex-1">
                        <p className="text-sm text-slate-600 mb-2">
                          If you can't scan the QR code, enter this code manually:
                        </p>
                        <div className="font-mono bg-slate-100 p-3 rounded-md text-sm break-all">
                          {setupData.secret}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">2. Save Your Backup Codes</h3>
                    <p className="text-sm text-slate-600 mb-4">
                      Save these backup codes in a secure place. You can use them to log in if you lose access to your authenticator app.
                    </p>
                    
                    <Button 
                      variant="outline" 
                      className="mb-4"
                      onClick={() => setShowBackupCodes(!showBackupCodes)}
                    >
                      {showBackupCodes ? "Hide Backup Codes" : "Show Backup Codes"}
                    </Button>
                    
                    {showBackupCodes && (
                      <div className="relative">
                        <div className="font-mono bg-slate-100 p-3 rounded-md text-sm grid grid-cols-2 gap-2">
                          {setupData.backupCodes.map((code: string, index: number) => (
                            <div key={index}>{code}</div>
                          ))}
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="absolute top-2 right-2 h-8 gap-1"
                          onClick={copyBackupCodes}
                        >
                          {isCopied ? (
                            <>
                              <ClipboardCheck className="h-4 w-4" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-4 w-4" />
                              <span>Copy</span>
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">3. Verify Your Setup</h3>
                    <p className="text-sm text-slate-600 mb-4">
                      Enter the verification code from your authenticator app to complete the setup.
                    </p>
                    
                    <Form {...otpForm}>
                      <form onSubmit={otpForm.handleSubmit(verifyAndEnableMfa)} className="space-y-4">
                        <FormField
                          control={otpForm.control}
                          name="token"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Verification Code</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter 6-digit code" 
                                  className="max-w-xs font-mono text-center text-lg tracking-wider"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex items-center space-x-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              setSetupState("idle");
                              setSetupData(null);
                            }}
                          >
                            Cancel
                          </Button>
                          <Button type="submit">
                            Verify and Enable
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="password" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Password Settings</CardTitle>
                <CardDescription>
                  Manage your account password
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  This section will allow you to change your password. Feature coming soon.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="sessions" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Active Sessions</CardTitle>
                <CardDescription>
                  Manage all devices and browsers where you're logged in
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  This section will show all your active sessions and allow you to log out remotely. Feature coming soon.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <MobileNav />
      
      {/* Disable MFA Confirmation Dialog */}
      <Dialog open={isDisabling} onOpenChange={setIsDisabling}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Disable Two-Factor Authentication</DialogTitle>
            <DialogDescription>
              Disabling two-factor authentication will make your account less secure.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...disableForm}>
            <form onSubmit={disableForm.handleSubmit(disableMfa)} className="space-y-4">
              <FormField
                control={disableForm.control}
                name="token"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Code</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter 6-digit code" 
                        className="font-mono text-center text-lg tracking-wider"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                    <p className="text-xs text-slate-500 mt-1">
                      Enter the verification code from your authenticator app to confirm.
                    </p>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDisabling(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  variant="destructive"
                >
                  Disable Two-Factor Authentication
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}