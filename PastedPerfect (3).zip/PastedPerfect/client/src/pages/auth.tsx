import { useState, useEffect } from "react";
import { Link, useLocation, useParams, useRoute } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { GoogleSignInButton } from "@/components/ui/google-signin-button";
import { MfaVerifyForm } from "@/components/ui/mfa-verify-form";

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function Auth() {
  const [, navigate] = useLocation();
  const params = useParams();
  const action = params?.action || "login";
  const { toast } = useToast();
  
  const isLogin = action === "login";
  const isRegister = action === "register";
  
  // MFA verification state
  const [showMfaVerification, setShowMfaVerification] = useState(false);
  
  // Set document title
  useEffect(() => {
    document.title = isLogin ? "Log In | Startup Arena" : "Sign Up | Startup Arena";
  }, [isLogin]);

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
    },
  });

  // Handle login submission
  const onLoginSubmit = async (data: LoginFormValues) => {
    try {
      const response = await apiRequest("POST", "/api/auth/login", data);
      const responseData = await response.json();
      
      // Check if MFA verification is required
      if (responseData && responseData.requireMfa) {
        // Show MFA verification form
        setShowMfaVerification(true);
        
        toast({
          title: "Verification required",
          description: "Please enter the verification code from your authenticator app.",
        });
        return;
      }
      
      // If MFA is not required, proceed with login
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Welcome back!",
        description: "You have successfully logged in.",
      });
      
      // Redirect to dashboard
      navigate("/dashboard");
    } catch (error) {
      console.error("Login error:", error);
      toast({
        variant: "destructive",
        title: "Login failed",
        description: "Invalid username or password. Please try again.",
      });
    }
  };

  // Handle register submission
  const onRegisterSubmit = async (data: RegisterFormValues) => {
    // Remove confirmPassword before sending to API
    const { confirmPassword, ...registerData } = data;
    
    try {
      // Register the user
      await apiRequest("POST", "/api/auth/register", registerData);
      
      toast({
        title: "Registration successful!",
        description: "Your account has been created.",
      });
      
      // Now log them in automatically
      try {
        await apiRequest("POST", "/api/auth/login", {
          username: registerData.username,
          password: registerData.password
        });
        
        // Invalidate the query to refresh user data
        queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
        
        // After successful login, redirect to profile setup
        navigate("/profile-setup");
      } catch (loginError) {
        // If auto-login fails, redirect to login page
        navigate("/auth/login");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: "This username may already be taken. Please try another one.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <Link href="/" className="flex items-center justify-center space-x-2 mb-6">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary-500 to-secondary-600 flex items-center justify-center">
            <i className="ri-rocket-2-fill text-white text-xl"></i>
          </div>
          <span className="text-xl font-bold text-slate-800">Startup Arena</span>
        </Link>
        
        <h1 className="text-3xl font-bold text-slate-800">
          {isLogin ? "Log in to your account" : "Create an account"}
        </h1>
        <p className="mt-2 text-slate-600">
          {isLogin 
            ? "Enter your credentials to access your account" 
            : "Join the community of founders, investors, and mentors"
          }
        </p>
      </div>
      
      <Card className="w-full max-w-md">
        {isLogin && showMfaVerification && (
          <MfaVerifyForm 
            onCancel={() => setShowMfaVerification(false)}
            onSuccess={() => {
              setShowMfaVerification(false);
              navigate("/dashboard");
            }}
          />
        )}
        
        {isLogin && !showMfaVerification && (
          <Form {...loginForm}>
            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)}>
              <CardContent className="space-y-6 pt-6">
                <FormField
                  control={loginForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Enter your password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex items-center justify-between">
                  <Button variant="link" className="px-0 text-sm" asChild>
                    <Link href="/auth/reset-password">Forgot password?</Link>
                  </Button>
                </div>
              </CardContent>
              
              <CardFooter className="flex-col space-y-4">
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loginForm.formState.isSubmitting}
                >
                  {loginForm.formState.isSubmitting ? "Logging in..." : "Log in"}
                </Button>
                
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-slate-200"></span>
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="px-2 bg-white text-slate-500">Or continue with</span>
                  </div>
                </div>
                
                <GoogleSignInButton />
                
                <p className="text-sm text-center text-slate-600">
                  Don't have an account?{" "}
                  <Link href="/auth/register" className="font-medium text-primary-600 hover:text-primary-500">
                    Sign up
                  </Link>
                </p>
              </CardFooter>
            </form>
          </Form>
        )}
        
        {isRegister && (
          <Form {...registerForm}>
            <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)}>
              <CardContent className="space-y-6 pt-6">
                <FormField
                  control={registerForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="Choose a username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Create a password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Confirm your password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                

              </CardContent>
              
              <CardFooter className="flex-col space-y-4">
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={registerForm.formState.isSubmitting}
                >
                  {registerForm.formState.isSubmitting ? "Creating account..." : "Create account"}
                </Button>
                
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-slate-200"></span>
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="px-2 bg-white text-slate-500">Or continue with</span>
                  </div>
                </div>
                
                <GoogleSignInButton />
                
                <p className="text-sm text-center text-slate-600">
                  Already have an account?{" "}
                  <Link href="/auth/login" className="font-medium text-primary-600 hover:text-primary-500">
                    Log in
                  </Link>
                </p>
              </CardFooter>
            </form>
          </Form>
        )}
      </Card>
      
      <p className="mt-8 text-xs text-center text-slate-500">
        By creating an account, you agree to our{" "}
        <a href="#" className="underline hover:text-slate-700">Terms of Service</a>{" "}
        and{" "}
        <a href="#" className="underline hover:text-slate-700">Privacy Policy</a>.
      </p>
    </div>
  );
}
