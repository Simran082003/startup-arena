import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import MobileNav from "@/components/common/mobile-nav";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";

export default function Challenges() {
  const { toast } = useToast();
  const [selectedChallenge, setSelectedChallenge] = useState<any>(null);
  const [selectedPitchId, setSelectedPitchId] = useState<string>("");
  const [isJoining, setIsJoining] = useState(false);

  // Fetch challenges
  const { data: challenges, isLoading: loadingChallenges } = useQuery({
    queryKey: ['/api/challenges'],
  });

  // Fetch user's pitches for joining a challenge
  const { data: userPitches, isLoading: loadingPitches } = useQuery({
    queryKey: ['/api/pitches/user'],
  });

  // Handle joining a challenge
  const handleJoinChallenge = async () => {
    if (!selectedChallenge || !selectedPitchId) {
      toast({
        title: "Error",
        description: "Please select a pitch to join the challenge",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsJoining(true);
      
      await apiRequest("POST", `/api/challenges/${selectedChallenge.id}/join`, {
        pitchId: parseInt(selectedPitchId)
      });
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/challenges'] });
      
      toast({
        title: "Success!",
        description: "You have successfully joined the challenge",
      });
      
      // Reset state
      setSelectedPitchId("");
      setSelectedChallenge(null);
    } catch (error) {
      console.error("Error joining challenge:", error);
      toast({
        title: "Error",
        description: "There was an error joining the challenge. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsJoining(false);
    }
  };

  // Filter challenges by status
  const activeChallenges = challenges?.filter((challenge: any) => challenge.status === "active") || [];
  const upcomingChallenges = challenges?.filter((challenge: any) => challenge.status === "upcoming") || [];
  const endedChallenges = challenges?.filter((challenge: any) => challenge.status === "ended") || [];

  // Set document title
  useEffect(() => {
    document.title = "Challenges | Startup Arena";
  }, []);

  const getChallengeStatusClass = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 hover:bg-green-200";
      case "upcoming":
        return "bg-blue-100 text-blue-800 hover:bg-blue-200";
      case "ended":
        return "bg-gray-100 text-gray-800 hover:bg-gray-200";
      default:
        return "bg-slate-100 text-slate-800 hover:bg-slate-200";
    }
  };

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Startup Challenges</h1>
          <p className="text-slate-500 mt-1">Participate in themed challenges to showcase your startup and win prizes</p>
        </div>
        
        {/* Featured challenge */}
        {activeChallenges.length > 0 && (
          <div className="bg-gradient-to-r from-primary-600 to-secondary-600 rounded-xl p-8 text-white mb-10">
            <div className="max-w-3xl">
              <Badge className="bg-white/20 text-white hover:bg-white/30 mb-2">
                FEATURED CHALLENGE
              </Badge>
              <h2 className="text-2xl font-bold mb-3">{activeChallenges[0].title}</h2>
              <p className="text-white/90 mb-6">
                {activeChallenges[0].description}
              </p>
              <div className="flex flex-wrap gap-4 mb-6">
                <div>
                  <p className="text-white/70 text-sm">Prize</p>
                  <p className="font-bold">{activeChallenges[0].prize}</p>
                </div>
                <div>
                  <p className="text-white/70 text-sm">End Date</p>
                  <p className="font-bold">{formatDate(new Date(activeChallenges[0].endDate))}</p>
                </div>
                <div>
                  <p className="text-white/70 text-sm">Participants</p>
                  <p className="font-bold">{activeChallenges[0].participantCount}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      className="bg-white text-primary-600 hover:bg-white/90"
                      onClick={() => setSelectedChallenge(activeChallenges[0])}
                      disabled={activeChallenges[0].userIsParticipating}
                    >
                      {activeChallenges[0].userIsParticipating ? "Already Participating" : "Join Challenge"}
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Join Challenge: {selectedChallenge?.title}</DialogTitle>
                      <DialogDescription>
                        Select one of your pitches to submit to this challenge
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="py-4">
                      <p className="text-sm font-medium mb-2">Select your pitch:</p>
                      <Select value={selectedPitchId} onValueChange={setSelectedPitchId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a pitch" />
                        </SelectTrigger>
                        <SelectContent>
                          {loadingPitches ? (
                            <SelectItem value="loading">Loading pitches...</SelectItem>
                          ) : userPitches?.length > 0 ? (
                            userPitches
                              .filter((pitch: any) => pitch.status === "active")
                              .map((pitch: any) => (
                                <SelectItem key={pitch.id} value={pitch.id.toString()}>
                                  {pitch.title}
                                </SelectItem>
                              ))
                          ) : (
                            <SelectItem value="none">No active pitches found</SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      
                      <p className="text-xs text-slate-500 mt-2">
                        Only published pitches can be submitted to challenges
                      </p>
                    </div>
                    
                    <DialogFooter>
                      <Button variant="outline" onClick={() => {
                        setSelectedChallenge(null);
                        setSelectedPitchId("");
                      }}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleJoinChallenge} 
                        disabled={isJoining || !selectedPitchId || selectedPitchId === "loading" || selectedPitchId === "none"}
                      >
                        {isJoining ? "Joining..." : "Join Challenge"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/10" asChild>
                  <Link href={`/challenges/${activeChallenges[0].id}`}>
                    View Details
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Active challenges */}
        <h2 className="text-xl font-bold text-slate-800 mb-4">Active Challenges</h2>
        {loadingChallenges ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading challenges...</p>
          </div>
        ) : activeChallenges.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
            {activeChallenges.map((challenge: any, index: number) => (
              <Card key={challenge.id} className={index === 0 ? "hidden lg:block" : ""}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start mb-3">
                    <Badge className={getChallengeStatusClass(challenge.status)}>
                      {challenge.status === "active" ? "Active" : challenge.status === "upcoming" ? "Upcoming" : "Ended"}
                    </Badge>
                    <div className="text-sm text-slate-500">
                      {challenge.participantCount} participants
                    </div>
                  </div>
                  
                  <h3 className="font-bold text-lg text-slate-800 mb-2">{challenge.title}</h3>
                  <p className="text-slate-600 text-sm mb-4">
                    {challenge.description.length > 120 
                      ? `${challenge.description.substring(0, 120)}...` 
                      : challenge.description
                    }
                  </p>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                    <div>
                      <p className="text-slate-500">Prize</p>
                      <p className="font-medium text-slate-800">{challenge.prize}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">End Date</p>
                      <p className="font-medium text-slate-800">{formatDate(new Date(challenge.endDate))}</p>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="border-t pt-4 flex justify-between">
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/challenges/${challenge.id}`}>
                      View Details
                    </Link>
                  </Button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        size="sm"
                        onClick={() => setSelectedChallenge(challenge)}
                        disabled={challenge.userIsParticipating}
                      >
                        {challenge.userIsParticipating ? "Participating" : "Join Now"}
                      </Button>
                    </DialogTrigger>
                    {/* Dialog content same as above */}
                  </Dialog>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="mb-10">
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No active challenges at the moment. Check back soon!</p>
            </CardContent>
          </Card>
        )}
        
        {/* Upcoming challenges */}
        <h2 className="text-xl font-bold text-slate-800 mb-4">Upcoming Challenges</h2>
        {loadingChallenges ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading challenges...</p>
          </div>
        ) : upcomingChallenges.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
            {upcomingChallenges.map((challenge: any) => (
              <Card key={challenge.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start mb-3">
                    <Badge className={getChallengeStatusClass(challenge.status)}>
                      Upcoming
                    </Badge>
                    <div className="text-sm text-slate-500">
                      Starts {formatDate(new Date(challenge.startDate))}
                    </div>
                  </div>
                  
                  <h3 className="font-bold text-lg text-slate-800 mb-2">{challenge.title}</h3>
                  <p className="text-slate-600 text-sm mb-4">
                    {challenge.description.length > 120 
                      ? `${challenge.description.substring(0, 120)}...` 
                      : challenge.description
                    }
                  </p>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                    <div>
                      <p className="text-slate-500">Prize</p>
                      <p className="font-medium text-slate-800">{challenge.prize}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Duration</p>
                      <p className="font-medium text-slate-800">
                        {Math.ceil((new Date(challenge.endDate).getTime() - new Date(challenge.startDate).getTime()) / (1000 * 60 * 60 * 24))} days
                      </p>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="border-t pt-4 flex justify-end">
                  <Button variant="outline" size="sm">
                    Get Notified
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="mb-10">
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No upcoming challenges scheduled yet.</p>
            </CardContent>
          </Card>
        )}
        
        {/* Past challenges */}
        <h2 className="text-xl font-bold text-slate-800 mb-4">Past Challenges</h2>
        {loadingChallenges ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading challenges...</p>
          </div>
        ) : endedChallenges.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {endedChallenges.map((challenge: any) => (
              <Card key={challenge.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start mb-3">
                    <Badge className={getChallengeStatusClass(challenge.status)}>
                      Completed
                    </Badge>
                    <div className="text-sm text-slate-500">
                      {challenge.participantCount} participants
                    </div>
                  </div>
                  
                  <h3 className="font-bold text-lg text-slate-800 mb-2">{challenge.title}</h3>
                  <p className="text-slate-600 text-sm mb-4">
                    {challenge.description.length > 120 
                      ? `${challenge.description.substring(0, 120)}...` 
                      : challenge.description
                    }
                  </p>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                    <div>
                      <p className="text-slate-500">Prize</p>
                      <p className="font-medium text-slate-800">{challenge.prize}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Ended On</p>
                      <p className="font-medium text-slate-800">{formatDate(new Date(challenge.endDate))}</p>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="border-t pt-4 flex justify-end">
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/challenges/${challenge.id}`}>
                      View Results
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No past challenges found.</p>
            </CardContent>
          </Card>
        )}
        
        {/* Challenge benefits */}
        <div className="mt-12 bg-gradient-to-r from-slate-50 to-slate-100 border border-slate-200 rounded-lg p-8">
          <h2 className="text-xl font-bold text-slate-800 mb-6 text-center">Benefits of Participating in Challenges</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <div className="w-12 h-12 rounded-lg bg-primary-100 flex items-center justify-center mb-4">
                <i className="ri-trophy-line text-xl text-primary-600"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Win Prizes</h3>
              <p className="text-slate-600 text-sm">
                Earn funding, credits, and recognition for your startup.
              </p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <div className="w-12 h-12 rounded-lg bg-secondary-100 flex items-center justify-center mb-4">
                <i className="ri-user-voice-line text-xl text-secondary-600"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Gain Visibility</h3>
              <p className="text-slate-600 text-sm">
                Get noticed by investors, partners, and potential customers.
              </p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-4">
                <i className="ri-feedback-line text-xl text-green-600"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Valuable Feedback</h3>
              <p className="text-slate-600 text-sm">
                Receive expert feedback to refine your product and pitch.
              </p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <div className="w-12 h-12 rounded-lg bg-accent-100 flex items-center justify-center mb-4">
                <i className="ri-group-line text-xl text-accent-500"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Network Growth</h3>
              <p className="text-slate-600 text-sm">
                Connect with other founders and industry leaders.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}
