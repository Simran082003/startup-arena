import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { formatDate } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MobileNav from "@/components/common/mobile-nav";

export default function MyPitches() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [pitchToDelete, setPitchToDelete] = useState<number | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Fetch user's pitches
  const { data: userPitches, isLoading, error } = useQuery({
    queryKey: ['/api/pitches/user'],
  });

  // Delete a pitch
  const handleDeletePitch = async () => {
    if (!pitchToDelete) return;
    
    try {
      setIsDeleting(true);
      await apiRequest("DELETE", `/api/pitches/${pitchToDelete}`, {});
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/pitches/user'] });
      
      toast({
        title: "Pitch deleted",
        description: "Your pitch has been deleted successfully.",
      });
      
      setPitchToDelete(null);
    } catch (error) {
      console.error("Error deleting pitch:", error);
      toast({
        title: "Error",
        description: "There was an error deleting your pitch. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  // Set document title
  useEffect(() => {
    document.title = "My Pitches | Startup Arena";
  }, []);

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">My Pitches</h1>
            <p className="text-slate-500 mt-1">Manage and track all your startup pitches</p>
          </div>
          
          <Button asChild>
            <Link href="/pitch/new">
              <i className="ri-add-line mr-1"></i> New Pitch
            </Link>
          </Button>
        </div>
        
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading your pitches...</p>
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-red-500">Error loading pitches. Please try again.</p>
              <Button variant="outline" className="mt-4" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/pitches/user'] })}>
                Retry
              </Button>
            </CardContent>
          </Card>
        ) : userPitches && userPitches.length > 0 ? (
          <div className="space-y-6">
            {userPitches.map((pitch: any) => (
              <div key={pitch.id} className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-lg text-slate-800">{pitch.title}</h3>
                    <Badge className={pitch.status === 'active' ? 'bg-green-100 text-green-800 hover:bg-green-200' : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'}>
                      {pitch.status === 'active' ? 'Active' : 'Draft'}
                    </Badge>
                  </div>
                  
                  <p className="text-slate-600 mb-4">
                    {pitch.description.length > 200 
                      ? `${pitch.description.substring(0, 200)}...` 
                      : pitch.description
                    }
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Created</p>
                      <p className="text-sm font-medium text-slate-700">{formatDate(new Date(pitch.createdAt))}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Status</p>
                      <p className="text-sm font-medium text-slate-700">{pitch.status === 'active' ? 'Published' : 'Draft'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Views</p>
                      <p className="text-sm font-medium text-slate-700">{pitch.views || 0}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Engagement</p>
                      <p className="text-sm font-medium text-slate-700">{pitch.upvotes || 0} upvotes, {pitch.comments || 0} comments</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-2 mb-6">
                    {pitch.tags && pitch.tags.map((tag: string, index: number) => (
                      <Badge key={index} variant="secondary" className="bg-slate-100 text-slate-800 hover:bg-slate-200">
                        {tag}
                      </Badge>
                    ))}
                    {(!pitch.tags || pitch.tags.length === 0) && (
                      <span className="text-xs text-slate-500">No tags</span>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/pitch/edit/${pitch.id}`}>
                          Edit Pitch
                        </Link>
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                            onClick={() => setPitchToDelete(pitch.id)}
                          >
                            Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. This will permanently delete your pitch
                              and remove it from our servers.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setPitchToDelete(null)}>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={handleDeletePitch}
                              className="bg-red-600 hover:bg-red-700"
                              disabled={isDeleting}
                            >
                              {isDeleting ? "Deleting..." : "Delete"}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                      
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/pitch/${pitch.id}`}>
                          View Details
                        </Link>
                      </Button>
                    </div>
                    
                    <div className="flex space-x-2">
                      {pitch.status === 'draft' && (
                        <Button 
                          size="sm"
                          onClick={async () => {
                            try {
                              await apiRequest("PUT", `/api/pitches/${pitch.id}`, { status: "active" });
                              queryClient.invalidateQueries({ queryKey: ['/api/pitches/user'] });
                              toast({
                                title: "Pitch published",
                                description: "Your pitch is now live and visible to others.",
                              });
                            } catch (error) {
                              toast({
                                title: "Error",
                                description: "There was an error publishing your pitch.",
                                variant: "destructive",
                              });
                            }
                          }}
                        >
                          Publish
                        </Button>
                      )}
                      
                      <Button size="sm" asChild>
                        <Link href={`/live-rooms/schedule?pitchId=${pitch.id}`}>
                          Schedule Live Pitch
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-16 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-lightbulb-line text-2xl text-slate-400"></i>
              </div>
              <h3 className="text-lg font-medium text-slate-800 mb-2">No pitches yet</h3>
              <p className="text-slate-500 mb-6">You haven't created any pitches yet. Start by creating your first pitch!</p>
              <Button asChild>
                <Link href="/pitch/new">Create Your First Pitch</Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
      
      <MobileNav />
    </div>
  );
}
