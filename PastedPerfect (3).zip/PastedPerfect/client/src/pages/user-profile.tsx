import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getInitials } from "@/lib/utils";

interface UserProfile {
  id: number;
  username: string;
  name: string;
  role: string;
  title?: string;
  avatarUrl?: string;
  bio?: string;
  company?: string;
  expertiseAreas?: string[];
  pitches?: any[];
  connections?: any[];
}

export default function UserProfile() {
  const { username } = useParams();
  const [activeTab, setActiveTab] = useState("about");

  // Fetch user profile data
  const { data: user, isLoading, error } = useQuery<UserProfile>({
    queryKey: [`/api/users/${username}`],
    queryFn: async () => {
      const response = await fetch(`/api/users/${username}`);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("User not found");
        }
        throw new Error("Failed to fetch user profile");
      }
      return response.json();
    }
  });

  // Get role badge styling
  const getRoleBadge = (role: string) => {
    switch (role) {
      case "founder":
        return "bg-emerald-100 text-emerald-800";
      case "investor":
        return "bg-blue-100 text-blue-800";
      case "mentor":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-1 items-center justify-center pt-16">
        <p className="text-slate-500">Loading user profile...</p>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="flex flex-1 items-center justify-center pt-16">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-2">User Not Found</h2>
          <p className="text-slate-500 mb-4">The user @{username} could not be found.</p>
          <Button asChild>
            <Link href="/dashboard">Return to Dashboard</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 container max-w-6xl py-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Profile Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg border border-slate-200 p-6 text-center">
              <Avatar className="h-24 w-24 mx-auto mb-4">
                <AvatarImage src={user.avatarUrl} alt={user.name} />
                <AvatarFallback className="bg-primary-100 text-primary-700 text-2xl">
                  {getInitials(user.name)}
                </AvatarFallback>
              </Avatar>
              
              <h1 className="text-xl font-bold text-slate-900">{user.name}</h1>
              <p className="text-slate-500">@{user.username}</p>
              
              <Badge className={`mt-2 ${getRoleBadge(user.role)}`}>
                {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
              </Badge>
              
              {user.title && (
                <p className="mt-2 text-sm text-slate-700">{user.title}</p>
              )}
              
              {user.company && (
                <p className="text-sm text-slate-500">{user.company}</p>
              )}
              
              <div className="mt-4 space-y-2">
                <Button className="w-full">Connect</Button>
                <Button variant="outline" className="w-full">Message</Button>
              </div>
            </div>
            
            {/* Expertise / Interests */}
            {user.expertiseAreas && user.expertiseAreas.length > 0 && (
              <div className="bg-white rounded-lg border border-slate-200 p-6">
                <h2 className="font-semibold text-slate-800 mb-3">
                  {user.role === "investor" ? "Investment Interests" : "Expertise"}
                </h2>
                <div className="flex flex-wrap gap-2">
                  {user.expertiseAreas.map((area) => (
                    <Badge key={area} variant="secondary">
                      {area}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            {/* Connections */}
            <div className="bg-white rounded-lg border border-slate-200 p-6">
              <h2 className="font-semibold text-slate-800 mb-3">Connections</h2>
              <div className="text-center py-4">
                <p className="text-slate-500 text-sm">
                  Connect with {user.name} to see their network
                </p>
              </div>
            </div>
          </div>
          
          {/* Main Content Area */}
          <div className="md:col-span-2 space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full flex justify-start bg-white border-b rounded-none p-0">
                <TabsTrigger 
                  value="about" 
                  className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600"
                >
                  About
                </TabsTrigger>
                <TabsTrigger 
                  value="pitches" 
                  className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600"
                >
                  Pitches
                </TabsTrigger>
                <TabsTrigger 
                  value="activity" 
                  className="flex-1 rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600"
                >
                  Activity
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="about" className="mt-6">
                <div className="bg-white rounded-lg border border-slate-200 p-6">
                  <h2 className="text-xl font-semibold text-slate-800 mb-4">About</h2>
                  {user.bio ? (
                    <p className="text-slate-700 whitespace-pre-line">{user.bio}</p>
                  ) : (
                    <p className="text-slate-500 italic">
                      {user.name} hasn't added a bio yet.
                    </p>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="pitches" className="mt-6">
                <div className="bg-white rounded-lg border border-slate-200 p-6">
                  <h2 className="text-xl font-semibold text-slate-800 mb-4">Pitches</h2>
                  {user.pitches && user.pitches.length > 0 ? (
                    <div className="space-y-4">
                      {user.pitches.map((pitch) => (
                        <div key={pitch.id} className="border rounded-lg p-4">
                          <h3 className="font-semibold text-lg">{pitch.title}</h3>
                          <p className="text-slate-600 text-sm">{pitch.description}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 italic">
                      {user.role === "founder" 
                        ? `${user.name} hasn't shared any pitches yet.`
                        : `${user.name} hasn't invested in any pitches yet.`
                      }
                    </p>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="activity" className="mt-6">
                <div className="bg-white rounded-lg border border-slate-200 p-6">
                  <h2 className="text-xl font-semibold text-slate-800 mb-4">Recent Activity</h2>
                  <div className="text-center py-6">
                    <p className="text-slate-500">
                      Connect with {user.name} to see their recent activity
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
}