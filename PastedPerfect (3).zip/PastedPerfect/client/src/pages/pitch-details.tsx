import { useState, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { getInitials, formatDate } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MobileNav from "@/components/common/mobile-nav";

export default function PitchDetails() {
  const { id } = useParams();
  const { toast } = useToast();
  const [comment, setComment] = useState("");
  
  // Fetch pitch details
  const { data: pitch, isLoading, error } = useQuery({
    queryKey: [`/api/pitch/${id}`],
  });
  
  // Upvote mutation
  const upvoteMutation = useMutation({
    mutationFn: () => apiRequest('POST', `/api/pitch/${id}/upvote`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pitch/${id}`] });
      toast({
        title: "Success",
        description: "You've upvoted this pitch!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to upvote. You may have already upvoted this pitch.",
        variant: "destructive",
      });
    },
  });
  
  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: (comment: string) => apiRequest('POST', `/api/pitch/${id}/comment`, { content: comment }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pitch/${id}`] });
      setComment("");
      toast({
        title: "Comment Posted",
        description: "Your comment has been added successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to post comment. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  // Handle comment submission
  const handleCommentSubmit = () => {
    if (!comment.trim()) {
      toast({
        title: "Error",
        description: "Comment cannot be empty",
        variant: "destructive",
      });
      return;
    }
    
    commentMutation.mutate(comment);
  };
  
  // Set document title
  useEffect(() => {
    if (pitch) {
      document.title = `${pitch.title} | Startup Arena`;
    } else {
      document.title = "Pitch Details | Startup Arena";
    }
  }, [pitch]);
  
  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading pitch details...</p>
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-red-500">Error loading pitch. Please try again.</p>
              <Button variant="outline" className="mt-4">
                Go Back
              </Button>
            </CardContent>
          </Card>
        ) : pitch ? (
          <div className="max-w-4xl mx-auto">
            {/* Pitch Header */}
            <div className="mb-8">
              <div className="flex flex-col md:flex-row justify-between md:items-center mb-4">
                <div className="mb-4 md:mb-0">
                  <Badge className="bg-primary-100 text-primary-800 mb-2">{pitch.category}</Badge>
                  <h1 className="text-3xl font-bold text-slate-800">{pitch.title}</h1>
                </div>
                
                <div className="flex space-x-3">
                  <Button variant="outline" asChild>
                    <Link href={`/live-room/${pitch.id}`}>
                      Join Live Room
                    </Link>
                  </Button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>Book a Meeting</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Schedule a Meeting</DialogTitle>
                        <DialogDescription>
                          Book a one-on-one meeting with the founder to learn more about this pitch.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="py-4">
                        <div className="text-center mb-4">
                          <p className="text-sm text-slate-500">Available meeting slots will be displayed here</p>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2 mb-4">
                          {[1, 2, 3, 4, 5, 6].map((slot) => (
                            <Button 
                              key={slot} 
                              variant="outline" 
                              className="text-xs h-auto py-2"
                            >
                              {new Date(Date.now() + slot * 24 * 60 * 60 * 1000).toLocaleDateString()} 
                              <br />
                              10:00 AM
                            </Button>
                          ))}
                        </div>
                      </div>
                      
                      <DialogFooter>
                        <Button variant="outline">Cancel</Button>
                        <Button>Confirm Booking</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
              
              {/* Founder Info */}
              <div className="flex items-center space-x-3 mb-6">
                <Avatar>
                  <AvatarImage src={pitch.founder.avatarUrl} alt={pitch.founder.name} />
                  <AvatarFallback className="bg-primary-100 text-primary-700">
                    {getInitials(pitch.founder.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-slate-800">{pitch.founder.name}</p>
                  <p className="text-sm text-slate-500">{pitch.founder.title || "Founder"}</p>
                </div>
                <div className="ml-auto flex items-center space-x-4 text-sm text-slate-500">
                  <span className="flex items-center space-x-1">
                    <i className="ri-eye-line"></i>
                    <span>{pitch.views || 0} views</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>{formatDate(pitch.createdAt)}</span>
                  </span>
                </div>
              </div>
              
              {/* Pitch Media */}
              {pitch.imageSrc && (
                <div className="mb-8 rounded-lg overflow-hidden">
                  <img 
                    src={pitch.imageSrc} 
                    alt={pitch.title} 
                    className="w-full h-auto" 
                  />
                </div>
              )}
              
              {/* Pitch Content */}
              <div className="prose prose-slate max-w-none mb-8">
                <p className="text-lg text-slate-700 mb-6">{pitch.description}</p>
                
                {pitch.content && (
                  <div dangerouslySetInnerHTML={{ __html: pitch.content }} />
                )}
              </div>
              
              {/* Tags */}
              {pitch.tags && pitch.tags.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-lg font-bold text-slate-800 mb-3">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {pitch.tags.map((tag: string, index: number) => (
                      <Badge 
                        key={index} 
                        variant="outline" 
                        className="bg-slate-50"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Pitch Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <Card>
                  <CardContent className="p-4 flex flex-col items-center justify-center">
                    <div className="text-4xl font-bold text-primary-600 mb-1">
                      {pitch.phase || "Seed"}
                    </div>
                    <p className="text-sm text-slate-500">Current Phase</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 flex flex-col items-center justify-center">
                    <div className="text-4xl font-bold text-secondary-600 mb-1">
                      ${pitch.fundingGoal?.toLocaleString() || "N/A"}
                    </div>
                    <p className="text-sm text-slate-500">Funding Goal</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 flex flex-col items-center justify-center">
                    <div className="text-4xl font-bold text-accent-500 mb-1">
                      {pitch.targetMarket || "Global"}
                    </div>
                    <p className="text-sm text-slate-500">Target Market</p>
                  </CardContent>
                </Card>
              </div>
              
              {/* Interactions */}
              <div className="flex justify-between items-center border-t border-b border-slate-200 py-4 mb-8">
                <div className="flex space-x-6">
                  <button 
                    className={`flex items-center space-x-2 ${pitch.hasUserUpvoted ? 'text-primary-600 font-medium' : 'text-slate-600 hover:text-primary-600'}`}
                    onClick={() => upvoteMutation.mutate()}
                    disabled={upvoteMutation.isPending || pitch.hasUserUpvoted}
                  >
                    <i className={`${pitch.hasUserUpvoted ? 'ri-thumb-up-fill' : 'ri-thumb-up-line'}`}></i>
                    <span>{pitch.upvotes} Upvotes</span>
                  </button>
                  
                  <button 
                    className="flex items-center space-x-2 text-slate-600 hover:text-secondary-600"
                    onClick={() => document.getElementById('comments-section')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    <i className="ri-message-2-line"></i>
                    <span>{pitch.comments?.length || 0} Comments</span>
                  </button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <button className="flex items-center space-x-2 text-slate-600 hover:text-accent-500">
                        <i className="ri-share-line"></i>
                        <span>Share</span>
                      </button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Share this pitch</DialogTitle>
                        <DialogDescription>
                          Share this pitch with your network
                        </DialogDescription>
                      </DialogHeader>
                      <div className="flex items-center space-x-2 mt-4">
                        <div className="grid flex-1 gap-2">
                          <div className="flex items-center border rounded-md p-2 bg-slate-50">
                            <span className="text-sm text-slate-600 truncate flex-1">
                              {window.location.href}
                            </span>
                          </div>
                        </div>
                        <Button>Copy</Button>
                      </div>
                      <div className="flex justify-center space-x-4 mt-4">
                        <Button variant="outline" className="w-10 h-10 p-0 rounded-full">
                          <i className="ri-twitter-fill text-blue-500"></i>
                        </Button>
                        <Button variant="outline" className="w-10 h-10 p-0 rounded-full">
                          <i className="ri-linkedin-fill text-blue-700"></i>
                        </Button>
                        <Button variant="outline" className="w-10 h-10 p-0 rounded-full">
                          <i className="ri-facebook-fill text-blue-600"></i>
                        </Button>
                        <Button variant="outline" className="w-10 h-10 p-0 rounded-full">
                          <i className="ri-mail-fill text-slate-600"></i>
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                
                {pitch.isNft ? (
                  <Badge className="bg-secondary-100 text-secondary-800">
                    <i className="ri-nft-line mr-1"></i> NFT Protected
                  </Badge>
                ) : (
                  <Button variant="outline" size="sm">
                    <i className="ri-nft-line mr-1"></i> Mint as NFT
                  </Button>
                )}
              </div>
            </div>
            
            {/* Comments Section */}
            <div id="comments-section" className="mb-8">
              <h2 className="text-xl font-bold text-slate-800 mb-6">Discussion ({pitch.comments?.length || 0})</h2>
              
              {/* Comment Form */}
              <div className="mb-8">
                <Textarea
                  placeholder="Share your thoughts, feedback, or questions..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="mb-3"
                  rows={4}
                />
                <div className="flex justify-end">
                  <Button 
                    onClick={handleCommentSubmit}
                    disabled={commentMutation.isPending || !comment.trim()}
                  >
                    {commentMutation.isPending ? "Posting..." : "Post Comment"}
                  </Button>
                </div>
              </div>
              
              {/* Comments List */}
              {pitch.comments && pitch.comments.length > 0 ? (
                <div className="space-y-6">
                  {pitch.comments.map((comment: any) => (
                    <div key={comment.id} className="bg-white rounded-lg border border-slate-200 p-4">
                      <div className="flex items-start space-x-3 mb-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={comment.user.avatarUrl} alt={comment.user.name} />
                          <AvatarFallback className="bg-secondary-100 text-secondary-700 text-xs">
                            {getInitials(comment.user.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <p className="font-medium text-slate-800">{comment.user.name}</p>
                            <p className="text-xs text-slate-500">{formatDate(comment.createdAt)}</p>
                          </div>
                          <p className="text-xs text-slate-500">{comment.user.title || "Member"}</p>
                        </div>
                      </div>
                      <p className="text-slate-700">{comment.content}</p>
                      <div className="mt-3 flex items-center space-x-4 text-xs text-slate-500">
                        <button className="hover:text-primary-600">
                          <i className="ri-thumb-up-line mr-1"></i> Like
                        </button>
                        <button className="hover:text-primary-600">
                          <i className="ri-reply-line mr-1"></i> Reply
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-slate-50 rounded-lg border border-slate-200">
                  <p className="text-slate-500">Be the first to comment on this pitch!</p>
                </div>
              )}
            </div>
            
            {/* Similar Pitches */}
            {pitch.similarPitches && pitch.similarPitches.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-bold text-slate-800 mb-6">Similar Pitches</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pitch.similarPitches.map((similarPitch: any) => (
                    <Card key={similarPitch.id}>
                      <CardContent className="p-4">
                        <Badge className="mb-2">{similarPitch.category}</Badge>
                        <h3 className="font-bold text-slate-800 mb-2">{similarPitch.title}</h3>
                        <p className="text-sm text-slate-600 mb-4 line-clamp-2">{similarPitch.description}</p>
                        <div className="flex items-center space-x-2 mb-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={similarPitch.founder.avatarUrl} alt={similarPitch.founder.name} />
                            <AvatarFallback className="bg-primary-100 text-primary-700 text-xs">
                              {getInitials(similarPitch.founder.name)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-slate-500">{similarPitch.founder.name}</span>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0">
                        <Button variant="outline" className="w-full" size="sm" asChild>
                          <Link href={`/pitch/${similarPitch.id}`}>
                            View Pitch
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-slate-500">Pitch not found</p>
            <Button variant="outline" className="mt-4" asChild>
              <Link href="/dashboard">
                Go to Dashboard
              </Link>
            </Button>
          </div>
        )}
      </main>
      
      <MobileNav />
    </div>
  );
}