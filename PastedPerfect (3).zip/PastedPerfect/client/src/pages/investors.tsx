import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import InvestorCard from "@/components/ui/investor-card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import MobileNav from "@/components/common/mobile-nav";

export default function Investors() {
  const [searchQuery, setSearchQuery] = useState("");
  const [interestFilter, setInterestFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");

  // Fetch investors
  const { data: investors, isLoading, error } = useQuery({
    queryKey: ['/api/investors'],
  });

  // Filter and sort investors
  const filteredInvestors = investors ? investors.filter((investor: any) => {
    // Search filter
    const matchesSearch = searchQuery === "" || 
      investor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      investor.firm.toLowerCase().includes(searchQuery.toLowerCase()) ||
      investor.bio.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Interest filter
    const matchesInterest = interestFilter === "all" || 
      investor.interests.some((interest: string) => 
        interest.toLowerCase() === interestFilter.toLowerCase()
      );
    
    return matchesSearch && matchesInterest;
  }) : [];

  // Sort investors
  const sortedInvestors = [...filteredInvestors].sort((a: any, b: any) => {
    if (sortBy === "name") {
      return a.name.localeCompare(b.name);
    } else if (sortBy === "firm") {
      return a.firm.localeCompare(b.firm);
    } else if (sortBy === "title") {
      return a.title.localeCompare(b.title);
    }
    return 0;
  });

  // Extract all unique interests for filter options
  const allInterests = investors 
    ? Array.from(new Set(investors.flatMap((investor: any) => investor.interests)))
    : [];

  // Set document title
  useEffect(() => {
    document.title = "Investors | Startup Arena";
  }, []);

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Investors</h1>
          <p className="text-slate-500 mt-1">Connect with investors looking for promising startups to fund</p>
        </div>
        
        {/* Filters and search */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="search" className="block text-sm font-medium text-slate-700 mb-1">
                Search
              </label>
              <Input
                id="search"
                placeholder="Search by name or firm..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div>
              <label htmlFor="interest" className="block text-sm font-medium text-slate-700 mb-1">
                Investment Interest
              </label>
              <Select
                value={interestFilter}
                onValueChange={setInterestFilter}
              >
                <SelectTrigger id="interest">
                  <SelectValue placeholder="Filter by interest" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Interests</SelectItem>
                  {allInterests.map((interest: string) => (
                    <SelectItem key={interest} value={interest}>{interest}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label htmlFor="sort" className="block text-sm font-medium text-slate-700 mb-1">
                Sort By
              </label>
              <Select
                value={sortBy}
                onValueChange={setSortBy}
              >
                <SelectTrigger id="sort">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name (A-Z)</SelectItem>
                  <SelectItem value="firm">Firm (A-Z)</SelectItem>
                  <SelectItem value="title">Investment Stage</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Current funding opportunities */}
        <div className="bg-gradient-to-r from-secondary-50 to-secondary-100 border border-secondary-200 rounded-lg p-6 mb-8">
          <h2 className="text-lg font-bold text-slate-800 mb-3">Active Funding Opportunities</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 border border-secondary-200">
              <Badge className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200">Seed Round</Badge>
              <h3 className="font-bold mt-2 mb-1">Tech Innovators Fund</h3>
              <p className="text-sm text-slate-600 mb-2">Investing $50K-$250K in early-stage SaaS startups</p>
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="text-xs">SaaS</Badge>
                <Badge variant="outline" className="text-xs">AI</Badge>
                <Badge variant="outline" className="text-xs">B2B</Badge>
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-secondary-200">
              <Badge className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200">Series A</Badge>
              <h3 className="font-bold mt-2 mb-1">Green Future Ventures</h3>
              <p className="text-sm text-slate-600 mb-2">$1M-$3M for sustainability and climate tech startups</p>
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="text-xs">Climate Tech</Badge>
                <Badge variant="outline" className="text-xs">Sustainability</Badge>
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-secondary-200">
              <Badge className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200">Angel Round</Badge>
              <h3 className="font-bold mt-2 mb-1">Health Innovators Alliance</h3>
              <p className="text-sm text-slate-600 mb-2">$25K-$100K for early-stage healthcare solutions</p>
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="text-xs">HealthTech</Badge>
                <Badge variant="outline" className="text-xs">MedTech</Badge>
              </div>
            </div>
          </div>
        </div>
        
        {/* Investors grid */}
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading investors...</p>
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-red-500">Error loading investors. Please try again.</p>
              <Button variant="outline" className="mt-4">
                Retry
              </Button>
            </CardContent>
          </Card>
        ) : sortedInvestors.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sortedInvestors.map((investor: any) => (
              <InvestorCard
                key={investor.id}
                id={investor.id}
                name={investor.name}
                avatarSrc={investor.avatarUrl}
                title={investor.title}
                firm={investor.firm}
                bio={investor.bio}
                interests={investor.interests}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No investors found matching your filters.</p>
              <Button variant="outline" className="mt-4" onClick={() => {
                setSearchQuery("");
                setInterestFilter("all");
              }}>
                Clear Filters
              </Button>
            </CardContent>
          </Card>
        )}
        
        {/* Investor pitch guide */}
        <div className="mt-12">
          <h2 className="text-xl font-bold text-slate-800 mb-6">How to Pitch to Investors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-primary-100 text-primary-600 font-bold mb-4">
                1
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Perfect Your Pitch</h3>
              <p className="text-slate-600">
                Create a concise, compelling pitch that clearly explains your problem, solution, and business model.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-primary-100 text-primary-600 font-bold mb-4">
                2
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Research Investors</h3>
              <p className="text-slate-600">
                Target investors who focus on your industry and stage. Personalize your approach for each investor.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-primary-100 text-primary-600 font-bold mb-4">
                3
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Prepare for Questions</h3>
              <p className="text-slate-600">
                Be ready to address tough questions about your market, competition, and financial projections.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-primary-100 text-primary-600 font-bold mb-4">
                4
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Follow Up</h3>
              <p className="text-slate-600">
                Send a thank-you note after your meeting and provide any additional information requested.
              </p>
            </div>
          </div>
        </div>
        
        {/* Join as investor CTA */}
        <div className="mt-12 bg-gradient-to-r from-secondary-600 to-primary-600 rounded-xl p-8 text-white">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold mb-4">Are You an Investor?</h2>
            <p className="text-white/90 mb-6">
              Join Startup Arena to discover promising startups across various industries and stages. Get early access to innovative founders and their ideas.
            </p>
            <Button variant="secondary" className="bg-white text-secondary-600 hover:bg-white/90">
              Join as an Investor
            </Button>
          </div>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}
