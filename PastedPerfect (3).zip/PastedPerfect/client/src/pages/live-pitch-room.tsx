import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { getInitials, formatTime } from "@/lib/utils";
import { useWebSocket, formatSocketMessage } from "@/lib/socket";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import MobileNav from "@/components/common/mobile-nav";

type Message = {
  id: string;
  senderId: number;
  senderName: string;
  senderAvatar?: string;
  content: string;
  type: 'text' | 'reaction' | 'question' | 'system';
  timestamp: string;
};

export default function LivePitchRoom() {
  const { id } = useParams();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [activeTab, setActiveTab] = useState("chat");
  const [reaction, setReaction] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [participants, setParticipants] = useState<any[]>([]);
  const [roomState, setRoomState] = useState<'scheduled' | 'live' | 'ended'>('scheduled');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Define the LiveRoom type
  type LiveRoom = {
    id: number;
    title: string;
    description?: string;
    status: 'scheduled' | 'live' | 'ended';
    startTime?: string;
    endTime?: string;
    pitchId?: number;
    presenter?: {
      id: number;
      username: string;
      name: string;
      avatarUrl?: string;
      title?: string;
    };
    participants?: any[];
    messages?: any[];
  };

  // Fetch live room details
  const { data: liveRoom = {} as LiveRoom, isLoading, error } = useQuery<LiveRoom>({
    queryKey: [`/api/live-room/${id}`],
  });
  
  // Initialize WebSocket connection
  const { sendMessage, connectionStatus } = useWebSocket({
    onOpen: () => {
      toast({
        title: "Connected to room",
        description: "You are now connected to the live pitch room",
      });
      
      // Authenticate and join room once connected
      if (id) {
        // Get current user from query cache
        type CurrentUser = {
          id: number;
          username: string;
          name?: string;
          email?: string;
          avatarUrl?: string;
          role: string;
        };
        
        const currentUser = queryClient.getQueryData<CurrentUser>(['/api/auth/me']);
        if (currentUser && currentUser.id) {
          sendMessage(formatSocketMessage('auth', { userId: currentUser.id, username: currentUser.username }));
          sendMessage(formatSocketMessage('join_room', { roomId: parseInt(id) }));
        }
      }
    },
    onClose: () => {
      toast({
        title: "Disconnected from room",
        description: "Connection to the live pitch room was lost",
        variant: "destructive",
      });
    },
    onError: () => {
      toast({
        title: "Connection error",
        description: "There was an error connecting to the live room",
        variant: "destructive",
      });
    },
    onMessage: (data) => {
      try {
        const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
        
        if (parsedData.type === 'message') {
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            senderId: parsedData.senderId,
            senderName: parsedData.senderName,
            senderAvatar: parsedData.senderAvatar,
            content: parsedData.payload.content,
            type: parsedData.payload.type || 'text',
            timestamp: parsedData.timestamp
          }]);
        } else if (parsedData.type === 'user_joined') {
          setParticipants(prev => [...prev, {
            id: parsedData.payload.userId,
            name: parsedData.payload.username,
            avatar: parsedData.payload.avatarUrl,
            role: parsedData.payload.role || 'viewer'
          }]);
          
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            senderId: 0,
            senderName: 'System',
            content: `${parsedData.payload.username} joined the room`,
            type: 'system',
            timestamp: parsedData.timestamp
          }]);
        } else if (parsedData.type === 'user_left') {
          setParticipants(prev => prev.filter(p => p.id !== parsedData.payload.userId));
          
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            senderId: 0,
            senderName: 'System',
            content: `${parsedData.payload.username} left the room`,
            type: 'system',
            timestamp: parsedData.timestamp
          }]);
        } else if (parsedData.type === 'room_state_change') {
          setRoomState(parsedData.payload.status);
          
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            senderId: 0,
            senderName: 'System',
            content: `Room is now ${parsedData.payload.status}`,
            type: 'system',
            timestamp: parsedData.timestamp
          }]);
        }
      } catch (e) {
        console.error('Error parsing websocket message:', e);
      }
    },
  });
  
  // Send a message to the room
  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    sendMessage(formatSocketMessage('message', {
      roomId: id,
      content: message,
      type: 'text'
    }));
    
    setMessage("");
  };
  
  // Send a reaction
  const handleSendReaction = (emoji: string) => {
    sendMessage(formatSocketMessage('reaction', {
      roomId: id,
      content: emoji,
      type: 'reaction'
    }));
    
    setReaction(emoji);
    
    // Clear reaction after 2 seconds
    setTimeout(() => setReaction(null), 2000);
  };
  
  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Initialize room data when loaded
  useEffect(() => {
    if (liveRoom) {
      if (liveRoom.messages && liveRoom.messages.length > 0) {
        setMessages(liveRoom.messages);
      }
      
      if (liveRoom.participants && liveRoom.participants.length > 0) {
        setParticipants(liveRoom.participants);
      }
      
      if (liveRoom.status) {
        setRoomState(liveRoom.status);
      }
    }
  }, [liveRoom]);
  
  // Clean up WebSocket connection when leaving the page
  useEffect(() => {
    return () => {
      sendMessage(formatSocketMessage('leave_room', { roomId: id }));
    };
  }, [id, sendMessage]);
  
  // Set document title
  useEffect(() => {
    if (liveRoom) {
      document.title = `${liveRoom.title} - Live Room | Startup Arena`;
    } else {
      document.title = "Live Pitch Room | Startup Arena";
    }
  }, [liveRoom]);
  
  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 overflow-hidden flex flex-col">
        {isLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-slate-500">Loading live room...</p>
          </div>
        ) : error ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-red-500 mb-4">Error loading the live room. Please try again.</p>
              <Button variant="outline" asChild>
                <Link href="/live-rooms">
                  Back to Live Rooms
                </Link>
              </Button>
            </div>
          </div>
        ) : liveRoom ? (
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            {/* Main Content Area */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Room Header */}
              <div className="bg-white border-b border-slate-200 p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h1 className="text-xl font-bold text-slate-800">{liveRoom.title}</h1>
                      <Badge className={
                        roomState === 'live' 
                          ? 'bg-red-100 text-red-800' 
                          : roomState === 'scheduled' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-slate-100 text-slate-800'
                      }>
                        {roomState === 'live' ? 'LIVE' : roomState === 'scheduled' ? 'SCHEDULED' : 'ENDED'}
                      </Badge>
                      <Badge className={
                        connectionStatus === 'connected'
                          ? 'bg-green-100 text-green-800'
                          : connectionStatus === 'connecting'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                      }>
                        {connectionStatus === 'connected'
                          ? 'Connected'
                          : connectionStatus === 'connecting'
                            ? 'Connecting...'
                            : 'Disconnected'}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-500 mt-1">
                      {liveRoom.description || 'Live pitch session and Q&A'}
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/pitch/${liveRoom.pitchId}`}>
                        View Pitch
                      </Link>
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:bg-red-50 hover:text-red-700">
                      Leave Room
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Video/Presentation Area */}
              <div className="relative bg-slate-900 flex-1 flex flex-col items-center justify-center">
                {roomState === 'live' ? (
                  <>
                    <div className="absolute top-4 left-4 flex items-center space-x-2">
                      <Badge className="bg-red-600 text-white">LIVE</Badge>
                      <span className="text-xs text-white">Viewers: {participants.length}</span>
                    </div>
                    
                    <div className="absolute top-4 right-4">
                      <Button variant="outline" size="sm" className="bg-white/10 text-white hover:bg-white/20 border-white/10">
                        <i className="ri-fullscreen-line mr-1"></i> Fullscreen
                      </Button>
                    </div>
                    
                    <div className="flex-1 w-full flex items-center justify-center">
                      {/* This would be the video stream or presentation - placeholder for now */}
                      <div className="text-center text-white/60">
                        <i className="ri-live-line text-6xl mb-4"></i>
                        <p className="text-lg">Live broadcast is in progress</p>
                        <p className="text-sm mt-2">
                          {liveRoom.presenter?.name || 'The presenter'} is currently sharing their screen
                        </p>
                      </div>
                    </div>
                    
                    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-4">
                      <Button variant="outline" className="bg-white/10 text-white hover:bg-white/20 border-white/10">
                        <i className="ri-mic-line mr-1"></i> Unmute
                      </Button>
                      <Button variant="outline" className="bg-white/10 text-white hover:bg-white/20 border-white/10">
                        <i className="ri-video-line mr-1"></i> Enable Video
                      </Button>
                      <Button variant="outline" className="bg-white/10 text-white hover:bg-white/20 border-white/10">
                        <i className="ri-hand-line mr-1"></i> Raise Hand
                      </Button>
                    </div>
                  </>
                ) : roomState === 'scheduled' ? (
                  <div className="text-center text-white p-8">
                    <div className="bg-slate-800 rounded-lg p-8 max-w-md">
                      <i className="ri-calendar-event-line text-6xl text-primary-400 mb-4"></i>
                      <h2 className="text-2xl font-bold mb-2">This session is scheduled to start soon</h2>
                      <p className="text-slate-300 mb-6">The host has not started this session yet. It will begin at the scheduled time.</p>
                      <div className="text-slate-300 mb-4">
                        <div className="flex justify-center">
                          <div className="text-center px-4">
                            <div className="text-3xl font-bold text-white">00</div>
                            <div className="text-xs uppercase text-slate-400">Days</div>
                          </div>
                          <div className="text-center px-4">
                            <div className="text-3xl font-bold text-white">00</div>
                            <div className="text-xs uppercase text-slate-400">Hours</div>
                          </div>
                          <div className="text-center px-4">
                            <div className="text-3xl font-bold text-white">45</div>
                            <div className="text-xs uppercase text-slate-400">Minutes</div>
                          </div>
                          <div className="text-center px-4">
                            <div className="text-3xl font-bold text-white">12</div>
                            <div className="text-xs uppercase text-slate-400">Seconds</div>
                          </div>
                        </div>
                      </div>
                      <Button className="w-full">Notify Me When It Starts</Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-white p-8">
                    <div className="bg-slate-800 rounded-lg p-8 max-w-md">
                      <i className="ri-film-line text-6xl text-slate-400 mb-4"></i>
                      <h2 className="text-2xl font-bold mb-2">This session has ended</h2>
                      <p className="text-slate-300 mb-6">The live session is now over. You can view the recording or check out the pitch details.</p>
                      <div className="space-y-3">
                        <Button className="w-full">Watch Recording</Button>
                        <Button variant="outline" className="w-full bg-transparent text-white border-white/20 hover:bg-white/10" asChild>
                          <Link href={`/pitch/${liveRoom.pitchId}`}>
                            View Pitch Details
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Reactions Overlay */}
                {reaction && (
                  <div className="absolute bottom-24 right-8 text-4xl animate-bounce">
                    {reaction}
                  </div>
                )}
              </div>
              
              {/* Presenter Info */}
              <div className="bg-white border-t border-slate-200 p-4">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={liveRoom.presenter?.avatarUrl} alt={liveRoom.presenter?.name} />
                    <AvatarFallback className="bg-primary-100 text-primary-700">
                      {getInitials(liveRoom.presenter?.name || 'Presenter')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-slate-800">{liveRoom.presenter?.name || 'Presenter'}</p>
                    <p className="text-xs text-slate-500">{liveRoom.presenter?.title || 'Founder'}</p>
                  </div>
                  <Button size="sm" variant="secondary" className="ml-auto">
                    <i className="ri-user-follow-line mr-1"></i> Follow
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Right Sidebar - Chat, Participants, Q&A */}
            <div className="h-96 lg:h-auto lg:w-96 border-t lg:border-l lg:border-t-0 border-slate-200 bg-white flex flex-col overflow-hidden">
              <Tabs defaultValue="chat" className="flex-1 flex flex-col" onValueChange={setActiveTab}>
                <TabsList className="border-b border-slate-200 w-full justify-start rounded-none px-2">
                  <TabsTrigger value="chat" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
                    Chat
                  </TabsTrigger>
                  <TabsTrigger value="participants" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
                    Participants ({participants.length})
                  </TabsTrigger>
                  <TabsTrigger value="questions" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
                    Q&A
                  </TabsTrigger>
                </TabsList>
                
                {/* Chat Tab */}
                <TabsContent value="chat" className="flex-1 flex flex-col p-0 m-0 overflow-hidden">
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {messages.length === 0 ? (
                        <div className="text-center py-8 text-slate-500">
                          <i className="ri-chat-3-line text-3xl mb-2"></i>
                          <p>No messages yet</p>
                          <p className="text-xs mt-1">Be the first to send a message!</p>
                        </div>
                      ) : (
                        messages.map((msg) => (
                          <div key={msg.id} className={`${msg.type === 'system' ? 'text-center' : ''}`}>
                            {msg.type === 'system' ? (
                              <div className="bg-slate-100 rounded-full px-3 py-1 text-xs text-slate-600 inline-block">
                                {msg.content}
                              </div>
                            ) : (
                              <div className="flex space-x-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={msg.senderAvatar} alt={msg.senderName} />
                                  <AvatarFallback className="bg-primary-100 text-primary-700 text-xs">
                                    {getInitials(msg.senderName)}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="flex items-center space-x-2">
                                    <p className="text-sm font-medium text-slate-800">{msg.senderName}</p>
                                    <span className="text-xs text-slate-500">{formatTime(new Date(msg.timestamp))}</span>
                                  </div>
                                  {msg.type === 'reaction' ? (
                                    <div className="text-2xl">{msg.content}</div>
                                  ) : msg.type === 'question' ? (
                                    <div className="bg-blue-50 rounded-lg p-3 text-slate-800 border-l-2 border-blue-500">
                                      {msg.content}
                                    </div>
                                  ) : (
                                    <p className="text-slate-700">{msg.content}</p>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        ))
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>
                  
                  {activeTab === "chat" && (
                    <div className="border-t border-slate-200 p-3">
                      <div className="flex items-center space-x-2 mb-2">
                        <button 
                          className="text-xl hover:bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center transition-colors"
                          onClick={() => handleSendReaction('👍')}
                        >
                          👍
                        </button>
                        <button 
                          className="text-xl hover:bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center transition-colors"
                          onClick={() => handleSendReaction('❤️')}
                        >
                          ❤️
                        </button>
                        <button 
                          className="text-xl hover:bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center transition-colors"
                          onClick={() => handleSendReaction('🔥')}
                        >
                          🔥
                        </button>
                        <button 
                          className="text-xl hover:bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center transition-colors"
                          onClick={() => handleSendReaction('👏')}
                        >
                          👏
                        </button>
                        <button 
                          className="text-xl hover:bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center transition-colors"
                          onClick={() => handleSendReaction('🎉')}
                        >
                          🎉
                        </button>
                        <button 
                          className="text-xl hover:bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center transition-colors"
                          onClick={() => handleSendReaction('🤔')}
                        >
                          🤔
                        </button>
                      </div>
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Type a message..."
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                          className="flex-1"
                        />
                        <Button onClick={handleSendMessage} disabled={!message.trim()}>
                          Send
                        </Button>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                {/* Participants Tab */}
                <TabsContent value="participants" className="flex-1 p-0 m-0 overflow-hidden">
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-1">
                      {participants.length === 0 ? (
                        <div className="text-center py-8 text-slate-500">
                          <i className="ri-user-line text-3xl mb-2"></i>
                          <p>No participants yet</p>
                        </div>
                      ) : (
                        participants.map((participant) => (
                          <div key={participant.id} className="flex items-center space-x-3 p-2 hover:bg-slate-50 rounded-lg">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={participant.avatar} alt={participant.name} />
                              <AvatarFallback className="bg-primary-100 text-primary-700 text-xs">
                                {getInitials(participant.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-slate-800">{participant.name}</p>
                              <p className="text-xs text-slate-500">{participant.role}</p>
                            </div>
                            {participant.role === 'host' && (
                              <Badge className="bg-primary-100 text-primary-800">Host</Badge>
                            )}
                            {participant.role === 'speaker' && (
                              <Badge className="bg-secondary-100 text-secondary-800">Speaker</Badge>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>
                
                {/* Q&A Tab */}
                <TabsContent value="questions" className="flex-1 flex flex-col p-0 m-0 overflow-hidden">
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {messages.filter(m => m.type === 'question').length === 0 ? (
                        <div className="text-center py-8 text-slate-500">
                          <i className="ri-question-answer-line text-3xl mb-2"></i>
                          <p>No questions yet</p>
                          <p className="text-xs mt-1">Be the first to ask a question!</p>
                        </div>
                      ) : (
                        messages
                          .filter(m => m.type === 'question')
                          .map((question) => (
                            <div key={question.id} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                              <div className="flex items-start space-x-3 mb-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={question.senderAvatar} alt={question.senderName} />
                                  <AvatarFallback className="bg-secondary-100 text-secondary-700 text-xs">
                                    {getInitials(question.senderName)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="flex justify-between items-start">
                                    <p className="text-sm font-medium text-slate-800">{question.senderName}</p>
                                    <span className="text-xs text-slate-500">{formatTime(new Date(question.timestamp))}</span>
                                  </div>
                                  <p className="text-slate-700 font-medium mt-1">{question.content}</p>
                                </div>
                              </div>
                              <div className="flex justify-between mt-2">
                                <div className="flex items-center space-x-2 text-xs text-slate-500">
                                  <button className="hover:text-primary-600">
                                    <i className="ri-thumb-up-line mr-1"></i> Upvote (0)
                                  </button>
                                </div>
                                <Button variant="outline" size="sm">
                                  Answer
                                </Button>
                              </div>
                            </div>
                          ))
                      )}
                    </div>
                  </ScrollArea>
                  
                  {activeTab === "questions" && (
                    <div className="border-t border-slate-200 p-3">
                      <Textarea
                        placeholder="Ask a question..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="mb-2"
                        rows={3}
                      />
                      <div className="flex justify-end">
                        <Button 
                          onClick={() => {
                            if (!message.trim()) return;
                            
                            sendMessage(formatSocketMessage('message', {
                              roomId: id,
                              content: message,
                              type: 'question'
                            }));
                            
                            setMessage("");
                          }} 
                          disabled={!message.trim()}
                        >
                          Submit Question
                        </Button>
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-slate-500 mb-4">Live room not found</p>
              <Button variant="outline" asChild>
                <Link href="/live-rooms">
                  Back to Live Rooms
                </Link>
              </Button>
            </div>
          </div>
        )}
      </main>
      
      <MobileNav />
    </div>
  );
}