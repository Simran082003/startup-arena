import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { MfaTestButton } from "@/components/ui/mfa-test";

export default function MfaTest() {
  return (
    <div className="container mx-auto py-12 px-4 max-w-5xl">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold tracking-tight">MFA Test Page</h1>
        <p className="text-lg text-slate-700 mt-4">
          This page allows you to test the Multi-Factor Authentication functionality
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Test MFA Login</CardTitle>
            <CardDescription>
              Create a test user with MFA already enabled to verify the login flow
            </CardDescription>
          </CardHeader>
          <CardContent>
            <MfaTestButton />
          </CardContent>
          <CardFooter className="flex-col items-start gap-2">
            <p className="text-sm text-slate-500">
              When testing, use code <span className="font-mono font-semibold">123456</span> as the MFA verification code.
            </p>
            <p className="text-sm text-slate-500">
              After setting up the test user, go to the <Link href="/auth/login" className="text-primary underline">Login page</Link> to test MFA.
            </p>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>MFA Setup Instructions</CardTitle>
            <CardDescription>
              For real users, MFA can be enabled from the security settings page
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">
              Multi-Factor Authentication adds an extra layer of security to your account by requiring a verification code from an authenticator app in addition to your password.
            </p>
            <ol className="list-decimal pl-5 space-y-2 text-sm">
              <li>Go to your <Link href="/security-settings" className="text-primary underline">Security Settings</Link></li>
              <li>Click "Enable Two-Factor Authentication"</li>
              <li>Scan the QR code with an authenticator app like Google Authenticator, Authy, or Microsoft Authenticator</li>
              <li>Enter the verification code from your app to complete setup</li>
            </ol>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full">
              <Link href="/security-settings">Go to Security Settings</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}