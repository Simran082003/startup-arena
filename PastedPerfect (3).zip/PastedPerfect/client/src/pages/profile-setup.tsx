import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";

// Define user type
interface User {
  id: number;
  username: string;
  name?: string;
  email?: string;
  avatarUrl?: string;
  role: string;
  title?: string;
  bio?: string;
  company?: string;
}

const profileSetupSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").optional(),
  email: z.string().email("Please enter a valid email").optional(),
  role: z.enum(["founder", "investor", "mentor"], {
    required_error: "Please select a role",
  }),
  title: z.string().optional(),
  bio: z.string().optional(),
  company: z.string().optional(),
});

type ProfileSetupFormValues = z.infer<typeof profileSetupSchema>;

export default function ProfileSetup() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Fetch current user data
  const { data: userData, isLoading } = useQuery<User>({
    queryKey: ['/api/auth/me'],
    retry: false
  });
  
  // Handle authentication checking
  useEffect(() => {
    if (!isLoading && !userData) {
      // If not logged in, redirect to login
      navigate("/auth/login");
      toast({
        variant: "destructive",
        title: "Not authenticated",
        description: "Please log in to continue.",
      });
    }
  }, [isLoading, userData, navigate, toast]);

  // Set document title
  useEffect(() => {
    document.title = "Complete Your Profile | Startup Arena";
  }, []);

  // Initialize form with empty values
  const form = useForm<ProfileSetupFormValues>({
    resolver: zodResolver(profileSetupSchema),
    defaultValues: {
      name: "",
      email: "",
      role: undefined,
      title: "",
      bio: "",
      company: "",
    },
  });

  // Update form values when userData changes
  useEffect(() => {
    if (userData) {
      form.reset({
        name: userData.name || "",
        email: userData.email || "",
        role: (userData.role as "founder" | "investor" | "mentor") || undefined,
        title: userData.title || "",
        bio: userData.bio || "",
        company: userData.company || "",
      });
    }
  }, [userData, form]);

  const onSubmit = async (data: ProfileSetupFormValues) => {
    try {
      await apiRequest("PUT", "/api/auth/profile", data);
      
      // Invalidate the query to refresh user data
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Profile updated!",
        description: "Your profile has been successfully updated.",
      });
      
      // Redirect to dashboard
      navigate("/dashboard");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: "There was a problem updating your profile. Please try again.",
      });
    }
  };

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center">
        <p>Loading your profile information...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-slate-800">Complete your profile</h1>
        <p className="mt-2 text-slate-600">
          Tell us a bit about yourself to get the most out of Startup Arena
        </p>
      </div>
      
      <Card className="w-full max-w-2xl">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardHeader>
              <CardTitle>Your information</CardTitle>
              <CardDescription>
                Please fill out the details below to personalize your experience
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your full name" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your email address" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>I am joining as a</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="founder" />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">
                            Founder — I have a startup idea to pitch
                          </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="investor" />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">
                            Investor — I'm looking to invest in startups
                          </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="mentor" />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">
                            Mentor — I want to guide founders
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Professional Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. CEO, Software Engineer, Angel Investor" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company or Organization</FormLabel>
                    <FormControl>
                      <Input placeholder="Your company name (if applicable)" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bio</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Tell us a bit about yourself, your experience, and your interests..."
                        className="min-h-[100px]"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            
            <CardFooter className="flex justify-end">
              <Button 
                type="submit" 
                disabled={form.formState.isSubmitting}
              >
                {form.formState.isSubmitting ? "Saving..." : "Save Profile"}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
    </div>
  );
}