import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import MobileNav from "@/components/common/mobile-nav";

// Define the form schema
const pitchFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  category: z.string().min(1, "Category is required"),
  status: z.enum(["draft", "active"]).default("draft"),
  imageSrc: z.string().optional(),
  videoSrc: z.string().optional(),
});

type PitchFormValues = z.infer<typeof pitchFormSchema>;

export default function PitchSubmission() {
  const { id } = useParams();
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("basics");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isEditMode = !!id;

  // Query to get existing pitch if in edit mode
  const { data: existingPitch, isLoading } = useQuery({
    queryKey: ['/api/pitches/' + id],
    enabled: isEditMode,
  });

  // Parse URL query params for draft data (if coming from dashboard quick create)
  useEffect(() => {
    if (!isEditMode && !isLoading) {
      const url = new URL(window.location.href);
      const title = url.searchParams.get('title');
      const description = url.searchParams.get('description');
      const category = url.searchParams.get('category');
      const tagString = url.searchParams.get('tags');
      
      if (title) form.setValue('title', title);
      if (description) form.setValue('description', description);
      if (category) form.setValue('category', category);
      if (tagString) setTags(tagString.split(','));
    }
  }, []);

  // Form setup
  const form = useForm<PitchFormValues>({
    resolver: zodResolver(pitchFormSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      status: "draft",
      imageSrc: "",
      videoSrc: "",
    }
  });

  // Update form when existing pitch data is loaded
  useEffect(() => {
    if (existingPitch && isEditMode) {
      form.reset({
        title: existingPitch.title,
        description: existingPitch.description,
        category: existingPitch.category,
        status: existingPitch.status,
        imageSrc: existingPitch.imageSrc || "",
        videoSrc: existingPitch.videoSrc || "",
      });
      
      if (existingPitch.tags) {
        setTags(existingPitch.tags);
      }
      
      if (existingPitch.imageSrc) {
        setImagePreview(existingPitch.imageSrc);
      }
    }
  }, [existingPitch, isEditMode, form]);

  // Tag handling
  const handleAddTag = () => {
    if (tagInput.trim() !== "" && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleImageInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // In a real app, this would upload to a file service
    // For now, we'll just set a URL from the input
    const value = e.target.value;
    form.setValue("imageSrc", value);
    setImagePreview(value);
  };

  // Form submission
  const onSubmit = async (values: PitchFormValues) => {
    try {
      setIsSubmitting(true);
      
      // Add tags to the data
      const pitchData = {
        ...values,
        tags
      };
      
      if (isEditMode) {
        // Update existing pitch
        await apiRequest("PUT", `/api/pitches/${id}`, pitchData);
        toast({
          title: "Pitch updated",
          description: "Your pitch has been updated successfully.",
        });
      } else {
        // Create new pitch
        await apiRequest("POST", "/api/pitches", pitchData);
        toast({
          title: "Pitch created",
          description: "Your pitch has been created successfully.",
        });
      }
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/pitches/user'] });
      
      // Redirect to my pitches page
      navigate("/my-pitches");
    } catch (error) {
      console.error("Error submitting pitch:", error);
      toast({
        title: "Error",
        description: "There was an error submitting your pitch. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Set document title
  useEffect(() => {
    document.title = isEditMode ? "Edit Pitch | Startup Arena" : "New Pitch | Startup Arena";
  }, [isEditMode]);

  if (isLoading && isEditMode) {
    return (
      <div className="flex-1 p-6 lg:ml-64 pt-20">
        <div className="text-center py-16">
          <p className="text-slate-500">Loading pitch details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">
            {isEditMode ? "Edit Pitch" : "Submit New Pitch"}
          </h1>
          <p className="text-slate-500 mt-1">
            {isEditMode 
              ? "Update your pitch details to improve your chances of success"
              : "Share your startup idea with potential investors and mentors"
            }
          </p>
        </div>
        
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Pitch Details</CardTitle>
          </CardHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3 mb-6">
                  <TabsTrigger value="basics">Basic Information</TabsTrigger>
                  <TabsTrigger value="media">Media & Preview</TabsTrigger>
                  <TabsTrigger value="settings">Settings & Status</TabsTrigger>
                </TabsList>
                
                <CardContent>
                  <TabsContent value="basics" className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pitch Title</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="E.g., TaskFlow: Project Management Simplified" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="SaaS">SaaS</SelectItem>
                              <SelectItem value="FinTech">FinTech</SelectItem>
                              <SelectItem value="HealthTech">HealthTech</SelectItem>
                              <SelectItem value="EdTech">EdTech</SelectItem>
                              <SelectItem value="AI">AI & Machine Learning</SelectItem>
                              <SelectItem value="E-commerce">E-commerce</SelectItem>
                              <SelectItem value="Climate Tech">Climate Tech</SelectItem>
                              <SelectItem value="IoT">Hardware & IoT</SelectItem>
                              <SelectItem value="Mobile Apps">Mobile Apps</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pitch Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your startup idea in detail..." 
                              className="min-h-[200px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="pt-4 border-t border-slate-200">
                      <FormLabel className="block text-sm font-medium text-slate-700 mb-2">
                        Tags
                      </FormLabel>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="flex items-center space-x-1 bg-primary-100 text-primary-800 hover:bg-primary-200">
                            <span>{tag}</span>
                            <button 
                              type="button"
                              onClick={() => handleRemoveTag(tag)}
                              className="text-primary-600 hover:text-primary-800 ml-1"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <div className="flex">
                        <Input 
                          value={tagInput}
                          onChange={(e) => setTagInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                          placeholder="Enter a tag..." 
                          className="rounded-r-none"
                        />
                        <Button 
                          type="button" 
                          onClick={handleAddTag}
                          className="rounded-l-none"
                          variant="secondary"
                        >
                          Add
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Add relevant tags to help others discover your pitch
                      </p>
                    </div>
                    
                    <div className="flex justify-end space-x-2 mt-6">
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => navigate('/my-pitches')}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="button"
                        onClick={() => setActiveTab("media")}
                      >
                        Next
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="media" className="space-y-4">
                    <FormField
                      control={form.control}
                      name="imageSrc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cover Image URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://example.com/image.jpg" 
                              {...field} 
                              onChange={handleImageInputChange}
                            />
                          </FormControl>
                          <FormMessage />
                          <p className="text-xs text-muted-foreground mt-1">
                            Provide a URL to an image that represents your startup
                          </p>
                        </FormItem>
                      )}
                    />
                    
                    {imagePreview && (
                      <div className="mt-4">
                        <p className="text-sm font-medium mb-2">Preview:</p>
                        <div className="aspect-video bg-slate-100 rounded-md overflow-hidden">
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="w-full h-full object-cover"
                            onError={() => setImagePreview(null)}
                          />
                        </div>
                      </div>
                    )}
                    
                    <FormField
                      control={form.control}
                      name="videoSrc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Demo Video URL (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://youtube.com/watch?v=..." 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                          <p className="text-xs text-muted-foreground mt-1">
                            Add a link to a YouTube or Vimeo video of your product demo
                          </p>
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2 mt-6">
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => setActiveTab("basics")}
                      >
                        Back
                      </Button>
                      <Button
                        type="button"
                        onClick={() => setActiveTab("settings")}
                      >
                        Next
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="settings" className="space-y-4">
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="draft">Draft - visible only to you</SelectItem>
                              <SelectItem value="active">Published - visible to everyone</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="bg-slate-50 p-4 rounded-md mt-6">
                      <h4 className="font-medium text-slate-800 mb-2">Before you submit</h4>
                      <ul className="text-sm text-slate-600 space-y-2 list-disc pl-5">
                        <li>Ensure your pitch title is clear and descriptive</li>
                        <li>Provide a detailed description of your startup idea</li>
                        <li>Add relevant tags to increase discoverability</li>
                        <li>Include a cover image for better visual engagement</li>
                        <li>Set status to "Published" when ready for others to see</li>
                      </ul>
                    </div>
                    
                    <div className="flex justify-end space-x-2 mt-6">
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => setActiveTab("media")}
                      >
                        Back
                      </Button>
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                      >
                        {isSubmitting
                          ? "Submitting..."
                          : isEditMode
                            ? "Update Pitch"
                            : "Create Pitch"
                        }
                      </Button>
                    </div>
                  </TabsContent>
                </CardContent>
              </Tabs>
              
              <CardFooter className="border-t pt-6 flex justify-between">
                <Button 
                  type="button" 
                  variant="ghost"
                  onClick={() => navigate('/my-pitches')}
                >
                  Cancel
                </Button>
                
                <div className="flex space-x-2">
                  {activeTab !== "basics" && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setActiveTab(activeTab === "media" ? "basics" : "media")}
                    >
                      Back
                    </Button>
                  )}
                  
                  {activeTab !== "settings" ? (
                    <Button
                      type="button"
                      onClick={() => setActiveTab(activeTab === "basics" ? "media" : "settings")}
                    >
                      Next
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                    >
                      {isSubmitting
                        ? "Submitting..."
                        : isEditMode
                          ? "Update Pitch"
                          : "Create Pitch"
                      }
                    </Button>
                  )}
                </div>
              </CardFooter>
            </form>
          </Form>
        </Card>
      </main>
      
      <MobileNav />
    </div>
  );
}
