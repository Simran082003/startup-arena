import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { InfoIcon, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import MobileNav from "@/components/common/mobile-nav";

// Define the form schema
const nftMintSchema = z.object({
  pitchId: z.number({
    required_error: "Please select a pitch to mint",
  }),
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  imageUrl: z.string().optional(),
  attributes: z.array(
    z.object({
      trait_type: z.string(),
      value: z.string()
    })
  ).optional(),
});

type NftMintFormValues = z.infer<typeof nftMintSchema>;

export default function MintNft() {
  const { id } = useParams();
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedPitch, setSelectedPitch] = useState<any>(null);
  
  // Set document title
  useEffect(() => {
    document.title = "Mint NFT | Startup Arena";
  }, []);

  // Fetch user's pitches that haven't been minted yet
  const { data: userPitches, isLoading: loadingPitches } = useQuery<any[]>({
    queryKey: ['/api/pitches/user/unminted'],
  });

  // Fetch specific pitch if ID is provided
  const { data: pitchData, isLoading: loadingPitch } = useQuery({
    queryKey: ['/api/pitches/' + id],
    enabled: !!id,
  });

  // Form setup
  const form = useForm<NftMintFormValues>({
    resolver: zodResolver(nftMintSchema),
    defaultValues: {
      pitchId: id ? parseInt(id) : undefined,
      title: "",
      description: "",
      imageUrl: "",
      attributes: [
        { trait_type: "Category", value: "" },
        { trait_type: "Created Date", value: "" }
      ],
    }
  });

  // Update form when pitch data is loaded
  useEffect(() => {
    if (pitchData && id) {
      const pitch = pitchData as any;
      form.reset({
        pitchId: parseInt(id),
        title: pitch.title || "",
        description: pitch.description || "",
        imageUrl: pitch.imageSrc || "/nft-placeholder.svg",
        attributes: [
          { trait_type: "Category", value: pitch.category || "" },
          { trait_type: "Created Date", value: pitch.createdAt || new Date().toISOString() }
        ],
      });
      setSelectedPitch(pitch);
    }
  }, [pitchData, id, form]);

  // Handle pitch selection
  const handlePitchSelect = (pitchId: number) => {
    if (!userPitches || !Array.isArray(userPitches)) return;
    
    const pitch = userPitches.find((p: any) => p.id === pitchId);
    if (pitch) {
      setSelectedPitch(pitch);
      form.setValue("pitchId", pitch.id);
      form.setValue("title", pitch.title || "");
      form.setValue("description", pitch.description || "");
      form.setValue("imageUrl", pitch.imageSrc || "/nft-placeholder.svg");
      form.setValue("attributes", [
        { trait_type: "Category", value: pitch.category || "" },
        { trait_type: "Created Date", value: pitch.createdAt || new Date().toISOString() }
      ]);
    }
  };

  // Form submission
  const onSubmit = async (values: NftMintFormValues) => {
    try {
      setIsSubmitting(true);
      
      const response = await apiRequest("POST", "/api/nfts/mint", values);
      const data = await response.json();
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/nfts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/pitches/user'] });
      
      toast({
        title: "NFT Successfully Minted!",
        description: `Your pitch has been minted with token ID: ${data.tokenId}`,
      });
      
      // Redirect to the NFT gallery
      navigate("/nft-gallery");
    } catch (error) {
      console.error("Error minting NFT:", error);
      toast({
        title: "Minting Failed",
        description: "There was an error minting your NFT. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Loading state
  if ((loadingPitches && !id) || (loadingPitch && id)) {
    return (
      <div className="flex-1 p-6 lg:ml-64 pt-20">
        <div className="text-center py-16">
          <p className="text-slate-500">Loading pitch details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Mint Your Pitch as an NFT</h1>
          <p className="text-slate-500 mt-1">
            Create an NFT to establish ownership of your startup idea
          </p>
        </div>
        
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>NFT Details</CardTitle>
          </CardHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <CardContent className="space-y-6">
                {/* Pitch selection (only show if no ID was provided) */}
                {!id && (
                  <div className="mb-6">
                    <FormLabel className="text-base">Select a Pitch to Mint</FormLabel>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                      {userPitches && Array.isArray(userPitches) && userPitches.length > 0 ? (
                        userPitches.map((pitch: any) => (
                          <Card 
                            key={pitch.id} 
                            className={`cursor-pointer border-2 hover:border-primary-300 transition-colors ${
                              selectedPitch?.id === pitch.id ? 'border-primary-500 bg-primary-50' : ''
                            }`}
                            onClick={() => handlePitchSelect(pitch.id)}
                          >
                            <CardContent className="p-4 flex">
                              <div className="w-16 h-16 rounded overflow-hidden mr-4 flex-shrink-0">
                                <img 
                                  src={pitch.imageSrc || "/pitch-placeholder.svg"} 
                                  alt={pitch.title || "Pitch"}
                                  className="w-full h-full object-cover" 
                                />
                              </div>
                              <div>
                                <h3 className="font-medium">{pitch.title || "Untitled Pitch"}</h3>
                                <p className="text-sm text-slate-500 line-clamp-1">{pitch.description || "No description"}</p>
                                <Badge className="mt-2" variant="outline">{pitch.category || "Other"}</Badge>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      ) : (
                        <div className="col-span-2 text-center py-8">
                          <AlertCircle className="h-8 w-8 text-amber-500 mx-auto mb-2" />
                          <p className="text-slate-600 mb-2">No pitches available for minting</p>
                          <p className="text-sm text-slate-500 mb-4">Create a pitch first or check if your pitches are already minted</p>
                          <Button variant="outline" asChild>
                            <a href="/pitch/new">Create New Pitch</a>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                {/* Form fields */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>NFT Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter NFT title" {...field} />
                      </FormControl>
                      <FormDescription>
                        This will be displayed as the title of your NFT
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>NFT Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe your NFT" 
                          className="min-h-[100px]" 
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Provide a detailed description for your NFT that will be stored on-chain
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>NFT Image</FormLabel>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormControl>
                          <Input placeholder="Image URL" {...field} />
                        </FormControl>
                        <div className="aspect-square bg-slate-100 rounded-md overflow-hidden">
                          <img
                            src={field.value || "/nft-placeholder.svg"}
                            alt="NFT Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "/nft-placeholder.svg";
                            }}
                          />
                        </div>
                      </div>
                      <FormDescription>
                        This image will represent your NFT on the blockchain
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Alert className="bg-amber-50 border-amber-200">
                  <InfoIcon className="h-4 w-4" />
                  <AlertTitle>Minting Fee</AlertTitle>
                  <AlertDescription>
                    Minting an NFT incurs a small network fee to cover blockchain transaction costs. This is approximately $0.02-$0.10 on Polygon.
                  </AlertDescription>
                </Alert>
              </CardContent>
              
              <CardFooter className="flex justify-between border-t pt-6">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => navigate(id ? `/pitch/${id}` : '/my-pitches')}
                >
                  Cancel
                </Button>
                
                <Button
                  type="submit"
                  disabled={isSubmitting || !selectedPitch}
                  className="relative"
                >
                  {isSubmitting ? (
                    <>
                      <span className="opacity-0">Mint NFT</span>
                      <span className="absolute inset-0 flex items-center justify-center">
                        <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                      </span>
                    </>
                  ) : (
                    "Mint NFT"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </Card>
        
        {/* Information Section */}
        <div className="mt-12 bg-slate-50 rounded-lg border border-slate-200 p-6 max-w-4xl mx-auto">
          <h3 className="text-lg font-bold text-slate-800 mb-4">About NFT Minting</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg p-5 border border-slate-200">
              <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="w-5 h-5 text-primary-600">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h4 className="font-bold text-slate-800 mb-2">Protect Your Ideas</h4>
              <p className="text-sm text-slate-600">
                Minting your pitch as an NFT establishes proof of ownership that's permanently recorded on the blockchain.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-5 border border-slate-200">
              <div className="w-10 h-10 rounded-full bg-secondary-100 flex items-center justify-center mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="w-5 h-5 text-secondary-600">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                </svg>
              </div>
              <h4 className="font-bold text-slate-800 mb-2">Transfer Rights</h4>
              <p className="text-sm text-slate-600">
                You can transfer partial or full ownership of your idea to investors or partners through NFT transactions.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-5 border border-slate-200">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="w-5 h-5 text-green-600">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h4 className="font-bold text-slate-800 mb-2">Documentation</h4>
              <p className="text-sm text-slate-600">
                Your NFT serves as transparent documentation of your idea's evolution, which can be valuable for intellectual property claims.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}