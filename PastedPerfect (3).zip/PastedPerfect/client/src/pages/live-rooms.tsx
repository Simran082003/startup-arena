import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LiveRoomCard from "@/components/ui/live-room-card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { formatDate, formatTime } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MobileNav from "@/components/common/mobile-nav";

export default function LiveRooms() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("live");
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  
  // Form state
  const [roomTitle, setRoomTitle] = useState("");
  const [roomDescription, setRoomDescription] = useState("");
  const [roomPitchId, setRoomPitchId] = useState("");
  const [roomThumbnailUrl, setRoomThumbnailUrl] = useState("");
  const [roomStartTime, setRoomStartTime] = useState("");
  const [roomStatus, setRoomStatus] = useState("scheduled");

  // Fetch live and upcoming rooms
  const { data: liveRooms = [], isLoading: loadingRooms } = useQuery<any[]>({
    queryKey: ['/api/live-rooms'],
  });

  // Fetch user's pitches for the selection dropdown
  const { data: userPitches = [], isLoading: loadingPitches } = useQuery<any[]>({
    queryKey: ['/api/pitches/user'],
  });

  // Handle create live room
  const handleCreateRoom = async () => {
    if (!roomTitle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a room title",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsCreating(true);
      
      const roomData = {
        title: roomTitle,
        description: roomDescription,
        pitchId: roomPitchId ? parseInt(roomPitchId) : undefined,
        thumbnailSrc: roomThumbnailUrl,
        startTime: roomStartTime || undefined,
        status: roomStatus,
      };
      
      await apiRequest("POST", "/api/live-rooms", roomData);
      
      // Reset form
      setRoomTitle("");
      setRoomDescription("");
      setRoomPitchId("");
      setRoomThumbnailUrl("");
      setRoomStartTime("");
      setRoomStatus("scheduled");
      
      // Close dialog
      setCreateDialogOpen(false);
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/live-rooms'] });
      
      toast({
        title: "Live room created",
        description: "Your live room has been created successfully.",
      });
    } catch (error) {
      console.error("Error creating live room:", error);
      toast({
        title: "Error",
        description: "There was an error creating your live room. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  // Set document title
  useEffect(() => {
    document.title = "Live Rooms | Startup Arena";
  }, []);

  // Filter rooms based on status
  const liveRoomsData = liveRooms.filter((room: any) => room.status === "live");
  const upcomingRoomsData = liveRooms.filter((room: any) => room.status === "upcoming");

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Live Pitch Rooms</h1>
            <p className="text-slate-500 mt-1">Join live pitch sessions or schedule your own</p>
          </div>
          
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <i className="ri-add-line mr-1"></i> Schedule Pitch
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Schedule a Live Pitch</DialogTitle>
                <DialogDescription>
                  Create a live room to present your pitch and get feedback in real-time
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 my-4">
                <div>
                  <label htmlFor="room-title" className="block text-sm font-medium text-slate-700 mb-1">
                    Room Title
                  </label>
                  <Input 
                    id="room-title" 
                    value={roomTitle}
                    onChange={(e) => setRoomTitle(e.target.value)}
                    placeholder="E.g., EcoCharge Demo & Investor Pitch"
                  />
                </div>
                
                <div>
                  <label htmlFor="room-description" className="block text-sm font-medium text-slate-700 mb-1">
                    Description (Optional)
                  </label>
                  <Textarea 
                    id="room-description" 
                    value={roomDescription}
                    onChange={(e) => setRoomDescription(e.target.value)}
                    placeholder="Briefly describe what you'll be presenting in this session"
                  />
                </div>
                
                <div>
                  <label htmlFor="room-pitch" className="block text-sm font-medium text-slate-700 mb-1">
                    Select Pitch (Optional)
                  </label>
                  <Select value={roomPitchId} onValueChange={setRoomPitchId}>
                    <SelectTrigger id="room-pitch">
                      <SelectValue placeholder="Select a pitch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {!loadingPitches && userPitches.map((pitch: any) => (
                        <SelectItem key={pitch.id} value={pitch.id.toString()}>
                          {pitch.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label htmlFor="room-thumbnail" className="block text-sm font-medium text-slate-700 mb-1">
                    Thumbnail URL (Optional)
                  </label>
                  <Input 
                    id="room-thumbnail" 
                    value={roomThumbnailUrl}
                    onChange={(e) => setRoomThumbnailUrl(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
                
                <div>
                  <label htmlFor="room-start-time" className="block text-sm font-medium text-slate-700 mb-1">
                    Start Time
                  </label>
                  <Input 
                    id="room-start-time" 
                    type="datetime-local"
                    value={roomStartTime}
                    onChange={(e) => setRoomStartTime(e.target.value)}
                  />
                </div>
                
                <div>
                  <label htmlFor="room-status" className="block text-sm font-medium text-slate-700 mb-1">
                    Status
                  </label>
                  <Select value={roomStatus} onValueChange={setRoomStatus}>
                    <SelectTrigger id="room-status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="scheduled">Scheduled for later</SelectItem>
                      <SelectItem value="live">Start live immediately</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => setCreateDialogOpen(false)}
                  disabled={isCreating}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateRoom}
                  disabled={isCreating}
                >
                  {isCreating ? "Creating..." : "Create Room"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="mb-6">
            <TabsTrigger value="live" className="relative">
              Live Now
              {liveRoomsData.length > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
              )}
            </TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="my-rooms">My Rooms</TabsTrigger>
          </TabsList>
          
          <TabsContent value="live">
            {loadingRooms ? (
              <div className="text-center py-8">
                <p className="text-slate-500">Loading live rooms...</p>
              </div>
            ) : liveRoomsData.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {liveRoomsData.map((room: any) => (
                  <LiveRoomCard
                    key={room.id}
                    id={room.id}
                    title={room.title}
                    presenterName={room.presenter.name}
                    presenterImage={room.presenter.avatarUrl}
                    thumbnailSrc={room.thumbnailSrc}
                    viewers={room.viewerCount}
                    status="live"
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                    <i className="ri-live-line text-2xl text-slate-400"></i>
                  </div>
                  <h3 className="text-lg font-medium text-slate-800 mb-2">No live pitches right now</h3>
                  <p className="text-slate-500 mb-6">Check back later or schedule your own live pitch</p>
                  <Button onClick={() => setCreateDialogOpen(true)}>
                    Schedule Your Own
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="upcoming">
            {loadingRooms ? (
              <div className="text-center py-8">
                <p className="text-slate-500">Loading upcoming rooms...</p>
              </div>
            ) : upcomingRoomsData.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {upcomingRoomsData.map((room: any) => (
                  <LiveRoomCard
                    key={room.id}
                    id={room.id}
                    title={room.title}
                    presenterName={room.presenter.name}
                    presenterImage={room.presenter.avatarUrl}
                    thumbnailSrc={room.thumbnailSrc}
                    viewers={0}
                    status="upcoming"
                    startTime={room.startTime}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                    <i className="ri-calendar-event-line text-2xl text-slate-400"></i>
                  </div>
                  <h3 className="text-lg font-medium text-slate-800 mb-2">No upcoming pitches scheduled</h3>
                  <p className="text-slate-500 mb-6">Be the first to schedule a live pitch session</p>
                  <Button onClick={() => setCreateDialogOpen(true)}>
                    Schedule a Pitch
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="my-rooms">
            {loadingRooms ? (
              <div className="text-center py-8">
                <p className="text-slate-500">Loading your rooms...</p>
              </div>
            ) : (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-slate-800 mb-4">Your Scheduled Pitches</h3>
                
                {liveRooms.filter((room: any) => 
                  room.presenter.username === (queryClient.getQueryData(['/api/auth/me']) as any)?.username
                ).length > 0 ? (
                  liveRooms
                    .filter((room: any) => 
                      room.presenter.username === (queryClient.getQueryData(['/api/auth/me']) as any)?.username
                    )
                    .map((room: any) => (
                      <div key={room.id} className="bg-white rounded-lg border border-slate-200 shadow-sm p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="text-lg font-semibold text-slate-800">{room.title}</h4>
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge className={room.status === 'live' ? 'bg-red-100 text-red-800' : 'bg-accent-100 text-accent-800'}>
                                {room.status === 'live' ? 'Live Now' : 'Scheduled'}
                              </Badge>
                              <span className="text-sm text-slate-500">
                                {room.status === 'live' 
                                  ? 'Started ' + formatTime(room.startTime)
                                  : 'Starts ' + formatDate(room.startTime) + ' at ' + formatTime(room.startTime)
                                }
                              </span>
                            </div>
                          </div>
                          
                          <Link href={`/live-room/${room.id}`}>
                            <Button variant={room.status === 'live' ? 'default' : 'outline'}>
                              {room.status === 'live' ? 'Join Now' : 'View'}
                            </Button>
                          </Link>
                        </div>
                        
                        {room.viewerCount > 0 && (
                          <p className="text-sm text-slate-500 mb-4">
                            <i className="ri-user-line mr-1"></i> {room.viewerCount} viewers
                          </p>
                        )}
                        
                        <div className="flex space-x-2 mt-4">
                          {room.status === 'scheduled' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={async () => {
                                try {
                                  await apiRequest("PUT", `/api/live-rooms/${room.id}`, { status: "live" });
                                  queryClient.invalidateQueries({ queryKey: ['/api/live-rooms'] });
                                  toast({
                                    title: "Room started",
                                    description: "Your live room is now active.",
                                  });
                                } catch (error) {
                                  toast({
                                    title: "Error",
                                    description: "There was an error starting your room.",
                                    variant: "destructive",
                                  });
                                }
                              }}
                            >
                              Start Now
                            </Button>
                          )}
                          
                          {room.status === 'live' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="text-red-600 border-red-200 hover:bg-red-50"
                              onClick={async () => {
                                try {
                                  await apiRequest("PUT", `/api/live-rooms/${room.id}`, { status: "ended" });
                                  queryClient.invalidateQueries({ queryKey: ['/api/live-rooms'] });
                                  toast({
                                    title: "Room ended",
                                    description: "Your live room has been ended.",
                                  });
                                } catch (error) {
                                  toast({
                                    title: "Error",
                                    description: "There was an error ending your room.",
                                    variant: "destructive",
                                  });
                                }
                              }}
                            >
                              End Stream
                            </Button>
                          )}
                          
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              // Copy invite link to clipboard
                              const url = `${window.location.origin}/live-room/${room.id}`;
                              navigator.clipboard.writeText(url);
                              toast({
                                title: "Link copied",
                                description: "Invite link copied to clipboard",
                              });
                            }}
                          >
                            Copy Invite Link
                          </Button>
                        </div>
                      </div>
                    ))
                ) : (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <p className="text-slate-500 mb-4">You haven't scheduled any pitch sessions yet</p>
                      <Button onClick={() => setCreateDialogOpen(true)}>
                        Schedule Your First Pitch
                      </Button>
                    </CardContent>
                  </Card>
                )}
                
                <div className="mt-8">
                  <Button onClick={() => setCreateDialogOpen(true)}>
                    <i className="ri-add-line mr-1"></i> Schedule New Pitch
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <div className="mt-10 px-4 py-6 bg-gradient-to-r from-primary-50 to-secondary-50 rounded-lg border border-primary-100">
          <h3 className="text-lg font-medium text-slate-800 mb-2">Tips for a Successful Live Pitch</h3>
          <ul className="space-y-2 text-sm text-slate-600 list-disc pl-5">
            <li>Prepare a concise 5-minute pitch that clearly explains your problem and solution</li>
            <li>Test your audio and video equipment before going live</li>
            <li>Have your demo ready to showcase your product</li>
            <li>Be prepared to answer questions from investors and mentors</li>
            <li>Follow up with interested participants after your pitch</li>
          </ul>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}

// Temporary Badge component to prevent compile error
// (since this file is imported elsewhere)
import { cn } from "@/lib/utils";

function Badge({ children, className }: { children: React.ReactNode, className?: string }) {
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", className)}>
      {children}
    </span>
  );
}
