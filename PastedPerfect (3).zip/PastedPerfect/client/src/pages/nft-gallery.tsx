import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { getInitials, formatDate } from "@/lib/utils";
import MobileNav from "@/components/common/mobile-nav";

export default function NftGallery() {
  const [filter, setFilter] = useState("all");
  const [sortBy, setSortBy] = useState("newest");

  // Fetch NFTs
  const { data: nfts, isLoading, error } = useQuery({
    queryKey: ['/api/nfts'],
  });

  // Set document title
  useEffect(() => {
    document.title = "NFT Gallery | Startup Arena";
  }, []);

  // Filter and sort NFTs
  const filteredNfts = nfts
    ? nfts
        .filter((nft: any) => {
          if (filter === "all") return true;
          if (filter === "owned") return nft.isOwner;
          if (filter === "created") return nft.isCreator;
          return true;
        })
        .sort((a: any, b: any) => {
          if (sortBy === "newest") {
            return new Date(b.mintedAt).getTime() - new Date(a.mintedAt).getTime();
          }
          if (sortBy === "oldest") {
            return new Date(a.mintedAt).getTime() - new Date(b.mintedAt).getTime();
          }
          if (sortBy === "price-high") {
            return b.price - a.price;
          }
          if (sortBy === "price-low") {
            return a.price - b.price;
          }
          return 0;
        })
    : [];

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">NFT Gallery</h1>
          <p className="text-slate-500 mt-1">Browse pitch NFTs or create one to protect your intellectual property</p>
        </div>
        
        {/* Feature Banner */}
        <div className="bg-gradient-to-r from-primary-600 to-secondary-600 rounded-xl p-6 md:p-8 mb-8 text-white">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-bold">Protect Your Startup Idea</h2>
              <p className="mt-1 text-white/80">Mint your pitch as an NFT to establish proof of ownership and secure your intellectual property.</p>
            </div>
            
            <Button variant="secondary" className="bg-white text-primary-600 hover:bg-white/90" asChild>
              <Link href="/mint-nft">
                Mint New NFT
              </Link>
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <div className="flex flex-col sm:flex-row justify-between mb-6">
          <Tabs defaultValue="all" className="mb-6 sm:mb-0" onValueChange={setFilter}>
            <TabsList className="border-b border-slate-200 w-full justify-start">
              <TabsTrigger value="all" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
                All NFTs
              </TabsTrigger>
              <TabsTrigger value="owned" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
                Owned by You
              </TabsTrigger>
              <TabsTrigger value="created" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
                Created by You
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          <div className="w-full sm:w-48">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* NFT Gallery */}
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading NFTs...</p>
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-red-500">Error loading NFTs. Please try again.</p>
              <Button variant="outline" className="mt-4">
                Retry
              </Button>
            </CardContent>
          </Card>
        ) : filteredNfts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredNfts.map((nft: any) => (
              <Card key={nft.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="relative">
                  <img 
                    src={nft.imageUrl || "/nft-placeholder.svg"} 
                    alt={nft.title} 
                    className="w-full h-48 object-cover bg-white"
                  />
                  <Badge className="absolute top-3 right-3 bg-black/70 text-white">
                    {nft.tokenId}
                  </Badge>
                </div>
                
                <CardContent className="pt-4">
                  <h3 className="text-lg font-bold text-slate-800 mb-1">{nft.title}</h3>
                  <p className="text-sm text-slate-600 mb-3 line-clamp-2">{nft.description}</p>
                  
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={nft.owner.avatarUrl || `/avatars/founder-${(nft.owner.id % 3) + 1}.svg`} />
                      <AvatarFallback className="bg-primary-100 text-primary-700 text-xs">
                        {getInitials(nft.owner.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium text-slate-800">
                        {nft.owner.id === nft.creator.id 
                          ? 'Created & Owned by' 
                          : 'Owned by'}
                      </p>
                      <p className="text-xs text-slate-500">{nft.owner.name}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                    <div>
                      <p className="text-slate-500">Minted On</p>
                      <p className="font-medium text-slate-800">{formatDate(nft.mintedAt)}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">Price</p>
                      <p className="font-medium text-slate-800">
                        {nft.price ? `${nft.price} ETH` : 'Not for sale'}
                      </p>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="flex pt-0 border-t">
                  <Button variant="outline" className="w-full" asChild>
                    <Link href={`/pitch/${nft.pitchId}`}>
                      View Related Pitch
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No NFTs found matching your criteria.</p>
              {filter !== "all" && (
                <Button variant="outline" className="mt-4" onClick={() => setFilter("all")}>
                  View All NFTs
                </Button>
              )}
            </CardContent>
          </Card>
        )}
        
        {/* NFT Info Section */}
        <div className="mt-12 bg-slate-50 rounded-lg border border-slate-200 p-6">
          <h3 className="text-lg font-bold text-slate-800 mb-4">How Startup Arena NFTs Work</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg p-5 border border-slate-200">
              <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mb-3">
                <i className="ri-lock-line text-primary-600"></i>
              </div>
              <h4 className="font-bold text-slate-800 mb-2">Establish Ownership</h4>
              <p className="text-sm text-slate-600">
                When you mint your pitch as an NFT, you create an immutable record of your idea on the blockchain, establishing proof of ownership.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-5 border border-slate-200">
              <div className="w-10 h-10 rounded-full bg-secondary-100 flex items-center justify-center mb-3">
                <i className="ri-exchange-line text-secondary-600"></i>
              </div>
              <h4 className="font-bold text-slate-800 mb-2">Transfer & License</h4>
              <p className="text-sm text-slate-600">
                You can transfer ownership or license your intellectual property to investors or partners using NFT smart contracts.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-5 border border-slate-200">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3">
                <i className="ri-shield-check-line text-green-600"></i>
              </div>
              <h4 className="font-bold text-slate-800 mb-2">Legal Protection</h4>
              <p className="text-sm text-slate-600">
                While not a replacement for patents or trademarks, NFTs can serve as evidence in intellectual property disputes.
              </p>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-secondary-50 border border-secondary-200 rounded-lg">
            <p className="text-sm text-slate-700">
              <strong>Note:</strong> Startup Arena NFTs use the Polygon network for low gas fees and environmental sustainability. A small fee is required to mint your NFT, which goes towards transaction costs and platform maintenance.
            </p>
          </div>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}