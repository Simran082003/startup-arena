import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import StatsCard from "@/components/ui/stats-card";
import PitchCard from "@/components/ui/pitch-card";
import LiveRoomCard from "@/components/ui/live-room-card";
import MentorCard from "@/components/ui/mentor-card";
import InvestorCard from "@/components/ui/investor-card";
import Sidebar from "@/components/common/sidebar";
import MobileNav from "@/components/common/mobile-nav";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { DashboardResponse, UserResponse } from "@shared/types";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("trending");
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Fetch dashboard data with retry on auth issues and logging
  const { data: dashboardData, isLoading, error: dashboardError } = useQuery<DashboardResponse>({
    queryKey: ['/api/dashboard'],
    retry: 3,
    onError: (error: any) => {
      console.error("Dashboard data fetch error:", error);
    }
  });

  // Fetch trending pitches
  const { data: trendingPitches, isLoading: loadingTrending } = useQuery({
    queryKey: ['/api/pitches/trending'],
    staleTime: 5 * 60 * 1000, // 5 minutes cache
  });

  // Fetch user's pitches - only when user is a founder
  const { data: userPitches, isLoading: loadingUserPitches } = useQuery({
    queryKey: ['/api/pitches/user'],
    enabled: !isLoading && dashboardData?.user?.role === 'founder',
  });

  // Fetch live rooms
  const { data: liveRooms = [], isLoading: loadingLiveRooms } = useQuery<any[]>({
    queryKey: ['/api/live-rooms'],
    refetchInterval: 60000, // Refetch every minute to keep live rooms updated
  });

  // Fetch mentors and investors
  const { data: mentorsAndInvestors = { mentors: [], investors: [] }, isLoading: loadingMentorsInvestors } = useQuery<{mentors: any[], investors: any[]}>({
    queryKey: ['/api/mentors-investors/top'],
    enabled: !isLoading && (dashboardData?.user?.role === 'founder' || !dashboardData?.user?.role),
  });

  // New Pitch Dialog
  const [pitchTitle, setPitchTitle] = useState("");
  const [pitchCategory, setPitchCategory] = useState("");
  const [pitchDescription, setPitchDescription] = useState("");
  const [pitchTags, setPitchTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState("");

  const handleAddTag = () => {
    if (newTag && !pitchTags.includes(newTag)) {
      setPitchTags([...pitchTags, newTag]);
      setNewTag("");
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setPitchTags(pitchTags.filter(tag => tag !== tagToRemove));
  };

  const handleNewPitchSubmit = () => {
    // Form validation
    if (!pitchTitle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a pitch title",
        variant: "destructive",
      });
      return;
    }

    if (!pitchCategory) {
      toast({
        title: "Error",
        description: "Please select a category",
        variant: "destructive",
      });
      return;
    }

    if (!pitchDescription.trim()) {
      toast({
        title: "Error",
        description: "Please enter a pitch description",
        variant: "destructive",
      });
      return;
    }

    // Redirect to the full pitch submission page with the draft data
    window.location.href = `/pitch/new?title=${encodeURIComponent(pitchTitle)}&category=${encodeURIComponent(pitchCategory)}&description=${encodeURIComponent(pitchDescription)}&tags=${encodeURIComponent(pitchTags.join(','))}`;
  };

  // Set document title
  useEffect(() => {
    document.title = "Dashboard | Startup Arena";
  }, []);
  
  // Check if user has completed profile with role selection
  useEffect(() => {
    if (!isLoading && dashboardData?.user) {
      // If user hasn't selected a role (or has default role "user"), redirect to profile setup
      // Role equals "user" when registration happened but profile not completed yet
      if (!dashboardData.user.role || dashboardData.user.role === "user") {
        toast({
          title: "Profile completion required",
          description: "Please complete your profile to continue",
        });
        navigate("/profile-setup");
      }
    }
  }, [isLoading, dashboardData, toast, navigate]);

  return (
    <div className="flex flex-1 pt-16">
      {/* Main Content */}
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">
            {isLoading ? "Dashboard" : 
              dashboardData?.user?.role === "founder" ? "Founder Dashboard" :
              dashboardData?.user?.role === "investor" ? "Investor Dashboard" :
              dashboardData?.user?.role === "mentor" ? "Mentor Dashboard" : 
              "Dashboard"
            }
          </h1>
          <p className="text-slate-500 mt-1">
            {isLoading 
              ? "Loading your dashboard..."
              : `Welcome back, ${dashboardData?.user?.name || 'User'}! ${
                  dashboardData?.user?.role === "founder" 
                    ? "Track your pitches and discover new opportunities." 
                    : dashboardData?.user?.role === "investor" 
                    ? "Discover promising startups and investment opportunities."
                    : dashboardData?.user?.role === "mentor"
                    ? "Connect with founders and help them grow their startups."
                    : "Explore the startup ecosystem."
                }`
            }
          </p>
        </div>

        {/* Quick Stats - Role specific */}
        {!isLoading && dashboardData?.user?.role === "founder" && (
          <div className="stats-grid">
            <StatsCard
              title="Your Pitches"
              value={dashboardData?.stats?.pitchCount || 0}
              icon="presentation-line"
              iconBgColor="bg-primary-100"
              iconTextColor="text-primary-600"
              description={`${dashboardData?.stats?.activePitches || 0} active, ${dashboardData?.stats?.draftPitches || 0} draft`}
            />
            
            <StatsCard
              title="Total Views"
              value={dashboardData?.stats?.totalViews || 0}
              icon="eye-line"
              iconBgColor="bg-secondary-100"
              iconTextColor="text-secondary-600"
              description={`+${dashboardData?.stats?.viewsGrowth || 0}% from last week`}
              trend={{ value: "+12%", isPositive: true }}
            />
            
            <StatsCard
              title="Connections"
              value={dashboardData?.stats?.connectionCount || 0}
              icon="user-add-line"
              iconBgColor="bg-green-100"
              iconTextColor="text-green-600"
              description={`+${dashboardData?.stats?.newConnections || 0} new this week`}
              trend={{ value: "+3", isPositive: true }}
            />
            
            <StatsCard
              title="Upcoming Pitches"
              value={dashboardData?.stats?.upcomingPitchCount || 0}
              icon="calendar-event-line"
              iconBgColor="bg-accent-100"
              iconTextColor="text-accent-500"
              description={dashboardData?.stats?.nextPitchDate || "None scheduled"}
            />
          </div>
        )}

        {/* Investor-specific stats */}
        {!isLoading && dashboardData?.user?.role === "investor" && (
          <div className="stats-grid">
            <StatsCard
              title="Investments"
              value={dashboardData?.stats?.investmentCount || 0}
              icon="money-dollar-circle-line"
              iconBgColor="bg-secondary-100"
              iconTextColor="text-secondary-600"
              description={`${dashboardData?.stats?.activeInvestments || 0} active investments`}
            />
            
            <StatsCard
              title="Pitches Reviewed"
              value={dashboardData?.stats?.reviewedPitchCount || 0}
              icon="file-list-3-line"
              iconBgColor="bg-primary-100"
              iconTextColor="text-primary-600"
              description={`${dashboardData?.stats?.newPitchesThisWeek || 0} new this week`}
              trend={{ value: "+5", isPositive: true }}
            />
            
            <StatsCard
              title="Connections"
              value={dashboardData?.stats?.connectionCount || 0}
              icon="user-add-line"
              iconBgColor="bg-green-100"
              iconTextColor="text-green-600"
              description={`+${dashboardData?.stats?.newConnections || 0} new this week`}
              trend={{ value: "+3", isPositive: true }}
            />
            
            <StatsCard
              title="Upcoming Pitches"
              value={dashboardData?.stats?.upcomingPitchCount || 0}
              icon="calendar-event-line"
              iconBgColor="bg-accent-100"
              iconTextColor="text-accent-500"
              description={dashboardData?.stats?.nextPitchDate || "None scheduled"}
            />
          </div>
        )}

        {/* Mentor-specific stats */}
        {!isLoading && dashboardData?.user?.role === "mentor" && (
          <div className="stats-grid">
            <StatsCard
              title="Mentees"
              value={dashboardData?.stats?.menteeCount || 0}
              icon="user-star-line"
              iconBgColor="bg-primary-100"
              iconTextColor="text-primary-600"
              description={`${dashboardData?.stats?.activeMentees || 0} active mentees`}
            />
            
            <StatsCard
              title="Sessions"
              value={dashboardData?.stats?.sessionCount || 0}
              icon="time-line"
              iconBgColor="bg-secondary-100"
              iconTextColor="text-secondary-600"
              description={`${dashboardData?.stats?.sessionHours || 0} total hours`}
              trend={{ value: "+2", isPositive: true }}
            />
            
            <StatsCard
              title="Connections"
              value={dashboardData?.stats?.connectionCount || 0}
              icon="user-add-line"
              iconBgColor="bg-green-100"
              iconTextColor="text-green-600"
              description={`+${dashboardData?.stats?.newConnections || 0} new this week`}
              trend={{ value: "+3", isPositive: true }}
            />
            
            <StatsCard
              title="Upcoming Sessions"
              value={dashboardData?.stats?.upcomingSessionCount || 0}
              icon="calendar-event-line"
              iconBgColor="bg-accent-100"
              iconTextColor="text-accent-500"
              description={dashboardData?.stats?.nextSessionDate || "None scheduled"}
            />
          </div>
        )}

        {/* Role-Specific Call to Action */}
        {!isLoading && dashboardData?.user?.role === "founder" && (
          <div className="bg-gradient-to-r from-primary-600 to-secondary-600 rounded-xl p-6 md:p-8 mb-8 text-white">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-bold">Ready to pitch your startup?</h2>
                <p className="mt-1 text-white/80">Create a compelling pitch and get feedback from mentors and investors.</p>
              </div>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="secondary" className="bg-white text-primary-600 hover:bg-white/90">
                    Submit New Pitch
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Create New Pitch</DialogTitle>
                    <DialogDescription>
                      Fill in the basic details to get started with your pitch
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 my-4">
                    <div>
                      <label htmlFor="pitch-title" className="block text-sm font-medium text-slate-700 mb-1">
                        Pitch Title
                      </label>
                      <Input 
                        id="pitch-title" 
                        placeholder="E.g., TaskFlow: Project Management Simplified"
                        value={pitchTitle}
                        onChange={(e) => setPitchTitle(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="pitch-category" className="block text-sm font-medium text-slate-700 mb-1">
                        Category
                      </label>
                      <Select value={pitchCategory} onValueChange={setPitchCategory}>
                        <SelectTrigger id="pitch-category">
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="SaaS">SaaS</SelectItem>
                          <SelectItem value="FinTech">FinTech</SelectItem>
                          <SelectItem value="HealthTech">HealthTech</SelectItem>
                          <SelectItem value="EdTech">EdTech</SelectItem>
                          <SelectItem value="AI">AI & Machine Learning</SelectItem>
                          <SelectItem value="E-commerce">E-commerce</SelectItem>
                          <SelectItem value="Climate Tech">Climate Tech</SelectItem>
                          <SelectItem value="IoT">Hardware & IoT</SelectItem>
                          <SelectItem value="Mobile Apps">Mobile Apps</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label htmlFor="pitch-desc" className="block text-sm font-medium text-slate-700 mb-1">
                        Pitch Description
                      </label>
                      <Textarea 
                        id="pitch-desc" 
                        rows={4} 
                        placeholder="Describe your startup idea in a few sentences..."
                        value={pitchDescription}
                        onChange={(e) => setPitchDescription(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Pitch Media
                      </label>
                      <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center cursor-pointer hover:bg-slate-50 transition-all">
                        <i className="ri-upload-cloud-line text-3xl text-slate-400 mb-2"></i>
                        <p className="text-sm text-slate-500">Click to upload or drag and drop</p>
                        <p className="text-xs text-slate-400 mt-1">PNG, JPG, GIF, MP4 or PDF (max. 10MB)</p>
                      </div>
                    </div>
                    
                    <div className="pt-4 border-t border-slate-200">
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Tags
                      </label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {pitchTags.map((tag, index) => (
                          <span key={index} className="bg-primary-100 text-primary-800 text-xs px-2.5 py-1 rounded-full flex items-center">
                            {tag} 
                            <button 
                              className="ml-1.5 text-primary-600 hover:text-primary-800"
                              onClick={() => handleRemoveTag(tag)}
                            >
                              &times;
                            </button>
                          </span>
                        ))}
                      </div>
                      <div className="flex">
                        <Input 
                          type="text" 
                          placeholder="Add a tag..." 
                          value={newTag}
                          onChange={(e) => setNewTag(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                          className="text-xs rounded-r-none"
                        />
                        <Button 
                          type="button" 
                          onClick={handleAddTag}
                          className="rounded-l-none"
                          variant="secondary"
                        >
                          Add
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button variant="outline" type="button" className="mr-2">
                      Cancel
                    </Button>
                    <Button type="button" onClick={handleNewPitchSubmit}>
                      Create Pitch
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        )}
        
        {!isLoading && dashboardData?.user?.role === "investor" && (
          <div className="bg-gradient-to-r from-secondary-600 to-accent-500 rounded-xl p-6 md:p-8 mb-8 text-white">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-bold">Looking for promising startups?</h2>
                <p className="mt-1 text-white/80">Discover innovative pitches and connect with talented founders.</p>
              </div>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="secondary" className="bg-white text-secondary-600 hover:bg-white/90">
                    Explore Pitches
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Discover Startups</DialogTitle>
                    <DialogDescription>
                      Find innovative startups matching your investment criteria
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 my-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Industries
                      </label>
                      <div className="flex flex-wrap gap-2">
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          FinTech
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          HealthTech
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          AI/ML
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          SaaS
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          EdTech
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Stage
                      </label>
                      <div className="flex flex-wrap gap-2">
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          Seed
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          Series A
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          Series B
                        </button>
                        <button className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200 text-xs px-3 py-1.5 rounded-full">
                          Growth
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button>Find Matches</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        )}
        
        {!isLoading && dashboardData?.user?.role === "mentor" && (
          <div className="bg-gradient-to-r from-accent-500 to-green-600 rounded-xl p-6 md:p-8 mb-8 text-white">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="mb-4 md:mb-0">
                <h2 className="text-xl font-bold">Ready to mentor startups?</h2>
                <p className="mt-1 text-white/80">Share your expertise and help founders succeed with their startups.</p>
              </div>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="secondary" className="bg-white text-accent-500 hover:bg-white/90">
                    Find Startups
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Mentor Startups</DialogTitle>
                    <DialogDescription>
                      Find startups that could benefit from your expertise
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 my-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Your Expertise
                      </label>
                      <div className="flex flex-wrap gap-2">
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          Product Development
                        </button>
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          Marketing
                        </button>
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          Fundraising
                        </button>
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          Scaling
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        Time Commitment
                      </label>
                      <div className="flex flex-wrap gap-2">
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          1-2 hours/week
                        </button>
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          3-5 hours/week
                        </button>
                        <button className="bg-accent-100 text-accent-800 hover:bg-accent-200 text-xs px-3 py-1.5 rounded-full">
                          Flexible
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button>Find Startups to Mentor</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        )}
        
        {/* Tabs Navigation */}
        <Tabs defaultValue="trending" className="mb-6" onValueChange={setActiveTab}>
          <TabsList className="border-b border-slate-200 w-full justify-start">
            <TabsTrigger value="trending" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
              Trending Pitches
            </TabsTrigger>
            <TabsTrigger value="following" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
              Following
            </TabsTrigger>
            <TabsTrigger value="your-pitches" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary-600">
              Your Pitches
            </TabsTrigger>
          </TabsList>
          
          {/* Tab Content: Trending Pitches */}
          <TabsContent value="trending" className="mt-6">
            {loadingTrending ? (
              <div className="text-center py-4 text-slate-500">Loading trending pitches...</div>
            ) : trendingPitches && (trendingPitches as any[]).length > 0 ? (
              <div className="pitch-card-grid">
                {(trendingPitches as any[]).map((pitch: any) => (
                  <PitchCard 
                    key={pitch.id}
                    id={pitch.id}
                    title={pitch.title}
                    description={pitch.description}
                    category={pitch.category}
                    imageSrc={pitch.imageSrc}
                    founderName={pitch.founder.name}
                    founderTitle={pitch.founder.title}
                    founderImage={pitch.founder.avatarUrl}
                    upvotes={pitch.upvotes}
                    comments={pitch.comments}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">No trending pitches available at the moment.</div>
            )}
          </TabsContent>
          
          {/* Tab Content: Following */}
          <TabsContent value="following" className="mt-6">
            <div className="bg-white rounded-lg border border-slate-200 p-5">
              <p className="text-center text-slate-600">You're not following any pitches yet.</p>
              <p className="text-center text-slate-500 text-sm mt-2">Explore trending pitches and follow the ones you like.</p>
              <div className="mt-4 flex justify-center">
                <Button onClick={() => setActiveTab("trending")}>
                  Explore Pitches
                </Button>
              </div>
            </div>
          </TabsContent>
          
          {/* Tab Content: Your Pitches */}
          <TabsContent value="your-pitches" className="mt-6">
            {loadingUserPitches ? (
              <div className="text-center py-4 text-slate-500">Loading your pitches...</div>
            ) : userPitches && (userPitches as any[]).length > 0 ? (
              <div className="space-y-6">
                {(userPitches as any[]).map((pitch: any) => (
                  <div key={pitch.id} className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-bold text-lg text-slate-800">{pitch.title}</h3>
                        <span className={`bg-${pitch.status === 'active' ? 'green' : 'yellow'}-100 text-${pitch.status === 'active' ? 'green' : 'yellow'}-800 text-xs font-medium px-2.5 py-1 rounded-full`}>
                          {pitch.status === 'active' ? 'Active' : 'Draft'}
                        </span>
                      </div>
                      
                      <p className="text-slate-600 mb-4">
                        {pitch.description}
                      </p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        <span className="bg-primary-100 text-primary-800 px-2.5 py-1 rounded-full text-xs">{pitch.category}</span>
                        {pitch.tags?.map((tag: string, index: number) => (
                          <span key={index} className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded-full text-xs">{tag}</span>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200">
                        <div className="flex items-center space-x-5">
                          <div className="flex items-center">
                            <i className="ri-eye-line text-slate-500 mr-1.5"></i>
                            <span className="text-slate-500 text-sm">{pitch.views || 0} views</span>
                          </div>
                          <div className="flex items-center">
                            <i className="ri-thumb-up-line text-slate-500 mr-1.5"></i>
                            <span className="text-slate-500 text-sm">{pitch.upvotes || 0} upvotes</span>
                          </div>
                          <div className="flex items-center">
                            <i className="ri-message-3-line text-slate-500 mr-1.5"></i>
                            <span className="text-slate-500 text-sm">{pitch.comments?.length || 0} comments</span>
                          </div>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" asChild>
                            <Link href={`/pitch/${pitch.id}`}>
                              View
                            </Link>
                          </Button>
                          <Button size="sm" variant="outline" asChild>
                            <Link href={`/pitch/${pitch.id}/edit`}>
                              Edit
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg border border-slate-200 p-8 text-center">
                <i className="ri-presentation-fill text-4xl text-slate-300 mb-2"></i>
                <h3 className="text-lg font-medium text-slate-800 mb-2">No pitches yet</h3>
                <p className="text-slate-500 mb-4">You haven't created any pitches yet. Create your first pitch to get feedback from mentors and investors.</p>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>Create Your First Pitch</Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Create New Pitch</DialogTitle>
                      <DialogDescription>
                        Fill in the basic details to get started with your pitch
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 my-4">
                      {/* Form fields as above */}
                    </div>
                    
                    <DialogFooter>
                      <Button variant="outline" type="button" className="mr-2">
                        Cancel
                      </Button>
                      <Button type="button" onClick={handleNewPitchSubmit}>
                        Create Pitch
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Live Rooms Section - Enhanced with Role-Specific Context */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-slate-800">
              {!isLoading && dashboardData?.user?.role === "investor" 
                ? "Startup Pitch Rooms" 
                : !isLoading && dashboardData?.user?.role === "mentor"
                ? "Mentor Sessions & Pitch Rooms"
                : "Live Pitch Rooms"}
            </h2>
            <Link href="/live-rooms" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
              View All <i className="ri-arrow-right-line ml-1"></i>
            </Link>
          </div>
          
          {/* Highlighted Live Video Room Section - Much more noticeable */}
          {!loadingLiveRooms && liveRooms && Array.isArray(liveRooms) && liveRooms.filter((room: any) => room.status === 'live').length > 0 && (
            <div className="mb-6 bg-gradient-to-r from-accent-500/10 to-secondary-500/10 p-4 rounded-xl border-2 border-accent-500/20">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-3">
                <h3 className="text-lg font-bold text-accent-800 flex items-center">
                  <span className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-2"></span>
                  Live Now
                </h3>
                <Link href={`/live-room/${liveRooms.find((room: any) => room.status === 'live')?.id}`}>
                  <Button className="mt-2 md:mt-0 bg-accent-500 hover:bg-accent-600">
                    <i className="ri-live-line mr-1"></i> Join Live Room
                  </Button>
                </Link>
              </div>
              
              <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-accent-200">
                {liveRooms.filter((room: any) => room.status === 'live').slice(0, 1).map((room: any) => (
                  <div key={room.id} className="flex flex-col md:flex-row gap-4 items-center">
                    <div className="w-full md:w-1/3 aspect-video bg-slate-200 rounded-lg overflow-hidden relative">
                      {room.thumbnailSrc ? (
                        <img 
                          src={room.thumbnailSrc} 
                          alt={room.title} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <img src="/live-pitch.svg" alt="Live Pitch" className="w-full h-full object-cover" />
                      )}
                      <div className="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full flex items-center">
                        <i className="ri-record-circle-fill mr-1 animate-pulse"></i> LIVE
                      </div>
                    </div>
                    
                    <div className="w-full md:w-2/3">
                      <h4 className="text-xl font-bold text-slate-800 mb-2">{room.title}</h4>
                      <div className="flex items-center mb-3">
                        <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden mr-2">
                          {room.presenter.avatarUrl ? (
                            <img 
                              src={room.presenter.avatarUrl} 
                              alt={room.presenter.name} 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <img 
                              src={`/avatars/founder-${room.presenter.id % 2 === 0 ? 2 : 1}.svg`} 
                              alt={room.presenter.name} 
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                        <span className="text-sm font-medium text-slate-700">
                          {room.presenter.name}
                        </span>
                        <span className="mx-2 text-slate-300">•</span>
                        <span className="text-sm text-slate-500">
                          <i className="ri-user-line mr-1"></i> {room.viewerCount || 0} viewers
                        </span>
                      </div>
                      
                      <p className="text-slate-600 mb-4 line-clamp-2">{room.description || 'Join this live pitch session to learn more about this startup and interact with the founder.'}</p>
                      
                      <Link href={`/live-room/${room.id}`}>
                        <Button className="w-full md:w-auto">
                          <i className="ri-live-line mr-1"></i> Join Live Room
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Regular Live Rooms List */}
          {loadingLiveRooms ? (
            <div className="text-center py-4 text-slate-500">Loading live rooms...</div>
          ) : liveRooms && liveRooms.length > 0 ? (
            <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {liveRooms.map((room: any) => (
                <LiveRoomCard 
                  key={room.id}
                  id={room.id}
                  title={room.title}
                  presenterName={room.presenter.name || "Anonymous"}
                  presenterImage={room.presenter.avatarUrl}
                  thumbnailSrc={room.thumbnailSrc}
                  viewers={room.viewerCount || 0}
                  status={room.status === "live" ? "live" : "upcoming"}
                  startTime={room.startTime}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg border border-slate-200 p-5 text-center">
              <p className="text-slate-600">No live pitches available at the moment.</p>
              <p className="text-slate-500 text-sm mt-2">
                {!isLoading && dashboardData?.user?.role === "founder" 
                  ? "Be the first to schedule a pitch session and showcase your startup!" 
                  : !isLoading && dashboardData?.user?.role === "investor"
                  ? "Check back later for live pitch sessions from promising startups."
                  : !isLoading && dashboardData?.user?.role === "mentor"
                  ? "Schedule a mentoring session or check back for live pitches."
                  : "Check back later or schedule your own live pitch session"
                }
              </p>
            </div>
          )}
        </div>
        
        {/* Mentors & Investors Section */}
        <div className="mt-10">
          <h2 className="text-xl font-bold text-slate-800 mb-4">Top Mentors & Investors</h2>
          {loadingMentorsInvestors ? (
            <div className="text-center py-4 text-slate-500">Loading...</div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Mentors */}
              <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Mentors</h3>
                <div className="space-y-4">
                  {(mentorsAndInvestors as any).mentors?.slice(0, 3).map((mentor: any) => (
                    <MentorCard 
                      key={mentor.id}
                      id={mentor.id}
                      name={mentor.name}
                      title={mentor.title}
                      company={mentor.company}
                      avatarUrl={mentor.avatarUrl}
                      expertise={mentor.expertise}
                      rating={mentor.rating}
                      reviewCount={mentor.reviewCount}
                    />
                  ))}
                  
                  <Button variant="outline" className="w-full mt-4" asChild>
                    <Link href="/mentors">View All Mentors</Link>
                  </Button>
                </div>
              </div>
              
              {/* Investors */}
              <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Investors</h3>
                <div className="space-y-4">
                  {(mentorsAndInvestors as any).investors?.slice(0, 3).map((investor: any) => (
                    <InvestorCard 
                      key={investor.id}
                      id={investor.id}
                      name={investor.name}
                      title={investor.title}
                      firm={investor.firm}
                      avatarUrl={investor.avatarUrl}
                      interests={investor.interests}
                    />
                  ))}
                  
                  <Button variant="outline" className="w-full mt-4" asChild>
                    <Link href="/investors">View All Investors</Link>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}