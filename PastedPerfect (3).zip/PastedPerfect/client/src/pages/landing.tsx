import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";

export default function Landing() {
  // Set document title
  useEffect(() => {
    document.title = "Startup Arena | Launch your startup with community support";
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="container mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <img src="/logo.svg" alt="Startup Arena Logo" className="w-10 h-10" />
            <span className="text-xl font-bold text-slate-800">Startup Arena</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-slate-600 hover:text-primary-600 transition-colors">Features</a>
            <a href="#how-it-works" className="text-slate-600 hover:text-primary-600 transition-colors">How It Works</a>
            <a href="#success-stories" className="text-slate-600 hover:text-primary-600 transition-colors">Success Stories</a>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" asChild>
              <Link href="/auth/login">Log in</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/register">Sign up</Link>
            </Button>
          </div>
        </div>
      </nav>
      
      {/* Hero Section */}
      <section className="container mx-auto px-6 pt-20 pb-24">
        <div className="flex flex-col-reverse md:flex-row items-center">
          <div className="md:w-1/2 mt-10 md:mt-0">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-800 leading-tight">
              Where Great <span className="gradient-text">Startup Ideas</span> Meet Their Perfect Audience
            </h1>
            <p className="mt-6 text-lg text-slate-600 max-w-lg">
              Pitch your startup idea, get valuable feedback from mentors, connect with investors, and build your network—all in one platform.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button size="lg" asChild>
                <Link href="/auth/register">Start Your Journey</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="#features">Learn More</a>
              </Button>
            </div>
            <div className="mt-8 flex items-center space-x-6">
              <div className="flex -space-x-2">
                <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 ring-2 ring-white">JD</div>
                <div className="w-8 h-8 rounded-full bg-secondary-100 flex items-center justify-center text-secondary-600 ring-2 ring-white">SK</div>
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 ring-2 ring-white">LP</div>
                <div className="w-8 h-8 rounded-full bg-accent-100 flex items-center justify-center text-accent-500 ring-2 ring-white">+</div>
              </div>
              <p className="text-sm text-slate-600">
                Join <span className="font-semibold">5,000+</span> founders already pitching
              </p>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full bg-gradient-to-br from-primary-500/20 to-secondary-600/20 absolute -z-10"></div>
              <img 
                src="/hero-image.svg" 
                alt="Startup pitch presentation" 
                className="rounded-lg shadow-lg max-w-full" 
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section id="features" className="bg-slate-50 py-20">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-800">Everything You Need to Launch Your Startup</h2>
            <p className="mt-4 text-lg text-slate-600">
              Startup Arena provides all the tools and connections you need to take your idea from concept to launch.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-14 h-14 rounded-lg bg-primary-100 flex items-center justify-center mb-6">
                <i className="ri-presentation-line text-2xl text-primary-600"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Pitch Showcase</h3>
              <p className="text-slate-600">
                Create compelling pitch profiles with text, images, and video to showcase your startup idea to the world.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-14 h-14 rounded-lg bg-secondary-100 flex items-center justify-center mb-6">
                <i className="ri-live-line text-2xl text-secondary-600"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Live Pitch Rooms</h3>
              <p className="text-slate-600">
                Present your idea in real-time with video streams and get instant feedback from potential investors and mentors.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-14 h-14 rounded-lg bg-green-100 flex items-center justify-center mb-6">
                <i className="ri-user-star-line text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Mentor Network</h3>
              <p className="text-slate-600">
                Connect with experienced entrepreneurs and industry experts who can provide valuable guidance and insights.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-14 h-14 rounded-lg bg-accent-100 flex items-center justify-center mb-6">
                <i className="ri-money-dollar-circle-line text-2xl text-accent-500"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Investor Access</h3>
              <p className="text-slate-600">
                Get your idea in front of verified investors looking for promising startups across various industries and stages.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-14 h-14 rounded-lg bg-purple-100 flex items-center justify-center mb-6">
                <i className="ri-trophy-line text-2xl text-purple-600"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Startup Challenges</h3>
              <p className="text-slate-600">
                Participate in themed challenges with prizes, recognition, and opportunities to fast-track your idea.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-14 h-14 rounded-lg bg-red-100 flex items-center justify-center mb-6">
                <i className="ri-nft-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Idea Protection</h3>
              <p className="text-slate-600">
                Optional NFT minting for your startup idea to establish timestamp proof of concept and protect your IP.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-800">How Startup Arena Works</h2>
            <p className="mt-4 text-lg text-slate-600">
              Follow these simple steps to start your journey from idea to successful startup
            </p>
          </div>
          
          <div className="relative max-w-4xl mx-auto">
            {/* Progress line */}
            <div className="absolute top-16 left-16 right-16 h-0.5 bg-primary-100 hidden md:block"></div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <div className="relative text-center">
                <div className="w-12 h-12 rounded-full bg-primary-600 flex items-center justify-center text-white text-xl font-bold mx-auto z-10 relative">
                  1
                </div>
                <h3 className="text-xl font-bold text-slate-800 mt-4 mb-2">Create Your Pitch</h3>
                <p className="text-slate-600">
                  Sign up, describe your startup idea, and create a compelling pitch with text, images, and videos.
                </p>
              </div>
              
              <div className="relative text-center">
                <div className="w-12 h-12 rounded-full bg-primary-600 flex items-center justify-center text-white text-xl font-bold mx-auto z-10 relative">
                  2
                </div>
                <h3 className="text-xl font-bold text-slate-800 mt-4 mb-2">Get Feedback</h3>
                <p className="text-slate-600">
                  Share your pitch with the community, receive upvotes, and get valuable constructive feedback.
                </p>
              </div>
              
              <div className="relative text-center">
                <div className="w-12 h-12 rounded-full bg-primary-600 flex items-center justify-center text-white text-xl font-bold mx-auto z-10 relative">
                  3
                </div>
                <h3 className="text-xl font-bold text-slate-800 mt-4 mb-2">Connect & Grow</h3>
                <p className="text-slate-600">
                  Present live pitches, connect with mentors and investors, and take your startup to the next level.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-16">
            <Button size="lg" asChild>
              <Link href="/auth/register">Join Startup Arena</Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* Success Stories */}
      <section id="success-stories" className="py-20 bg-slate-50">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-800">Success Stories</h2>
            <p className="mt-4 text-lg text-slate-600">
              Meet the startups that found success through Startup Arena
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <img 
                src="/success-story-1.svg" 
                alt="TutorAI Team" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-800 mb-2">TutorAI</h3>
                <p className="text-slate-600 mb-4">
                  Raised $2.5M seed round after connecting with investors through Startup Arena. Now serving 50,000+ students worldwide.
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden">
                    <img 
                      src="/avatars/founder-1.svg" 
                      alt="Sarah Johnson" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="ml-3">
                    <p className="font-medium text-slate-800">Sarah Johnson</p>
                    <p className="text-sm text-slate-500">Founder & CEO</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <img 
                src="/success-story-2.svg" 
                alt="HealthTrack Team" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-800 mb-2">HealthTrack</h3>
                <p className="text-slate-600 mb-4">
                  Found their technical co-founder through Startup Arena's mentor network. Recently launched their app with 30,000 users.
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden">
                    <img 
                      src="/avatars/founder-2.svg" 
                      alt="David Kim" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="ml-3">
                    <p className="font-medium text-slate-800">David Kim</p>
                    <p className="text-sm text-slate-500">Co-founder</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <img 
                src="/success-story-3.svg" 
                alt="EcoCharge Team" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-800 mb-2">EcoCharge</h3>
                <p className="text-slate-600 mb-4">
                  Refined their business model through feedback from Startup Arena challenges. Now in 200+ retail stores nationwide.
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden">
                    <img 
                      src="/avatars/founder-3.svg" 
                      alt="Alex Chen" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="ml-3">
                    <p className="font-medium text-slate-800">Alex Chen</p>
                    <p className="text-sm text-slate-500">Founder & CEO</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Launch Your Startup Journey?</h2>
          <p className="text-lg text-white/80 max-w-2xl mx-auto mb-10">
            Join thousands of founders who are turning their ideas into reality with the help of Startup Arena.
          </p>
          <Button size="lg" variant="secondary" className="bg-white text-primary-600 hover:bg-white/90" asChild>
            <Link href="/auth/register">Get Started Now</Link>
          </Button>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <img src="/logo.svg" alt="Startup Arena Logo" className="w-10 h-10" />
                <span className="text-xl font-bold">Startup Arena</span>
              </div>
              <p className="text-slate-400">
                The platform where startups thrive through community support, mentorship, and investor connections.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-4">Platform</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">How it Works</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Success Stories</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Pitch Guide</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Startup Resources</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Help Center</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
            <p className="text-slate-500">© 2023 Startup Arena. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <i className="ri-linkedin-fill text-xl"></i>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <i className="ri-instagram-fill text-xl"></i>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
