import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow 
} from "@/components/ui/table";
import { getInitials } from "@/lib/utils";
import MobileNav from "@/components/common/mobile-nav";

export default function Leaderboard() {
  const [timeframe, setTimeframe] = useState("all-time");

  // Fetch leaderboard data
  const { data: leaderboard, isLoading, error } = useQuery({
    queryKey: ['/api/leaderboard'],
  });

  // Set document title
  useEffect(() => {
    document.title = "Leaderboard | Startup Arena";
  }, []);

  // Get rank badge style based on position
  const getRankBadgeStyle = (rank: number) => {
    if (rank === 1) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    if (rank === 2) return "bg-slate-100 text-slate-800 border-slate-200";
    if (rank === 3) return "bg-amber-100 text-amber-800 border-amber-200";
    return "bg-slate-50 text-slate-600 border-slate-200";
  };

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Startup Leaderboard</h1>
          <p className="text-slate-500 mt-1">See the top-performing startups based on engagement and upvotes</p>
        </div>
        
        {/* Featured top 3 */}
        {!isLoading && !error && leaderboard && leaderboard.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {leaderboard.slice(0, 3).map((startup: any, index: number) => (
              <Card key={startup.id} className={`bg-gradient-to-b ${index === 0 ? 'from-yellow-50 to-white border-yellow-200' : index === 1 ? 'from-slate-50 to-white border-slate-200' : 'from-amber-50 to-white border-amber-200'}`}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start mb-6">
                    <Badge className={`text-lg px-3 py-1 border ${getRankBadgeStyle(index + 1)}`}>
                      #{index + 1}
                    </Badge>
                    <div className="flex items-center space-x-1 text-slate-600">
                      <i className="ri-star-fill text-yellow-500"></i>
                      <span className="font-medium">{Math.floor(startup.score)}</span>
                    </div>
                  </div>
                  
                  <h3 className="font-bold text-xl text-slate-800 mb-2 line-clamp-1">{startup.title}</h3>
                  <p className="text-slate-600 text-sm mb-4 line-clamp-2">
                    {startup.description}
                  </p>
                  
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar>
                      <AvatarImage src={startup.founder.avatarUrl} alt={startup.founder.name} />
                      <AvatarFallback className="bg-primary-100 text-primary-700">
                        {getInitials(startup.founder.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium text-slate-800">{startup.founder.name}</p>
                      <p className="text-xs text-slate-500">Founder</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-1">
                      <i className="ri-thumb-up-line text-primary-500"></i>
                      <span>{startup.upvotes}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <i className="ri-eye-line text-secondary-500"></i>
                      <span>{startup.views}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <i className="ri-message-2-line text-green-500"></i>
                      <span>{startup.comments}</span>
                    </div>
                    
                    <Button variant="outline" size="sm" className="ml-auto" asChild>
                      <Link href={`/pitch/${startup.id}`}>
                        View Pitch
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        
        {/* Timeframe filter */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-bold text-slate-800">All Rankings</h2>
          <div className="flex space-x-2">
            <Button
              variant={timeframe === "all-time" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("all-time")}
            >
              All Time
            </Button>
            <Button
              variant={timeframe === "this-month" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("this-month")}
            >
              This Month
            </Button>
            <Button
              variant={timeframe === "this-week" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("this-week")}
            >
              This Week
            </Button>
          </div>
        </div>
        
        {/* Leaderboard table */}
        {isLoading ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">Loading leaderboard data...</p>
            </CardContent>
          </Card>
        ) : error ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-red-500">Error loading leaderboard. Please try again.</p>
              <Button variant="outline" className="mt-4">
                Retry
              </Button>
            </CardContent>
          </Card>
        ) : leaderboard && leaderboard.length > 0 ? (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Rank</TableHead>
                    <TableHead>Startup</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-center">Upvotes</TableHead>
                    <TableHead className="text-center">Views</TableHead>
                    <TableHead className="text-center">Comments</TableHead>
                    <TableHead className="text-center">Score</TableHead>
                    <TableHead className="w-24"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leaderboard.map((startup: any) => (
                    <TableRow key={startup.id}>
                      <TableCell className="font-bold text-center">
                        <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full ${
                          startup.rank <= 3 
                            ? `${startup.rank === 1 ? 'bg-yellow-100 text-yellow-800' : startup.rank === 2 ? 'bg-slate-100 text-slate-700' : 'bg-amber-100 text-amber-800'}`
                            : 'bg-slate-50 text-slate-700'
                        }`}>
                          {startup.rank}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={startup.founder.avatarUrl} alt={startup.founder.name} />
                            <AvatarFallback className="bg-primary-100 text-primary-700 text-xs">
                              {getInitials(startup.founder.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-slate-800">{startup.title}</p>
                            <p className="text-xs text-slate-500">{startup.founder.name}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-slate-50">
                          {startup.category}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center font-medium">{startup.upvotes}</TableCell>
                      <TableCell className="text-center">{startup.views}</TableCell>
                      <TableCell className="text-center">{startup.comments}</TableCell>
                      <TableCell className="text-center font-bold">{Math.floor(startup.score)}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/pitch/${startup.id}`}>
                            View
                          </Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No leaderboard data available at the moment.</p>
            </CardContent>
          </Card>
        )}
        
        {/* Leaderboard info */}
        <div className="mt-10 bg-slate-50 rounded-lg border border-slate-200 p-6">
          <h3 className="text-lg font-bold text-slate-800 mb-4">How Scores Are Calculated</h3>
          <p className="text-slate-600 mb-4">
            The startup leaderboard ranks pitches based on a weighted scoring system that considers:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 border border-slate-200">
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center mr-2">
                  <i className="ri-thumb-up-line text-primary-600"></i>
                </div>
                <p className="font-medium text-slate-800">Upvotes</p>
              </div>
              <p className="text-sm text-slate-600">
                Each upvote adds 10 points to your score
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-slate-200">
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 rounded-full bg-secondary-100 flex items-center justify-center mr-2">
                  <i className="ri-message-2-line text-secondary-600"></i>
                </div>
                <p className="font-medium text-slate-800">Comments</p>
              </div>
              <p className="text-sm text-slate-600">
                Each comment adds 5 points to your score
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-slate-200">
              <div className="flex items-center mb-2">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                  <i className="ri-eye-line text-green-600"></i>
                </div>
                <p className="font-medium text-slate-800">Views</p>
              </div>
              <p className="text-sm text-slate-600">
                Each view adds 0.5 points to your score
              </p>
            </div>
          </div>
          
          <div className="text-center mt-6">
            <p className="text-slate-500 mb-4">Want to improve your ranking?</p>
            <Button asChild>
              <Link href="/pitch/new">
                Submit a New Pitch
              </Link>
            </Button>
          </div>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}
