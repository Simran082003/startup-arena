import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import MentorCard from "@/components/ui/mentor-card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import MobileNav from "@/components/common/mobile-nav";

export default function Mentors() {
  const [searchQuery, setSearchQuery] = useState("");
  const [expertiseFilter, setExpertiseFilter] = useState("all");
  const [sortBy, setSortBy] = useState("rating");

  // Fetch mentors
  const { data: mentors, isLoading, error } = useQuery({
    queryKey: ['/api/mentors'],
  });

  // Filter and sort mentors
  const filteredMentors = mentors ? mentors.filter((mentor: any) => {
    // Search filter
    const matchesSearch = searchQuery === "" || 
      mentor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mentor.expertise.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mentor.bio.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Expertise filter
    const matchesExpertise = expertiseFilter === "all" || 
      mentor.expertise.toLowerCase().includes(expertiseFilter.toLowerCase());
    
    return matchesSearch && matchesExpertise;
  }) : [];

  // Sort mentors
  const sortedMentors = [...filteredMentors].sort((a: any, b: any) => {
    if (sortBy === "rating") {
      return b.rating - a.rating;
    } else if (sortBy === "reviews") {
      return b.reviewCount - a.reviewCount;
    } else if (sortBy === "name") {
      return a.name.localeCompare(b.name);
    }
    return 0;
  });

  // Extract unique expertise areas for filter options
  const expertiseAreas = mentors ? Array.from(new Set(mentors.map((mentor: any) => mentor.expertise.split(' • ')[1] || mentor.expertise))) : [];

  // Set document title
  useEffect(() => {
    document.title = "Mentors | Startup Arena";
  }, []);

  return (
    <div className="flex flex-1 pt-16">
      <main className="flex-1 p-6 lg:ml-64 overflow-y-auto pb-20 lg:pb-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Mentors</h1>
          <p className="text-slate-500 mt-1">Connect with experienced mentors who can help guide your startup journey</p>
        </div>
        
        {/* Filters and search */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="search" className="block text-sm font-medium text-slate-700 mb-1">
                Search
              </label>
              <Input
                id="search"
                placeholder="Search by name or expertise..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div>
              <label htmlFor="expertise" className="block text-sm font-medium text-slate-700 mb-1">
                Expertise
              </label>
              <Select
                value={expertiseFilter}
                onValueChange={setExpertiseFilter}
              >
                <SelectTrigger id="expertise">
                  <SelectValue placeholder="Filter by expertise" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Expertise Areas</SelectItem>
                  {expertiseAreas.map((area: string) => (
                    <SelectItem key={area} value={area}>{area}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label htmlFor="sort" className="block text-sm font-medium text-slate-700 mb-1">
                Sort By
              </label>
              <Select
                value={sortBy}
                onValueChange={setSortBy}
              >
                <SelectTrigger id="sort">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Highest Rating</SelectItem>
                  <SelectItem value="reviews">Most Reviews</SelectItem>
                  <SelectItem value="name">Name (A-Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Mentors grid */}
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-slate-500">Loading mentors...</p>
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-red-500">Error loading mentors. Please try again.</p>
              <Button variant="outline" className="mt-4">
                Retry
              </Button>
            </CardContent>
          </Card>
        ) : sortedMentors.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sortedMentors.map((mentor: any) => (
              <MentorCard
                key={mentor.id}
                id={mentor.id}
                name={mentor.name}
                avatarSrc={mentor.avatarUrl}
                title={mentor.title}
                expertise={mentor.expertise}
                bio={mentor.bio}
                rating={mentor.rating}
                reviewCount={mentor.reviewCount}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-slate-500">No mentors found matching your filters.</p>
              <Button variant="outline" className="mt-4" onClick={() => {
                setSearchQuery("");
                setExpertiseFilter("all");
              }}>
                Clear Filters
              </Button>
            </CardContent>
          </Card>
        )}
        
        {/* Feature highlight */}
        <div className="mt-12 bg-gradient-to-r from-primary-600 to-secondary-600 rounded-xl p-8 text-white">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold mb-4">Become a Mentor</h2>
            <p className="text-white/90 mb-6">
              Are you an experienced entrepreneur, industry expert, or investor? Share your knowledge and help the next generation of founders succeed.
            </p>
            <Button variant="secondary" className="bg-white text-primary-600 hover:bg-white/90">
              Apply to Become a Mentor
            </Button>
          </div>
        </div>
        
        {/* Mentorship benefits */}
        <div className="mt-12">
          <h2 className="text-xl font-bold text-slate-800 mb-6">Benefits of Mentorship</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-12 h-12 rounded-lg bg-primary-100 flex items-center justify-center mb-4">
                <i className="ri-lightbulb-line text-xl text-primary-600"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Expert Guidance</h3>
              <p className="text-slate-600">
                Get personalized advice from experienced professionals who have been where you are.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-12 h-12 rounded-lg bg-secondary-100 flex items-center justify-center mb-4">
                <i className="ri-user-star-line text-xl text-secondary-600"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Network Expansion</h3>
              <p className="text-slate-600">
                Tap into your mentor's professional network for introductions to key industry contacts.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg border border-slate-200">
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-4">
                <i className="ri-rocket-line text-xl text-green-600"></i>
              </div>
              <h3 className="font-bold text-slate-800 mb-2">Accelerated Growth</h3>
              <p className="text-slate-600">
                Avoid common pitfalls and learn from others' experiences to grow your startup faster.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}
