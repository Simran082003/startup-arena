import { cn } from "@/lib/utils";
import { Button } from "./button";
import { Badge } from "./badge";

interface InvestorCardProps {
  id: number;
  name: string;
  avatarUrl?: string;
  title: string;
  firm: string;
  bio?: string;
  interests: string[];
  className?: string;
}

export function InvestorCard({
  id,
  name,
  avatarUrl,
  title,
  firm,
  bio = "Investor looking for promising startups.",
  interests,
  className,
}: InvestorCardProps) {
  return (
    <div className={cn("bg-white rounded-lg border border-slate-200 shadow-sm p-5", className)}>
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-14 h-14 rounded-full bg-slate-200 overflow-hidden">
          {avatarUrl ? (
            <img src={avatarUrl} alt={name} className="w-full h-full object-cover" />
          ) : (
            <img src={`/avatars/investor-${(id % 3) + 1}.svg`} alt={name} className="w-full h-full object-cover" />
          )}
        </div>
        <div>
          <h3 className="font-bold text-slate-800">{name}</h3>
          <p className="text-sm text-secondary-600">Investor • {title}</p>
        </div>
      </div>
      
      <p className="text-sm text-slate-600 mb-4">
        {bio}
      </p>
      
      <div className="flex flex-wrap gap-2 mb-4">
        {interests.map((interest, index) => (
          <Badge key={index} variant="secondary" className="bg-slate-100 text-slate-700 hover:bg-slate-200">
            {interest}
          </Badge>
        ))}
      </div>
      
      <Button
        variant="outline"
        className="w-full border-secondary-600 text-secondary-600 hover:bg-secondary-50"
      >
        Connect
      </Button>
    </div>
  );
}

export default InvestorCard;
