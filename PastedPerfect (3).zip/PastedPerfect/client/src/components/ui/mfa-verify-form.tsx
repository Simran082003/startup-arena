import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

// Schema for MFA verification code
const mfaSchema = z.object({
  token: z.string().min(6, "Verification code must be at least 6 digits").max(8)
});

type MfaFormValues = z.infer<typeof mfaSchema>;

interface MfaVerifyFormProps {
  onCancel: () => void;
  onSuccess: () => void;
}

export function MfaVerifyForm({ onCancel, onSuccess }: MfaVerifyFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // MFA verification form
  const mfaForm = useForm<MfaFormValues>({
    resolver: zodResolver(mfaSchema),
    defaultValues: {
      token: ""
    }
  });
  
  // Handle MFA verification submission
  const onMfaSubmit = async (data: MfaFormValues) => {
    setIsSubmitting(true);
    
    try {
      // Verify MFA token
      await apiRequest("POST", "/api/auth/login-mfa", data);
      
      // Invalidate the query to refresh user data
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Verification successful",
        description: "You have been authenticated successfully.",
      });
      
      onSuccess();
      navigate("/dashboard");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Verification failed",
        description: "Invalid verification code. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Two-Factor Authentication</CardTitle>
        <CardDescription>
          Enter the verification code from your authenticator app
        </CardDescription>
      </CardHeader>
      
      <Form {...mfaForm}>
        <form onSubmit={mfaForm.handleSubmit(onMfaSubmit)}>
          <CardContent className="space-y-6 pt-6">
            <FormField
              control={mfaForm.control}
              name="token"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Verification Code</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter 6-digit code" 
                      className="text-center text-lg tracking-wider font-mono"
                      autoComplete="one-time-code"
                      inputMode="numeric"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                  Verifying...
                </>
              ) : "Verify"}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}