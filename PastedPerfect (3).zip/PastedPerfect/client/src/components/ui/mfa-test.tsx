import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function MfaTestButton() {
  const [isLoading, setIsLoading] = useState(false);
  const [testUser, setTestUser] = useState<{
    username: string;
    password: string;
    mfaEnabled: boolean;
  } | null>(null);
  const { toast } = useToast();

  const createTestUser = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/auth/mfa/test-setup");
      const data = await response.json();
      
      setTestUser({
        username: data.username,
        password: data.password,
        mfaEnabled: data.mfaEnabled
      });
      
      toast({
        title: "Test MFA User Created",
        description: "You can now test the MFA login flow with this user.",
      });
    } catch (error) {
      console.error("Error creating test MFA user:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create test MFA user."
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      {!testUser ? (
        <Button 
          onClick={createTestUser}
          disabled={isLoading}
        >
          {isLoading ? "Creating Test User..." : "Create MFA Test User"}
        </Button>
      ) : (
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Test MFA User Created</CardTitle>
            <CardDescription>
              Use these credentials to test the MFA login flow
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="font-semibold">Username:</p>
              <p className="font-mono bg-slate-100 p-2 rounded">{testUser.username}</p>
            </div>
            <div>
              <p className="font-semibold">Password:</p>
              <p className="font-mono bg-slate-100 p-2 rounded">{testUser.password}</p>
            </div>
            <div>
              <p className="font-semibold">MFA Enabled:</p>
              <p className="font-mono bg-slate-100 p-2 rounded">{testUser.mfaEnabled ? "Yes" : "No"}</p>
            </div>
            <p className="text-sm text-slate-500 mt-4">
              When you log in with these credentials, you will be prompted for an MFA code.
              The test MFA code is always <span className="font-mono font-semibold">123456</span> for testing purposes.
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              variant="outline" 
              onClick={() => setTestUser(null)}
              className="w-full"
            >
              Reset
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}