import { cn } from "@/lib/utils";
import { Button } from "./button";

interface MentorCardProps {
  id: number;
  name: string;
  avatarUrl?: string;
  title: string;
  company?: string;
  expertise: string;
  bio?: string;
  rating: number;
  reviewCount: number;
  className?: string;
}

export function MentorCard({
  id,
  name,
  avatarUrl,
  title,
  company,
  expertise,
  bio = "Experienced mentor helping startups succeed.",
  rating,
  reviewCount,
  className,
}: MentorCardProps) {
  return (
    <div className={cn("bg-white rounded-lg border border-slate-200 shadow-sm p-5", className)}>
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-14 h-14 rounded-full bg-slate-200 overflow-hidden">
          {avatarUrl ? (
            <img src={avatarUrl} alt={name} className="w-full h-full object-cover" />
          ) : (
            <img src={`/avatars/mentor-${(id % 3) + 1}.svg`} alt={name} className="w-full h-full object-cover" />
          )}
        </div>
        <div>
          <h3 className="font-bold text-slate-800">{name}</h3>
          <p className="text-sm text-primary-600">Mentor • {expertise}</p>
        </div>
      </div>
      
      <p className="text-sm text-slate-600 mb-4">
        {bio}
      </p>
      
      <div className="flex items-center space-x-2 mb-4">
        <i className="ri-star-fill text-yellow-400"></i>
        <span className="font-medium text-slate-700">{rating.toFixed(1)}</span>
        <span className="text-sm text-slate-500">({reviewCount} reviews)</span>
      </div>
      
      <Button
        variant="outline"
        className="w-full border-primary-600 text-primary-600 hover:bg-primary-50"
      >
        Request Mentoring
      </Button>
    </div>
  );
}

export default MentorCard;
