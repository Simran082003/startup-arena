import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconBgColor: string;
  iconTextColor: string;
  description?: string;
  trend?: {
    value: string;
    isPositive?: boolean;
  };
  className?: string;
}

export function StatsCard({
  title,
  value,
  icon,
  iconBgColor,
  iconTextColor,
  description,
  trend,
  className,
}: StatsCardProps) {
  return (
    <div className={cn("bg-white rounded-lg p-6 border border-slate-200 shadow-sm", className)}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-slate-500">{title}</h3>
        <div className={cn(
          "w-10 h-10 rounded-full flex items-center justify-center",
          iconBgColor
        )}>
          <i className={cn(`ri-${icon}`, iconTextColor, "text-lg")}></i>
        </div>
      </div>
      
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      
      {description && (
        <p className={cn(
          "text-sm mt-1",
          trend?.isPositive !== undefined 
            ? trend.isPositive
              ? "text-green-600"
              : "text-red-600"
            : "text-slate-500"
        )}>
          {description}
        </p>
      )}
    </div>
  );
}

export default StatsCard;
