import { Link } from "wouter";
import { cn, getInitials, truncateText } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface PitchCardProps {
  id: number;
  title: string;
  description: string;
  category: string;
  imageSrc?: string;
  founderName: string;
  founderTitle: string;
  founderImage?: string;
  upvotes: number;
  comments: number;
  isDetailed?: boolean;
  className?: string;
}

export function PitchCard({
  id,
  title,
  description,
  category,
  imageSrc,
  founderName,
  founderTitle,
  founderImage,
  upvotes,
  comments,
  isDetailed = false,
  className,
}: PitchCardProps) {
  const { toast } = useToast();
  const [upvoteCount, setUpvoteCount] = useState(upvotes);
  const [hasUpvoted, setHasUpvoted] = useState(false);

  const getCategoryColor = (category: string) => {
    const categories: Record<string, string> = {
      "EdTech": "bg-primary-100 text-primary-800",
      "HealthTech": "bg-secondary-100 text-secondary-800",
      "FinTech": "bg-green-100 text-green-800",
      "CleanTech": "bg-blue-100 text-blue-800",
      "Climate Tech": "bg-green-100 text-green-800",
      "AI": "bg-purple-100 text-purple-800",
      "IoT": "bg-orange-100 text-orange-800",
      "SaaS": "bg-indigo-100 text-indigo-800",
      "Blockchain": "bg-cyan-100 text-cyan-800",
      "E-commerce": "bg-pink-100 text-pink-800",
      "Mobile Apps": "bg-yellow-100 text-yellow-800",
      "Hardware": "bg-red-100 text-red-800",
    };
    
    return categories[category] || "bg-slate-100 text-slate-800";
  };

  const handleUpvote = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (hasUpvoted) return;
    
    try {
      await apiRequest('POST', `/api/pitches/${id}/upvote`, {});
      setUpvoteCount(prev => prev + 1);
      setHasUpvoted(true);
      toast({
        title: "Upvoted!",
        description: "You have successfully upvoted this pitch.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "You must be logged in to upvote.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className={cn("bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden", className)}>
      <div className="relative h-40 bg-slate-100">
        {imageSrc ? (
          <img src={imageSrc} alt={`${title} visual`} className="w-full h-full object-cover" />
        ) : (
          <img src="/pitch-thumbnail.svg" alt={`${title} visual`} className="w-full h-full object-cover" />
        )}
        <div className={cn("category-badge", getCategoryColor(category))}>
          {category}
        </div>
      </div>
      
      <div className="p-5">
        <Link href={`/pitch/${id}`}>
          <h3 className="font-bold text-lg text-slate-800 mb-1 hover:text-primary-600 transition-colors cursor-pointer">
            {title}
          </h3>
        </Link>
        
        <p className="text-slate-500 text-sm line-clamp-2 mb-4">
          {truncateText(description, isDetailed ? 200 : 100)}
        </p>
        
        <div className="flex items-center space-x-3 mb-4">
          {founderImage ? (
            <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden">
              <img src={founderImage} alt={founderName} className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden">
              <img src={`/avatars/founder-${id % 2 === 0 ? 2 : 1}.svg`} alt={founderName} className="w-full h-full object-cover" />
            </div>
          )}
          <div>
            <p className="text-sm font-medium text-slate-700">{founderName}</p>
            <p className="text-xs text-slate-500">{founderTitle}</p>
          </div>
        </div>
        
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <div className="flex items-center space-x-4">
            <button 
              className={cn(
                "flex items-center space-x-1 hover:text-primary-600 transition-colors",
                hasUpvoted ? "text-primary-600" : "text-slate-500"
              )}
              onClick={handleUpvote}
            >
              <i className={`ri-thumb-${hasUpvoted ? 'up-fill' : 'up-line'}`}></i>
              <span className="text-xs font-medium">{upvoteCount}</span>
            </button>
            
            <Link href={`/pitch/${id}#comments`}>
              <button className="flex items-center space-x-1 text-slate-500 hover:text-primary-600 transition-colors">
                <i className="ri-chat-1-line"></i>
                <span className="text-xs font-medium">{comments}</span>
              </button>
            </Link>
          </div>
          
          <Link href={`/pitch/${id}`}>
            <button className="text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors">
              View Details
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default PitchCard;
