import { cn, formatTime } from "@/lib/utils";
import { Link } from "wouter";

interface LiveRoomCardProps {
  id: number;
  title: string;
  presenterName: string;
  presenterImage?: string;
  thumbnailSrc?: string;
  viewers: number;
  status: "live" | "upcoming";
  startTime?: string | Date;
  className?: string;
}

export function LiveRoomCard({
  id,
  title,
  presenterName,
  presenterImage,
  thumbnailSrc,
  viewers,
  status,
  startTime,
  className,
}: LiveRoomCardProps) {
  // Calculate time until the upcoming stream starts
  const getTimeUntil = () => {
    if (!startTime) return "";
    
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = start.getTime() - now.getTime();
    
    if (diffMs <= 0) return "Starting now";
    
    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${diffHrs}h ${diffMins}m`;
  };

  return (
    <div className={cn(
      "bg-white rounded-lg border shadow-sm overflow-hidden relative",
      status === "live" ? "border-red-200" : "border-slate-200",
      className
    )}>
      {status === "live" && (
        <div className="live-badge">
          <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
          <span>LIVE NOW</span>
        </div>
      )}
      
      {status === "upcoming" && (
        <div className="absolute top-3 left-3 bg-accent-500 text-white text-xs font-medium px-2 py-1 rounded-full z-10">
          <span>UPCOMING</span>
        </div>
      )}
      
      <div className={`relative h-32 ${status === "live" ? "bg-slate-800" : "bg-slate-50"}`}>
        {thumbnailSrc ? (
          <img 
            src={thumbnailSrc} 
            alt={title} 
            className={cn(
              "w-full h-full object-cover", 
              status === "live" ? "opacity-80" : "opacity-50"
            )}
          />
        ) : (
          <img 
            src="/live-pitch.svg" 
            alt={title} 
            className={cn(
              "w-full h-full object-cover", 
              status === "live" ? "opacity-80" : "opacity-50"
            )}
          />
        )}
        
        <div className="absolute inset-0 flex items-center justify-center">
          {status === "live" ? (
            <button className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
              <i className="ri-play-fill text-white text-2xl"></i>
            </button>
          ) : (
            <div className="text-center">
              <p className="text-sm font-medium text-slate-700">Starts in</p>
              <p className="text-xl font-bold text-primary-600">{getTimeUntil()}</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-slate-800 mb-1">{title}</h3>
        
        <div className="flex items-center space-x-2 mb-3">
          {presenterImage ? (
            <div className="w-6 h-6 rounded-full bg-slate-200 overflow-hidden">
              <img src={presenterImage} alt={presenterName} className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="w-6 h-6 rounded-full bg-slate-200 overflow-hidden">
              <img src={`/avatars/founder-${id % 2 === 0 ? 2 : 1}.svg`} alt={presenterName} className="w-full h-full object-cover" />
            </div>
          )}
          <p className="text-xs font-medium text-slate-700">{presenterName}</p>
        </div>
        
        <div className="flex items-center justify-between">
          {status === "live" ? (
            <div className="flex items-center space-x-1 text-slate-500">
              <i className="ri-user-line"></i>
              <span className="text-xs font-medium">{viewers} watching</span>
            </div>
          ) : (
            <div className="text-xs text-slate-500">
              {startTime ? formatTime(startTime) : "Coming soon"}
            </div>
          )}
          
          <Link href={status === "live" ? `/live-room/${id}` : `/live-rooms#upcoming-${id}`}>
            <button className={cn(
              "text-xs font-medium transition-colors",
              status === "live" 
                ? "text-red-600 hover:text-red-700" 
                : "text-primary-600 hover:text-primary-700"
            )}>
              {status === "live" ? "Join Stream" : "Set Reminder"}
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default LiveRoomCard;
