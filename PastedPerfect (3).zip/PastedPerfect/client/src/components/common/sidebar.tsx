import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import UserSearch from "./user-search";

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
  className?: string;
}

export default function Sidebar({ isOpen = true, onClose, className }: SidebarProps) {
  const [location] = useLocation();

  const navItems = [
    { path: "/dashboard", icon: "dashboard-fill", label: "Dashboard" },
    { path: "/my-pitches", icon: "lightbulb-line", label: "My Pitches" },
    { path: "/live-rooms", icon: "live-line", label: "Live Rooms", badge: 3 },
    { path: "/mentors", icon: "user-star-line", label: "Mentors" },
    { path: "/investors", icon: "money-dollar-circle-line", label: "Investors" },
    { path: "/challenges", icon: "trophy-line", label: "Challenges" },
    { path: "/leaderboard", icon: "bar-chart-box-line", label: "Leaderboard" },
    { path: "/nft-gallery", icon: "nft-line", label: "NFT Gallery" }
  ];

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <aside 
      id="sidebar-menu" 
      className={cn(
        "w-64 bg-white border-r border-slate-200 fixed h-[calc(100vh-4rem)] top-16 overflow-y-auto transition-all duration-300 ease-in-out z-20",
        isOpen ? "left-0" : "-left-64",
        className
      )}
    >
      {onClose && (
        <button 
          className="absolute top-2 right-2 text-slate-500 hover:text-slate-700 lg:hidden"
          onClick={onClose}
        >
          <i className="ri-close-line text-xl"></i>
        </button>
      )}
      
      {/* User Search */}
      <div className="p-4 border-b border-slate-200">
        <UserSearch />
      </div>
      
      <nav className="p-4 space-y-1">
        {navItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "nav-item",
              isActive(item.path) ? "nav-item-active" : "nav-item-inactive"
            )}
          >
            <i className={`ri-${item.icon} text-lg`}></i>
            <span>{item.label}</span>
            
            {item.badge && (
              <span className="ml-auto bg-accent-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                {item.badge}
              </span>
            )}
          </Link>
        ))}
        
        <hr className="my-4 border-slate-200" />
        
        <Link 
          href="/settings"
          className="nav-item nav-item-inactive"
        >
          <i className="ri-settings-4-line text-lg"></i>
          <span>Settings</span>
        </Link>
        
        <Link 
          href="/help"
          className="nav-item nav-item-inactive"
        >
          <i className="ri-question-line text-lg"></i>
          <span>Help & Support</span>
        </Link>
      </nav>
    </aside>
  );
}
