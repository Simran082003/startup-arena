import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/dashboard", icon: "dashboard-fill", label: "Home" },
    { path: "/my-pitches", icon: "lightbulb-line", label: "Pitches" },
    { path: "/live-rooms", icon: "live-line", label: "Live" },
    { path: "/mentors", icon: "user-star-line", label: "Network" }
  ];

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-10">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "flex flex-col items-center justify-center",
              isActive(item.path) ? "text-primary-600" : "text-slate-500"
            )}
          >
            <i className={`ri-${item.icon} text-xl`}></i>
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
