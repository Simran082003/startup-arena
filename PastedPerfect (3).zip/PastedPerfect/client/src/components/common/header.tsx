import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";
import Sidebar from "./sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface HeaderProps {
  user: any | null;
  isLoading: boolean;
}

export default function Header({ user, isLoading }: HeaderProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account.",
      });
      
      navigate('/');
    } catch (error) {
      toast({
        title: "Error logging out",
        description: "There was a problem logging out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <header className="bg-white border-b border-slate-200 fixed top-0 w-full z-10">
      <div className="flex items-center justify-between px-4 h-16">
        {/* Mobile menu button */}
        <button 
          className="lg:hidden text-slate-500 hover:text-primary-600 transition-all"
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        >
          <i className="ri-menu-line text-2xl"></i>
        </button>
        
        {/* Logo */}
        <Link href="/dashboard">
          <div className="flex items-center space-x-2 cursor-pointer">
            <img src="/logo.svg" alt="Startup Arena Logo" className="w-10 h-10" />
            <h1 className="text-xl font-bold text-slate-800">Startup Arena</h1>
          </div>
        </Link>
        
        {/* Search bar - Desktop only */}
        <div className="hidden md:flex flex-1 max-w-lg mx-4">
          <div className="relative w-full">
            <Input 
              type="text" 
              placeholder="Search pitches, founders, or investors..." 
              className="w-full py-2 pl-10 pr-4"
            />
            <i className="ri-search-line absolute left-3 top-2.5 text-slate-400"></i>
          </div>
        </div>
        
        {/* Right navigation */}
        <div className="flex items-center space-x-4">
          {isLoading ? (
            <div className="w-8 h-8 rounded-full bg-slate-200 animate-pulse"></div>
          ) : user ? (
            <>
              <button className="hidden md:flex items-center justify-center w-10 h-10 rounded-full hover:bg-slate-100 transition-all text-slate-500 relative">
                <i className="ri-notification-3-line text-xl"></i>
                <span className="absolute top-1 right-1 w-3 h-3 bg-accent-500 rounded-full border-2 border-white"></span>
              </button>
              
              <button className="hidden md:flex items-center justify-center w-10 h-10 rounded-full hover:bg-slate-100 transition-all text-slate-500">
                <i className="ri-message-3-line text-xl"></i>
              </button>
              
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center space-x-1">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user.avatarUrl} alt={user.username} />
                    <AvatarFallback className="bg-primary-100 text-primary-700">
                      {getInitials(user.username)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline-block text-sm font-medium text-slate-700">{user.username}</span>
                  <i className="hidden md:inline-block ri-arrow-down-s-line text-slate-500"></i>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <div className="flex items-center">
                        <i className="ri-user-line mr-2 text-slate-500"></i>
                        Profile
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings/security">
                      <div className="flex items-center">
                        <i className="ri-shield-keyhole-line mr-2 text-slate-500"></i>
                        Security Settings
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <div className="flex items-center">
                      <i className="ri-logout-box-line mr-2 text-slate-500"></i>
                      Logout
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center space-x-2">
              <Button variant="ghost" asChild>
                <Link href="/auth/login">
                  Log in
                </Link>
              </Button>
              <Button asChild>
                <Link href="/auth/register">
                  Sign up
                </Link>
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Mobile search - Only visible on mobile */}
      <div className="px-4 pb-3 lg:hidden">
        <div className="relative w-full">
          <Input
            type="text"
            placeholder="Search..."
            className="w-full py-2 pl-10 pr-4"
          />
          <i className="ri-search-line absolute left-3 top-2.5 text-slate-400"></i>
        </div>
      </div>

      {/* Sidebar for mobile */}
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} className="lg:hidden" />
      
      {/* Sidebar for desktop */}
      <Sidebar className="hidden lg:block" />
    </header>
  );
}
