import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getInitials } from "@/lib/utils";

interface User {
  id: number;
  username: string;
  name: string;
  role: string;
  title?: string;
  avatarUrl?: string;
  bio?: string;
  company?: string;
}

export default function UserSearch() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Fetch users based on search term and role filter
  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users/search", searchTerm, roleFilter],
    queryFn: async () => {
      if (!searchTerm && roleFilter === "all") return [];
      
      const params = new URLSearchParams();
      if (searchTerm) params.append("query", searchTerm);
      if (roleFilter !== "all") params.append("role", roleFilter);
      
      return fetch(`/api/users/search?${params.toString()}`).then(res => {
        if (!res.ok) throw new Error("Failed to fetch users");
        return res.json();
      });
    },
    enabled: searchTerm.length > 0 || roleFilter !== "all",
  });

  // Close search results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    if (value.length > 0) {
      setIsSearchOpen(true);
    } else {
      setIsSearchOpen(false);
    }
  };

  // Handle role filter change
  const handleRoleChange = (value: string) => {
    setRoleFilter(value);
    if (value !== "all" || searchTerm.length > 0) {
      setIsSearchOpen(true);
    }
  };

  // Get role badge styling
  const getRoleBadge = (role: string) => {
    switch (role) {
      case "founder":
        return "bg-emerald-100 text-emerald-800";
      case "investor":
        return "bg-blue-100 text-blue-800";
      case "mentor":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  return (
    <div className="relative w-full" ref={searchRef}>
      <div className="flex gap-2">
        <div className="flex-1">
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={handleSearchChange}
            className="w-full"
          />
        </div>
        <div className="w-32">
          <Select value={roleFilter} onValueChange={handleRoleChange}>
            <SelectTrigger>
              <SelectValue placeholder="Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="founder">Founders</SelectItem>
              <SelectItem value="investor">Investors</SelectItem>
              <SelectItem value="mentor">Mentors</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isSearchOpen && (
        <div className="absolute z-50 w-full bg-white mt-1 rounded-md border border-slate-200 shadow-lg max-h-64 overflow-y-auto">
          {isLoading ? (
            <div className="p-4 text-center text-slate-500">
              <p>Searching...</p>
            </div>
          ) : users.length === 0 ? (
            <div className="p-4 text-center text-slate-500">
              <p>No users found. Try a different search term or filter.</p>
            </div>
          ) : (
            <ul className="py-1">
              {users.map((user) => (
                <li key={user.id} className="hover:bg-slate-50">
                  <Link
                    href={`/user/${user.username}`}
                    className="flex items-center p-2 gap-3"
                    onClick={() => setIsSearchOpen(false)}
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={user.avatarUrl} alt={user.name} />
                      <AvatarFallback className="bg-primary-100 text-primary-700">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-900 truncate">{user.name}</p>
                      <p className="text-xs text-slate-500 truncate">
                        @{user.username} • {user.title || user.company || ''}
                      </p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${getRoleBadge(user.role)}`}>
                      {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}