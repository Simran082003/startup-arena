import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useEffect, useState, lazy, Suspense } from "react";
import NotFound from "@/pages/not-found";

// Import pages
import Dashboard from "@/pages/dashboard";
import Landing from "@/pages/landing";
import Auth from "@/pages/auth";
import ProfileSetup from "@/pages/profile-setup";
import PitchSubmission from "@/pages/pitch-submission";
import MyPitches from "@/pages/my-pitches";
import LiveRooms from "@/pages/live-rooms";
import Mentors from "@/pages/mentors";
import Investors from "@/pages/investors";
import Challenges from "@/pages/challenges";
import Leaderboard from "@/pages/leaderboard";
import NftGallery from "@/pages/nft-gallery";
import PitchDetails from "@/pages/pitch-details";
import LivePitchRoom from "@/pages/live-pitch-room";
import UserProfile from "@/pages/user-profile";
import MintNft from "@/pages/mint-nft";
import SecuritySettings from "@/pages/security-settings";

import { useQuery } from "@tanstack/react-query";
import Header from "./components/common/header";
import { useLocation } from "wouter";

function Router() {
  const [user, setUser] = useState<any>(null);
  const [location] = useLocation();

  // Query to check if user is logged in
  const { data, isLoading } = useQuery({
    queryKey: ['/api/auth/me'],
    retry: false,
  });

  useEffect(() => {
    if (data) {
      setUser(data);
    }
  }, [data]);

  // Check if the current page is the landing page
  const isLandingPage = location === "/";
  const isAuthPage = location === "/auth" || location === "/auth/login" || location === "/auth/register";

  return (
    <>
      {!isLandingPage && !isAuthPage && <Header user={user} isLoading={isLoading} />}
      
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/auth" component={Auth} />
        <Route path="/auth/:action" component={Auth} />
        <Route path="/profile-setup" component={ProfileSetup} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/pitch/new" component={PitchSubmission} />
        <Route path="/pitch/edit/:id" component={PitchSubmission} />
        <Route path="/pitch/:id" component={PitchDetails} />
        <Route path="/my-pitches" component={MyPitches} />
        <Route path="/live-rooms" component={LiveRooms} />
        <Route path="/live-room/:id" component={LivePitchRoom} />
        <Route path="/mentors" component={Mentors} />
        <Route path="/investors" component={Investors} />
        <Route path="/challenges" component={Challenges} />
        <Route path="/leaderboard" component={Leaderboard} />
        <Route path="/nft-gallery" component={NftGallery} />
        <Route path="/mint-nft" component={MintNft} />
        <Route path="/mint-nft/:id" component={MintNft} />
        <Route path="/user/:username" component={UserProfile} />
        <Route path="/settings/security" component={SecuritySettings} />
        <Route path="/mfa-test" component={lazy(() => import('./pages/mfa-test'))} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  // Set document title and metadata
  useEffect(() => {
    document.title = "Startup Arena";
    
    // Add meta description
    const meta = document.createElement('meta');
    meta.name = 'description';
    meta.content = 'Startup Arena - Where founders pitch, investors invest, and mentors guide.';
    document.head.appendChild(meta);
    
    return () => {
      document.head.removeChild(meta);
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
