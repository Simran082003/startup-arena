import { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { z } from "zod";
import session from "express-session";
import { pool } from "@db";
import pgSession from "connect-pg-simple";
import { ZodError } from "zod";

declare module "express-session" {
  interface SessionData {
    userId: number;
    mfaPendingUserId?: number;
  }
}

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
        name?: string;
        email?: string;
        avatarUrl?: string;
        role: string;
        title?: string;
      };
    }
  }
}

// Configure session store
const PgSessionStore = pgSession(session);

export function auth(app: Express) {
  // Session middleware
  app.use(
    session({
      store: new PgSessionStore({
        pool,
        tableName: "session",
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET || "startup-arena-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
      },
    })
  );

  // Current user middleware
  app.use(async (req, res, next) => {
    if (req.session.userId) {
      try {
        const user = await storage.getUserById(req.session.userId);
        if (user) {
          // Convert null to undefined for interface compatibility
          const name = user.name === null ? undefined : user.name;
          const email = user.email === null ? undefined : user.email;
          const avatarUrl = user.avatarUrl === null ? undefined : user.avatarUrl;
          const title = user.title === null ? undefined : user.title;
          
          req.user = {
            id: user.id,
            username: user.username,
            name,
            email,
            avatarUrl,
            role: user.role,
            title,
          };
        }
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    }
    next();
  });

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const registerSchema = z.object({
        username: z.string().min(3, "Username must be at least 3 characters"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        role: z.enum(["user", "founder", "investor", "mentor"]).optional(),
      });

      const validData = registerSchema.parse(req.body);

      // Check if username is taken
      const existingUser = await storage.getUserByUsername(validData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username is already taken" });
      }

      // Create user
      const userData = {
        ...validData,
        role: validData.role || 'user' as const
      };
      const user = await storage.createUser(userData);

      return res.status(201).json({
        id: user.id,
        username: user.username,
        role: user.role,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Registration error:", error);
      return res.status(500).json({ message: "Error during registration" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginSchema = z.object({
        username: z.string(),
        password: z.string(),
      });

      const validData = loginSchema.parse(req.body);

      // Validate credentials
      const user = await storage.validateUserCredentials(
        validData.username,
        validData.password
      );

      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Check if MFA is enabled for this user
      const mfaEnabled = user.mfaEnabled || false;
      
      if (mfaEnabled) {
        // Set pending MFA verification for this user
        req.session.mfaPendingUserId = user.id;
        await new Promise<void>((resolve, reject) => {
          req.session.save((err) => {
            if (err) reject(err);
            resolve();
          });
        });
        
        // Return response indicating MFA is required
        return res.json({
          requireMfa: true,
          userId: user.id,
          username: user.username
        });
      }
      
      // If MFA is not enabled, set full session
      req.session.userId = user.id;
      await new Promise<void>((resolve, reject) => {
        req.session.save((err) => {
          if (err) reject(err);
          resolve();
        });
      });

      return res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        avatarUrl: user.avatarUrl,
        role: user.role,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Login error:", error);
      return res.status(500).json({ message: "Error during login" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Error during logout" });
      }
      res.clearCookie("connect.sid");
      return res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    return res.json(req.user);
  });

  app.put("/api/auth/profile", requireAuth, async (req, res) => {
    try {
      const profileSchema = z.object({
        name: z.string().optional(),
        email: z.string().email().optional(),
        avatarUrl: z.string().optional(),
        role: z.enum(["user", "founder", "investor", "mentor"]).optional(),
        title: z.string().optional(),
        bio: z.string().optional(),
        company: z.string().optional(),
      });

      const validData = profileSchema.parse(req.body);

      const updatedUser = await storage.updateUser(req.user!.id, validData);

      return res.json({
        id: updatedUser.id,
        username: updatedUser.username,
        name: updatedUser.name,
        email: updatedUser.email,
        avatarUrl: updatedUser.avatarUrl,
        role: updatedUser.role,
        title: updatedUser.title,
        bio: updatedUser.bio,
        company: updatedUser.company,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Profile update error:", error);
      return res.status(500).json({ message: "Error updating profile" });
    }
  });
}

// Middleware to require authentication
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}
