// Simple Firebase Admin mock to avoid initialization errors
// We'll use a simpler approach for Google auth with just client-side Firebase

const mockAuth = {
  verifyIdToken: async (token: string) => {
    // In a real implementation, this would verify the token
    return {
      uid: 'mock-uid',
      email: 'user@example.com',
      name: 'Test User',
      picture: ''
    };
  }
};

export default { auth: mockAuth };