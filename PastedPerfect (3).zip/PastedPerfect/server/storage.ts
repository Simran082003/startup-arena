import { db } from '@db';
import * as schema from '@shared/schema';
import { eq, and, or, desc, asc, sql, ne } from 'drizzle-orm';
import { hash, compare } from 'bcrypt';

// User operations
export const storage = {
  // User operations
  async getUserById(id: number) {
    return await db.query.users.findFirst({
      where: eq(schema.users.id, id)
    });
  },

  async getUserByUsername(username: string) {
    return await db.query.users.findFirst({
      where: eq(schema.users.username, username)
    });
  },

  async createUser(userData: Omit<schema.InsertUser, 'password'> & { password: string }) {
    const hashedPassword = await hash(userData.password, 10);
    
    // Set default role to 'user' if not specified
    // Role selection will be done during profile setup
    const userDataWithDefaults = {
      ...userData,
      role: userData.role || 'user' as const,
      password: hashedPassword
    };
    
    const [user] = await db.insert(schema.users)
      .values(userDataWithDefaults)
      .returning();
    
    return user;
  },

  async updateUser(id: number, userData: Partial<Omit<schema.User, 'id' | 'password'>>) {
    const [updatedUser] = await db.update(schema.users)
      .set({
        ...userData,
        updatedAt: new Date()
      })
      .where(eq(schema.users.id, id))
      .returning();
    
    return updatedUser;
  },

  async validateUserCredentials(username: string, password: string) {
    const user = await this.getUserByUsername(username);
    
    if (!user) {
      return null;
    }
    
    const passwordMatch = await compare(password, user.password);
    
    if (!passwordMatch) {
      return null;
    }
    
    return user;
  },

  // Pitch operations
  async getPitchById(id: number) {
    return await db.query.pitches.findFirst({
      where: eq(schema.pitches.id, id),
      with: {
        user: true,
        comments: {
          with: {
            user: true
          }
        },
        upvotes: true
      }
    });
  },

  async getPitchesByUserId(userId: number) {
    return await db.query.pitches.findMany({
      where: eq(schema.pitches.userId, userId),
      orderBy: [desc(schema.pitches.updatedAt)],
      with: {
        comments: true,
        upvotes: true
      }
    });
  },

  async createPitch(pitchData: Omit<schema.Pitch, 'id' | 'createdAt' | 'updatedAt'>) {
    const [pitch] = await db.insert(schema.pitches)
      .values(pitchData)
      .returning();
    
    return pitch;
  },

  async updatePitch(id: number, pitchData: Partial<Omit<schema.Pitch, 'id' | 'createdAt' | 'updatedAt'>>) {
    const [updatedPitch] = await db.update(schema.pitches)
      .set({
        ...pitchData,
        updatedAt: new Date()
      })
      .where(eq(schema.pitches.id, id))
      .returning();
    
    return updatedPitch;
  },

  async deletePitch(id: number) {
    // Delete related records first (comments, upvotes)
    await db.delete(schema.comments)
      .where(eq(schema.comments.pitchId, id));
    
    await db.delete(schema.upvotes)
      .where(eq(schema.upvotes.pitchId, id));
    
    // Now delete the pitch
    await db.delete(schema.pitches)
      .where(eq(schema.pitches.id, id));
    
    return true;
  },

  // Comment operations
  async createComment(commentData: Omit<schema.Comment, 'id' | 'createdAt' | 'updatedAt'>) {
    const [comment] = await db.insert(schema.comments)
      .values(commentData)
      .returning();
    
    return comment;
  },

  // Upvote operations
  async createUpvote(upvoteData: Omit<schema.Upvote, 'id' | 'createdAt'>) {
    const [upvote] = await db.insert(schema.upvotes)
      .values(upvoteData)
      .returning();
    
    // Update pitch upvote count
    await db.update(schema.pitches)
      .set({ upvotes: sql`${schema.pitches.upvotes} + 1` })
      .where(eq(schema.pitches.id, upvoteData.pitchId));
    
    return upvote;
  },

  async hasUserUpvoted(pitchId: number, userId: number) {
    const upvote = await db.query.upvotes.findFirst({
      where: and(
        eq(schema.upvotes.pitchId, pitchId),
        eq(schema.upvotes.userId, userId)
      )
    });
    
    return !!upvote;
  },

  // Live room operations
  async getLiveRoomById(id: number) {
    return await db.query.liveRooms.findFirst({
      where: eq(schema.liveRooms.id, id),
      with: {
        user: true,
        pitch: true,
        participants: {
          with: {
            user: true
          }
        },
        messages: {
          with: {
            user: true
          },
          orderBy: [asc(schema.liveRoomMessages.createdAt)]
        }
      }
    });
  },

  async getActiveLiveRooms() {
    return await db.query.liveRooms.findMany({
      where: or(
        eq(schema.liveRooms.status, "live"),
        eq(schema.liveRooms.status, "scheduled")
      ),
      orderBy: [
        desc(sql`CASE WHEN ${schema.liveRooms.status} = 'live' THEN 1 ELSE 0 END`),
        asc(schema.liveRooms.startTime)
      ],
      with: {
        user: true,
        participants: true
      }
    });
  },

  async createLiveRoom(roomData: Omit<schema.LiveRoom, 'id' | 'createdAt' | 'updatedAt'>) {
    const [room] = await db.insert(schema.liveRooms)
      .values(roomData)
      .returning();
    
    return room;
  },

  async updateLiveRoomStatus(id: number, status: 'scheduled' | 'live' | 'ended') {
    const [updatedRoom] = await db.update(schema.liveRooms)
      .set({
        status,
        updatedAt: new Date(),
        ...(status === 'live' ? { startTime: new Date() } : {}),
        ...(status === 'ended' ? { endTime: new Date() } : {})
      })
      .where(eq(schema.liveRooms.id, id))
      .returning();
    
    return updatedRoom;
  },

  async addParticipantToRoom(roomId: number, userId: number, role: 'host' | 'viewer' | 'speaker' = 'viewer') {
    const [participant] = await db.insert(schema.liveRoomParticipants)
      .values({
        roomId,
        userId,
        role
      })
      .returning();
    
    return participant;
  },

  async removeParticipantFromRoom(roomId: number, userId: number) {
    await db.update(schema.liveRoomParticipants)
      .set({ leftAt: new Date() })
      .where(and(
        eq(schema.liveRoomParticipants.roomId, roomId),
        eq(schema.liveRoomParticipants.userId, userId),
        sql`${schema.liveRoomParticipants.leftAt} IS NULL`
      ));
    
    return true;
  },

  async addMessageToRoom(roomId: number, userId: number, content: string, type: 'text' | 'reaction' | 'question' | 'system' = 'text') {
    const [message] = await db.insert(schema.liveRoomMessages)
      .values({
        roomId,
        userId,
        content,
        type
      })
      .returning();
    
    return message;
  },

  // Challenge operations
  async getChallengeById(id: number) {
    return await db.query.challenges.findFirst({
      where: eq(schema.challenges.id, id),
      with: {
        participants: {
          with: {
            pitch: {
              with: {
                user: true
              }
            },
            user: true
          }
        }
      }
    });
  },

  async getAllChallenges() {
    return await db.query.challenges.findMany({
      with: {
        participants: true
      },
      orderBy: [
        desc(sql`CASE WHEN ${schema.challenges.status} = 'active' THEN 2 WHEN ${schema.challenges.status} = 'upcoming' THEN 1 ELSE 0 END`),
        asc(schema.challenges.startDate)
      ]
    });
  },

  async joinChallenge(challengeId: number, pitchId: number, userId: number) {
    const [participant] = await db.insert(schema.challengeParticipants)
      .values({
        challengeId,
        pitchId,
        userId
      })
      .returning();
    
    return participant;
  },

  // NFT operations
  async getNftById(id: number) {
    return await db.query.nfts.findFirst({
      where: eq(schema.nfts.id, id),
      with: {
        pitch: {
          with: {
            user: true
          }
        },
        user: true
      }
    });
  },

  async getAllNfts() {
    return await db.query.nfts.findMany({
      with: {
        pitch: {
          with: {
            user: true
          }
        },
        user: true
      },
      orderBy: [desc(schema.nfts.mintedAt)]
    });
  },

  async createNft(nftData: Omit<schema.NFT, 'id' | 'mintedAt'>) {
    const [nft] = await db.insert(schema.nfts)
      .values(nftData)
      .returning();
    
    return nft;
  }
};
