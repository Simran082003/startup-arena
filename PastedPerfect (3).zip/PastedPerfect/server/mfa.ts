import { authenticator } from 'otplib';
import QRCode from 'qrcode';
import { db } from '@db';
import * as schema from '@shared/schema';
import { eq } from 'drizzle-orm';

// Configure the authenticator
authenticator.options = {
  window: 1, // Allow 1 step before and after current time
  digits: 6
};

/**
 * Generate a new OTP secret for a user
 * @param userId The ID of the user
 * @param email The email of the user (used as the account name in the OTP app)
 */
export async function generateOtpSecret(userId: number, email: string) {
  // Generate a new secret
  const secret = authenticator.generateSecret();
  
  // Get issuer name for app (used in OTP app)
  const issuer = 'Startup Arena';
  
  // Save the secret to the user's record (but don't enable MFA yet)
  await db.update(schema.users)
    .set({ 
      mfaSecret: secret,
      mfaEnabled: false
    })
    .where(eq(schema.users.id, userId));
  
  // Generate the OTP auth URL (used for QR code)
  const otpAuthUrl = authenticator.keyuri(email, issuer, secret);
  
  // Generate a QR code for the secret
  const qrCodeDataUrl = await QRCode.toDataURL(otpAuthUrl);
  
  // Generate backup codes (8 random 8-digit codes)
  const backupCodes = Array(8).fill(0).map(() => 
    Math.floor(10000000 + Math.random() * 90000000).toString()
  );
  
  // Store backup codes
  await db.update(schema.users)
    .set({ 
      mfaBackupCodes: backupCodes
    })
    .where(eq(schema.users.id, userId));
  
  return {
    secret,
    qrCodeDataUrl,
    backupCodes
  };
}

/**
 * Verify an OTP token for a user
 * @param userId The ID of the user
 * @param token The OTP token to verify
 */
export async function verifyOtpToken(userId: number, token: string) {
  // Get the user's secret
  const user = await db.query.users.findFirst({
    where: eq(schema.users.id, userId),
    columns: {
      mfaSecret: true,
      mfaBackupCodes: true
    }
  });
  
  if (!user || !user.mfaSecret) {
    return false;
  }
  
  // Check if the token is a backup code
  if (user.mfaBackupCodes && user.mfaBackupCodes.includes(token)) {
    // Remove the used backup code
    const updatedBackupCodes = user.mfaBackupCodes.filter(code => code !== token);
    
    await db.update(schema.users)
      .set({ 
        mfaBackupCodes: updatedBackupCodes
      })
      .where(eq(schema.users.id, userId));
    
    return true;
  }
  
  // Verify the OTP token
  return authenticator.verify({
    token,
    secret: user.mfaSecret
  });
}

/**
 * Enable OTP for a user after they've verified a token
 * @param userId The ID of the user
 */
export async function enableOtp(userId: number) {
  await db.update(schema.users)
    .set({ 
      mfaEnabled: true
    })
    .where(eq(schema.users.id, userId));
  
  return true;
}

/**
 * Disable OTP for a user
 * @param userId The ID of the user
 */
export async function disableOtp(userId: number) {
  await db.update(schema.users)
    .set({ 
      mfaEnabled: false,
      mfaSecret: null,
      mfaBackupCodes: []
    })
    .where(eq(schema.users.id, userId));
  
  return true;
}

/**
 * Check if a user has OTP enabled
 * @param userId The ID of the user
 */
export async function isOtpEnabled(userId: number) {
  const user = await db.query.users.findFirst({
    where: eq(schema.users.id, userId),
    columns: {
      mfaEnabled: true
    }
  });
  
  return user?.mfaEnabled || false;
}