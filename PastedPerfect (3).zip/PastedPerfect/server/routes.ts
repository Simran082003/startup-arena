import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { auth, requireAuth } from "./auth";
import { setupWebSockets } from "./ws";
import { z } from "zod";
import { db } from "@db";
import { eq, and, or, desc, sql, asc, ne } from "drizzle-orm";
import * as schema from "@shared/schema";
import { ZodError } from "zod";
import { 
  generateOtpSecret, 
  verifyOtpToken, 
  enableOtp, 
  disableOtp, 
  isOtpEnabled 
} from "./mfa";
import bcrypt from "bcrypt";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Define API prefix
  const apiPrefix = "/api";

  // Setup auth routes
  auth(app);
  
  // Login with token endpoint for Google Auth
  app.post(`${apiPrefix}/auth/login-with-token`, async (req, res) => {
    try {
      // Get the data from the request
      const { email, name, photoURL } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // Check if the user exists in our database
      let user = await db.query.users.findFirst({
        where: eq(schema.users.email, email)
      });
      
      if (!user) {
        // User doesn't exist, create a new one
        const username = email.split('@')[0];
        
        // Check if username exists
        const existingUser = await db.query.users.findFirst({
          where: eq(schema.users.username, username)
        });
        
        // If username already exists, append a random number
        const finalUsername = existingUser 
          ? `${username}_${Math.floor(Math.random() * 10000)}`
          : username;
        
        // Create a new user
        const [newUser] = await db.insert(schema.users)
          .values({
            username: finalUsername,
            email: email,
            name: name || '',
            avatarUrl: photoURL || '',
            // Use a random secure password since they'll login with Google
            password: await bcrypt.hash(Math.random().toString(36).slice(-12), 10),
            role: "user",
            mfaEnabled: false
          })
          .returning();
        
        user = newUser;
      }
      
      // Set user session
      req.session.userId = user.id;
      
      return res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        avatarUrl: user.avatarUrl,
        role: user.role,
        title: user.title
      });
    } catch (error) {
      console.error("Authentication error:", error);
      return res.status(500).json({ message: "Authentication failed" });
    }
  });
  
  // MFA Setup and Verification Routes
  
  // GET /api/auth/mfa/status - Check if MFA is enabled for the current user
  app.get(`${apiPrefix}/auth/mfa/status`, requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const mfaEnabled = await isOtpEnabled(userId);
      
      return res.json({ mfaEnabled });
    } catch (error) {
      console.error("Error checking MFA status:", error);
      return res.status(500).json({ message: "Error checking MFA status" });
    }
  });
  
  // POST /api/auth/mfa/test-setup - Creates a test user with MFA enabled for testing
  app.post(`${apiPrefix}/auth/mfa/test-setup`, async (req, res) => {
    try {
      // Check if test user exists
      let user = await db.query.users.findFirst({
        where: eq(schema.users.username, "testmfa")
      });
      
      if (!user) {
        // Create a test user with MFA enabled
        const [newUser] = await db.insert(schema.users)
          .values({
            username: "testmfa",
            password: await bcrypt.hash("password123", 10),
            role: "user",
            mfaEnabled: true
          })
          .returning();
          
        user = newUser;
        
        // Generate OTP secret for the test user
        const email = "testmfa@example.com";
        await generateOtpSecret(user.id, email);
      }
      
      return res.json({ 
        message: "Test MFA user created", 
        username: "testmfa", 
        password: "password123",
        mfaEnabled: true 
      });
    } catch (error) {
      console.error("Error creating test MFA user:", error);
      return res.status(500).json({ message: "Error creating test MFA user" });
    }
  });
  
  // POST /api/auth/mfa/setup - Generate OTP secret and QR code for setup
  app.post(`${apiPrefix}/auth/mfa/setup`, requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const email = req.user!.email || req.user!.username;
      
      // Check if MFA is already enabled
      const mfaEnabled = await isOtpEnabled(userId);
      if (mfaEnabled) {
        return res.status(400).json({ message: "MFA is already enabled for this account" });
      }
      
      // Generate OTP secret and QR code
      const { secret, qrCodeDataUrl, backupCodes } = await generateOtpSecret(userId, email);
      
      return res.json({
        secret,
        qrCodeDataUrl,
        backupCodes
      });
    } catch (error) {
      console.error("Error setting up MFA:", error);
      return res.status(500).json({ message: "Error setting up MFA" });
    }
  });
  
  // POST /api/auth/mfa/verify - Verify OTP token and enable MFA
  app.post(`${apiPrefix}/auth/mfa/verify`, requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      const verifySchema = z.object({
        token: z.string().min(6).max(8)
      });
      
      const { token } = verifySchema.parse(req.body);
      
      // Verify the token
      const isValid = await verifyOtpToken(userId, token);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid OTP token" });
      }
      
      // Enable MFA for the user
      await enableOtp(userId);
      
      return res.json({ message: "MFA has been enabled for your account" });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error verifying MFA token:", error);
      return res.status(500).json({ message: "Error verifying MFA token" });
    }
  });
  
  // POST /api/auth/mfa/disable - Disable MFA for the current user
  app.post(`${apiPrefix}/auth/mfa/disable`, requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Verify token for security (require OTP verification to disable)
      const verifySchema = z.object({
        token: z.string().min(6).max(8)
      });
      
      const { token } = verifySchema.parse(req.body);
      
      // Verify the token
      const isValid = await verifyOtpToken(userId, token);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid OTP token" });
      }
      
      // Disable MFA
      await disableOtp(userId);
      
      return res.json({ message: "MFA has been disabled for your account" });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error disabling MFA:", error);
      return res.status(500).json({ message: "Error disabling MFA" });
    }
  });
  
  // POST /api/auth/login-mfa - Verify MFA during login
  app.post(`${apiPrefix}/auth/login-mfa`, async (req, res) => {
    try {
      // This endpoint is used after a successful username/password login
      // The session should already contain the userId but MFA is not yet verified
      
      if (!req.session || !req.session.mfaPendingUserId) {
        return res.status(401).json({ message: "No pending MFA login session" });
      }
      
      const verifySchema = z.object({
        token: z.string().min(6).max(8)
      });
      
      const { token } = verifySchema.parse(req.body);
      const userId = req.session.mfaPendingUserId;
      
      // Verify the token
      const isValid = await verifyOtpToken(userId, token);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid OTP token" });
      }
      
      // Clear the pending MFA flag and set the user as fully authenticated
      delete req.session.mfaPendingUserId;
      req.session.userId = userId;
      
      // Save the session
      await new Promise<void>((resolve, reject) => {
        req.session.save((err) => {
          if (err) reject(err);
          resolve();
        });
      });
      
      // Get user information
      const user = await storage.getUserById(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.json({
        id: user.id,
        username: user.username,
        name: user.name || null,
        email: user.email || null,
        avatarUrl: user.avatarUrl || null,
        role: user.role,
        title: user.title || null
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error verifying MFA login:", error);
      return res.status(500).json({ message: "Error verifying MFA login" });
    }
  });

  // Setup WebSockets for live features
  setupWebSockets(httpServer);

  // API Routes

  // GET /api/dashboard - Get role-specific dashboard data
  app.get(`${apiPrefix}/dashboard`, requireAuth, async (req, res) => {
    try {
      const user = req.user!;
      
      // Common data - connections
      const connections = await db.query.connections.findMany({
        where: or(
          eq(schema.connections.followerId, user.id),
          eq(schema.connections.followingId, user.id)
        )
      });
      
      // Common stats shared by all roles
      const commonStats = {
        connectionCount: connections.length,
        newConnections: connections.filter(c => 
          new Date(c.createdAt).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
        ).length,
        upcomingPitchCount: 0,
        nextPitchDate: undefined as string | undefined,
      };
      
      // Initialize dashboard data with user and empty stats
      let dashboardData = {
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email,
          avatarUrl: user.avatarUrl,
          role: user.role,
        },
        stats: { ...commonStats }
      };
      
      // Role-specific data
      if (user.role === "founder") {
        // Founder dashboard - all about pitches
        const pitchesQuery = await db.query.pitches.findMany({
          where: eq(schema.pitches.userId, user.id)
        });
        
        const activePitches = pitchesQuery.filter(p => p.status === "active").length;
        const draftPitches = pitchesQuery.filter(p => p.status === "draft").length;
        const totalViews = pitchesQuery.reduce((sum, pitch) => sum + (pitch.views || 0), 0);
        
        // Get upcoming pitch (live room)
        const upcomingPitches = await db.query.liveRooms.findMany({
          where: and(
            eq(schema.liveRooms.userId, user.id),
            eq(schema.liveRooms.status, "scheduled")
          ),
          orderBy: asc(schema.liveRooms.startTime),
          limit: 1
        });
        
        dashboardData.stats = {
          ...dashboardData.stats,
          pitchCount: pitchesQuery.length,
          activePitches,
          draftPitches,
          totalViews,
          viewsGrowth: Math.floor(Math.random() * 20), // Sample data
          upcomingPitchCount: upcomingPitches.length,
          nextPitchDate: upcomingPitches[0]?.startTime?.toString() || undefined,
        };
      }
      else if (user.role === "investor") {
        // Investor dashboard - focus on investments and reviewed pitches
        // Get upcoming pitches to watch
        const upcomingPitches = await db.query.liveRooms.findMany({
          where: eq(schema.liveRooms.status, "scheduled"),
          orderBy: asc(schema.liveRooms.startTime),
          limit: 1
        });
        
        // For now using sample data - in production this would come from a table of investments
        dashboardData.stats = {
          ...dashboardData.stats,
          investmentCount: 5,  // Sample data
          activeInvestments: 3, // Sample data
          reviewedPitchCount: 14, // Sample data
          newPitchesThisWeek: 3, // Sample data
          upcomingPitchCount: upcomingPitches.length,
          nextPitchDate: upcomingPitches[0]?.startTime || undefined,
        };
      }
      else if (user.role === "mentor") {
        // Mentor dashboard - focus on mentees and sessions
        // Get upcoming mentoring sessions
        const upcomingPitches = await db.query.liveRooms.findMany({
          where: eq(schema.liveRooms.status, "scheduled"),
          orderBy: asc(schema.liveRooms.startTime),
          limit: 1
        });
        
        // For now using sample data - in production this would come from mentoring session tables
        dashboardData.stats = {
          ...dashboardData.stats,
          menteeCount: 8, // Sample data
          activeMentees: 4, // Sample data
          sessionCount: 12, // Sample data
          sessionHours: 24, // Sample data
          upcomingSessionCount: 2, // Sample data
          nextSessionDate: upcomingPitches[0]?.startTime || undefined,
          upcomingPitchCount: upcomingPitches.length,
          nextPitchDate: upcomingPitches[0]?.startTime || undefined,
        };
      }
      else {
        // Default dashboard for users without a specific role
        const upcomingPitches = await db.query.liveRooms.findMany({
          where: eq(schema.liveRooms.status, "scheduled"),
          orderBy: asc(schema.liveRooms.startTime),
          limit: 1
        });
        
        dashboardData.stats = {
          ...dashboardData.stats,
          pitchCount: 0,
          activePitches: 0,
          draftPitches: 0,
          totalViews: 0,
          viewsGrowth: 0,
          upcomingPitchCount: upcomingPitches.length,
          nextPitchDate: upcomingPitches[0]?.startTime || undefined,
        };
      }
      
      return res.json(dashboardData);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      return res.status(500).json({ message: "Error fetching dashboard data" });
    }
  });

  // GET /api/pitches/trending - Get trending pitches
  app.get(`${apiPrefix}/pitches/trending`, async (req, res) => {
    try {
      const trendingPitches = await db.query.pitches.findMany({
        where: eq(schema.pitches.status, "active"),
        orderBy: [
          desc(schema.pitches.upvotes),
          desc(schema.pitches.views)
        ],
        limit: 10,
        with: {
          user: {
            columns: {
              password: false,
            }
          },
          comments: true,
        }
      });
      
      const formattedPitches = trendingPitches.map(pitch => ({
        id: pitch.id,
        title: pitch.title,
        description: pitch.description,
        category: pitch.category,
        imageSrc: pitch.imageSrc,
        upvotes: pitch.upvotes,
        comments: pitch.comments.length,
        founder: {
          id: pitch.user.id,
          username: pitch.user.username,
          name: pitch.user.name || pitch.user.username,
          title: pitch.user.title || "Founder",
          avatarUrl: pitch.user.avatarUrl
        }
      }));
      
      return res.json(formattedPitches);
    } catch (error) {
      console.error("Error fetching trending pitches:", error);
      return res.status(500).json({ message: "Error fetching trending pitches" });
    }
  });

  // GET /api/pitches/user - Get current user's pitches
  app.get(`${apiPrefix}/pitches/user`, requireAuth, async (req, res) => {
    try {
      const userPitches = await db.query.pitches.findMany({
        where: eq(schema.pitches.userId, req.user!.id),
        orderBy: [desc(schema.pitches.updatedAt)],
        with: {
          upvotes: true,
          comments: true,
        }
      });
      
      const formattedPitches = userPitches.map(pitch => ({
        id: pitch.id,
        title: pitch.title,
        description: pitch.description,
        category: pitch.category,
        status: pitch.status,
        imageSrc: pitch.imageSrc,
        views: pitch.views,
        upvotes: pitch.upvotes.length,
        comments: pitch.comments.length,
        tags: pitch.tags || [],
        createdAt: pitch.createdAt,
        updatedAt: pitch.updatedAt
      }));
      
      return res.json(formattedPitches);
    } catch (error) {
      console.error("Error fetching user pitches:", error);
      return res.status(500).json({ message: "Error fetching your pitches" });
    }
  });

  // GET /api/pitches/:id - Get pitch details
  app.get(`${apiPrefix}/pitches/:id`, async (req, res) => {
    try {
      const pitchId = parseInt(req.params.id);
      if (isNaN(pitchId)) {
        return res.status(400).json({ message: "Invalid pitch ID" });
      }
      
      const pitch = await db.query.pitches.findFirst({
        where: eq(schema.pitches.id, pitchId),
        with: {
          user: {
            columns: {
              password: false,
            }
          },
          comments: {
            with: {
              user: {
                columns: {
                  password: false,
                }
              }
            },
            orderBy: [desc(schema.comments.createdAt)]
          },
          upvotes: true
        }
      });
      
      if (!pitch) {
        return res.status(404).json({ message: "Pitch not found" });
      }
      
      // Update view count
      await db.update(schema.pitches)
        .set({ views: (pitch.views || 0) + 1 })
        .where(eq(schema.pitches.id, pitchId));
      
      // Check if user has upvoted
      let hasUserUpvoted = false;
      if (req.user) {
        const userUpvote = pitch.upvotes.find(upvote => upvote.userId === req.user!.id);
        hasUserUpvoted = !!userUpvote;
      }
      
      // Format response
      const response = {
        id: pitch.id,
        title: pitch.title,
        description: pitch.description,
        category: pitch.category,
        status: pitch.status,
        imageSrc: pitch.imageSrc,
        videoSrc: pitch.videoSrc,
        views: pitch.views,
        upvotes: pitch.upvotes.length,
        tags: pitch.tags || [],
        createdAt: pitch.createdAt,
        updatedAt: pitch.updatedAt,
        founder: {
          id: pitch.user.id,
          username: pitch.user.username,
          name: pitch.user.name || pitch.user.username,
          title: pitch.user.title || "Founder",
          avatarUrl: pitch.user.avatarUrl,
          bio: pitch.user.bio
        },
        comments: pitch.comments.map(comment => ({
          id: comment.id,
          content: comment.content,
          createdAt: comment.createdAt,
          user: {
            id: comment.user.id,
            username: comment.user.username,
            name: comment.user.name || comment.user.username,
            avatarUrl: comment.user.avatarUrl,
            role: comment.user.role
          }
        })),
        hasUserUpvoted
      };
      
      return res.json(response);
    } catch (error) {
      console.error("Error fetching pitch details:", error);
      return res.status(500).json({ message: "Error fetching pitch details" });
    }
  });

  // POST /api/pitches - Create a new pitch
  app.post(`${apiPrefix}/pitches`, requireAuth, async (req, res) => {
    try {
      const pitchSchema = z.object({
        title: z.string().min(3, "Title must be at least 3 characters"),
        description: z.string().min(10, "Description must be at least 10 characters"),
        category: z.string().min(1, "Category is required"),
        status: z.enum(["draft", "active"]).optional(),
        imageSrc: z.string().optional(),
        videoSrc: z.string().optional(),
        tags: z.array(z.string()).optional()
      });
      
      const validData = pitchSchema.parse(req.body);
      
      const newPitch = await db.insert(schema.pitches)
        .values({
          ...validData,
          userId: req.user!.id,
          status: validData.status || "draft"
        })
        .returning();
      
      return res.status(201).json(newPitch[0]);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating pitch:", error);
      return res.status(500).json({ message: "Error creating pitch" });
    }
  });

  // PUT /api/pitches/:id - Update a pitch
  app.put(`${apiPrefix}/pitches/:id`, requireAuth, async (req, res) => {
    try {
      const pitchId = parseInt(req.params.id);
      if (isNaN(pitchId)) {
        return res.status(400).json({ message: "Invalid pitch ID" });
      }
      
      // Verify ownership
      const existingPitch = await db.query.pitches.findFirst({
        where: eq(schema.pitches.id, pitchId)
      });
      
      if (!existingPitch) {
        return res.status(404).json({ message: "Pitch not found" });
      }
      
      if (existingPitch.userId !== req.user!.id) {
        return res.status(403).json({ message: "You are not authorized to update this pitch" });
      }
      
      const pitchSchema = z.object({
        title: z.string().min(3, "Title must be at least 3 characters").optional(),
        description: z.string().min(10, "Description must be at least 10 characters").optional(),
        category: z.string().min(1, "Category is required").optional(),
        status: z.enum(["draft", "active"]).optional(),
        imageSrc: z.string().optional(),
        videoSrc: z.string().optional(),
        tags: z.array(z.string()).optional()
      });
      
      const validData = pitchSchema.parse(req.body);
      
      const updatedPitch = await db.update(schema.pitches)
        .set({
          ...validData,
          updatedAt: new Date()
        })
        .where(eq(schema.pitches.id, pitchId))
        .returning();
      
      return res.json(updatedPitch[0]);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating pitch:", error);
      return res.status(500).json({ message: "Error updating pitch" });
    }
  });

  // DELETE /api/pitches/:id - Delete a pitch
  app.delete(`${apiPrefix}/pitches/:id`, requireAuth, async (req, res) => {
    try {
      const pitchId = parseInt(req.params.id);
      if (isNaN(pitchId)) {
        return res.status(400).json({ message: "Invalid pitch ID" });
      }
      
      // Verify ownership
      const existingPitch = await db.query.pitches.findFirst({
        where: eq(schema.pitches.id, pitchId)
      });
      
      if (!existingPitch) {
        return res.status(404).json({ message: "Pitch not found" });
      }
      
      if (existingPitch.userId !== req.user!.id) {
        return res.status(403).json({ message: "You are not authorized to delete this pitch" });
      }
      
      // Delete related records first (comments, upvotes)
      await db.delete(schema.comments)
        .where(eq(schema.comments.pitchId, pitchId));
      
      await db.delete(schema.upvotes)
        .where(eq(schema.upvotes.pitchId, pitchId));
      
      // Now delete the pitch
      await db.delete(schema.pitches)
        .where(eq(schema.pitches.id, pitchId));
      
      return res.json({ message: "Pitch deleted successfully" });
    } catch (error) {
      console.error("Error deleting pitch:", error);
      return res.status(500).json({ message: "Error deleting pitch" });
    }
  });

  // POST /api/pitches/:id/upvote - Upvote a pitch
  app.post(`${apiPrefix}/pitches/:id/upvote`, requireAuth, async (req, res) => {
    try {
      const pitchId = parseInt(req.params.id);
      if (isNaN(pitchId)) {
        return res.status(400).json({ message: "Invalid pitch ID" });
      }
      
      // Check if pitch exists
      const pitch = await db.query.pitches.findFirst({
        where: eq(schema.pitches.id, pitchId)
      });
      
      if (!pitch) {
        return res.status(404).json({ message: "Pitch not found" });
      }
      
      // Check if user already upvoted
      const existingUpvote = await db.query.upvotes.findFirst({
        where: and(
          eq(schema.upvotes.pitchId, pitchId),
          eq(schema.upvotes.userId, req.user!.id)
        )
      });
      
      if (existingUpvote) {
        return res.status(400).json({ message: "You have already upvoted this pitch" });
      }
      
      // Add upvote
      await db.insert(schema.upvotes)
        .values({
          pitchId,
          userId: req.user!.id
        });
      
      // Update upvote count in pitch
      await db.update(schema.pitches)
        .set({ upvotes: sql`${schema.pitches.upvotes} + 1` })
        .where(eq(schema.pitches.id, pitchId));
      
      return res.json({ message: "Pitch upvoted successfully" });
    } catch (error) {
      console.error("Error upvoting pitch:", error);
      return res.status(500).json({ message: "Error upvoting pitch" });
    }
  });

  // POST /api/pitches/:id/comments - Add a comment to a pitch
  app.post(`${apiPrefix}/pitches/:id/comments`, requireAuth, async (req, res) => {
    try {
      const pitchId = parseInt(req.params.id);
      if (isNaN(pitchId)) {
        return res.status(400).json({ message: "Invalid pitch ID" });
      }
      
      // Check if pitch exists
      const pitch = await db.query.pitches.findFirst({
        where: eq(schema.pitches.id, pitchId)
      });
      
      if (!pitch) {
        return res.status(404).json({ message: "Pitch not found" });
      }
      
      const commentSchema = z.object({
        content: z.string().min(1, "Comment content is required")
      });
      
      const validData = commentSchema.parse(req.body);
      
      const newComment = await db.insert(schema.comments)
        .values({
          pitchId,
          userId: req.user!.id,
          content: validData.content
        })
        .returning();
      
      // Get user info to return with comment
      const user = req.user!;
      
      const commentWithUser = {
        ...newComment[0],
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          avatarUrl: user.avatarUrl,
          role: user.role
        }
      };
      
      return res.status(201).json(commentWithUser);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating comment:", error);
      return res.status(500).json({ message: "Error creating comment" });
    }
  });

  // GET /api/live-rooms - Get live and upcoming rooms
  app.get(`${apiPrefix}/live-rooms`, async (req, res) => {
    try {
      const liveRooms = await db.query.liveRooms.findMany({
        where: or(
          eq(schema.liveRooms.status, "live"),
          eq(schema.liveRooms.status, "scheduled")
        ),
        orderBy: [
          // Live rooms first, then by start time
          desc(sql`CASE WHEN ${schema.liveRooms.status} = 'live' THEN 1 ELSE 0 END`),
          asc(schema.liveRooms.startTime)
        ],
        limit: 6,
        with: {
          user: {
            columns: {
              password: false
            }
          },
          participants: true
        }
      });
      
      const formattedRooms = liveRooms.map(room => ({
        id: room.id,
        title: room.title,
        status: room.status === "live" ? "live" : "upcoming",
        startTime: room.startTime,
        thumbnailSrc: room.thumbnailSrc,
        presenter: {
          id: room.user.id,
          name: room.user.name || room.user.username,
          username: room.user.username,
          avatarUrl: room.user.avatarUrl
        },
        viewerCount: room.participants.filter(p => p.leftAt === null).length || 0
      }));
      
      return res.json(formattedRooms);
    } catch (error) {
      console.error("Error fetching live rooms:", error);
      return res.status(500).json({ message: "Error fetching live rooms" });
    }
  });

  // GET /api/live-rooms/active - Get only currently live rooms
  app.get(`${apiPrefix}/live-rooms/active`, async (req, res) => {
    try {
      const liveRooms = await db.query.liveRooms.findMany({
        where: eq(schema.liveRooms.status, "live"),
        orderBy: [desc(schema.liveRooms.startTime)],
        with: {
          user: {
            columns: {
              password: false,
            }
          },
          pitch: true,
        }
      });
      
      const formattedRooms = liveRooms.map(room => ({
        id: room.id,
        title: room.title,
        description: room.description,
        status: room.status,
        startTime: room.startTime,
        thumbnailSrc: room.thumbnailSrc,
        viewerCount: Math.floor(Math.random() * 20) + 5, // Mock data for demo
        presenter: {
          id: room.user.id,
          username: room.user.username,
          name: room.user.name || room.user.username,
          avatarUrl: room.user.avatarUrl
        },
        pitch: room.pitch ? {
          id: room.pitch.id,
          title: room.pitch.title,
        } : null
      }));
      
      return res.json(formattedRooms);
    } catch (error) {
      console.error("Error fetching active live rooms:", error);
      return res.status(500).json({ message: "Error fetching active live rooms" });
    }
  });

  // GET /api/live-rooms/:id - Get live room details
  app.get(`${apiPrefix}/live-rooms/:id`, async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      if (isNaN(roomId)) {
        return res.status(400).json({ message: "Invalid room ID" });
      }
      
      const room = await db.query.liveRooms.findFirst({
        where: eq(schema.liveRooms.id, roomId),
        with: {
          user: {
            columns: {
              password: false
            }
          },
          pitch: true,
          participants: {
            with: {
              user: {
                columns: {
                  password: false
                }
              }
            }
          },
          messages: {
            with: {
              user: {
                columns: {
                  password: false
                }
              }
            },
            orderBy: [asc(schema.liveRoomMessages.createdAt)],
            limit: 100
          }
        }
      });
      
      if (!room) {
        return res.status(404).json({ message: "Live room not found" });
      }
      
      // Format the response
      const formattedRoom = {
        id: room.id,
        title: room.title,
        description: room.description,
        status: room.status,
        startTime: room.startTime,
        endTime: room.endTime,
        thumbnailSrc: room.thumbnailSrc,
        presenter: {
          id: room.user.id,
          username: room.user.username,
          name: room.user.name || room.user.username,
          avatarUrl: room.user.avatarUrl,
          title: room.user.title
        },
        pitch: room.pitch ? {
          id: room.pitch.id,
          title: room.pitch.title,
          description: room.pitch.description,
          category: room.pitch.category
        } : null,
        participants: room.participants
          .filter(p => p.leftAt === null)
          .map(p => ({
            id: p.user.id,
            username: p.user.username,
            name: p.user.name || p.user.username,
            avatarUrl: p.user.avatarUrl,
            role: p.role
          })),
        messages: room.messages.map(m => ({
          id: m.id,
          content: m.content,
          type: m.type,
          timestamp: m.createdAt,
          user: {
            id: m.user.id,
            username: m.user.username,
            name: m.user.name || m.user.username,
            avatarUrl: m.user.avatarUrl
          }
        }))
      };
      
      return res.json(formattedRoom);
    } catch (error) {
      console.error("Error fetching live room details:", error);
      return res.status(500).json({ message: "Error fetching live room details" });
    }
  });

  // POST /api/live-rooms - Create a new live room
  app.post(`${apiPrefix}/live-rooms`, requireAuth, async (req, res) => {
    try {
      const liveRoomSchema = z.object({
        title: z.string().min(3, "Title must be at least 3 characters"),
        description: z.string().optional(),
        pitchId: z.number().optional(),
        thumbnailSrc: z.string().optional(),
        startTime: z.string().optional(), // ISO string
        status: z.enum(["scheduled", "live"]).default("scheduled")
      });
      
      const validData = liveRoomSchema.parse(req.body);
      const startTime = validData.startTime ? new Date(validData.startTime) : new Date();
      
      // If pitchId is provided, verify ownership
      if (validData.pitchId) {
        const pitch = await db.query.pitches.findFirst({
          where: eq(schema.pitches.id, validData.pitchId)
        });
        
        if (!pitch) {
          return res.status(404).json({ message: "Pitch not found" });
        }
        
        if (pitch.userId !== req.user!.id) {
          return res.status(403).json({ message: "You do not own this pitch" });
        }
      }
      
      const newRoom = await db.insert(schema.liveRooms)
        .values({
          title: validData.title,
          description: validData.description || "",
          pitchId: validData.pitchId,
          userId: req.user!.id,
          thumbnailSrc: validData.thumbnailSrc,
          startTime,
          status: validData.status
        })
        .returning();
      
      // Add creator as a participant
      await db.insert(schema.liveRoomParticipants)
        .values({
          roomId: newRoom[0].id,
          userId: req.user!.id,
          role: "host"
        });
      
      return res.status(201).json(newRoom[0]);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating live room:", error);
      return res.status(500).json({ message: "Error creating live room" });
    }
  });

  // POST /api/live-rooms/:id/join - Join a live room
  app.post(`${apiPrefix}/live-rooms/:id/join`, requireAuth, async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      if (isNaN(roomId)) {
        return res.status(400).json({ message: "Invalid room ID" });
      }
      
      // Check if room exists
      const room = await db.query.liveRooms.findFirst({
        where: eq(schema.liveRooms.id, roomId)
      });
      
      if (!room) {
        return res.status(404).json({ message: "Live room not found" });
      }
      
      // Check if user is already in the room
      const existingParticipant = await db.query.liveRoomParticipants.findFirst({
        where: and(
          eq(schema.liveRoomParticipants.roomId, roomId),
          eq(schema.liveRoomParticipants.userId, req.user!.id),
          sql`${schema.liveRoomParticipants.leftAt} IS NULL`
        )
      });
      
      if (existingParticipant) {
        return res.json({ message: "Already joined the room", participantId: existingParticipant.id });
      }
      
      // If user left before, update their record
      const previousParticipation = await db.query.liveRoomParticipants.findFirst({
        where: and(
          eq(schema.liveRoomParticipants.roomId, roomId),
          eq(schema.liveRoomParticipants.userId, req.user!.id)
        )
      });
      
      if (previousParticipation) {
        await db.update(schema.liveRoomParticipants)
          .set({ 
            leftAt: null,
            joinedAt: new Date()
          })
          .where(eq(schema.liveRoomParticipants.id, previousParticipation.id));
        
        return res.json({ message: "Rejoined the room", participantId: previousParticipation.id });
      }
      
      // Add participant
      const role = room.userId === req.user!.id ? "host" : "viewer";
      
      const newParticipant = await db.insert(schema.liveRoomParticipants)
        .values({
          roomId,
          userId: req.user!.id,
          role
        })
        .returning();
      
      // Add system message about joining
      await db.insert(schema.liveRoomMessages)
        .values({
          roomId,
          userId: req.user!.id,
          content: `${req.user!.username} joined the room`,
          type: "system"
        });
      
      return res.status(201).json({ 
        message: "Joined the room successfully", 
        participantId: newParticipant[0].id 
      });
    } catch (error) {
      console.error("Error joining live room:", error);
      return res.status(500).json({ message: "Error joining live room" });
    }
  });

  // POST /api/live-rooms/:id/leave - Leave a live room
  app.post(`${apiPrefix}/live-rooms/:id/leave`, requireAuth, async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      if (isNaN(roomId)) {
        return res.status(400).json({ message: "Invalid room ID" });
      }
      
      // Update participant record
      await db.update(schema.liveRoomParticipants)
        .set({ leftAt: new Date() })
        .where(and(
          eq(schema.liveRoomParticipants.roomId, roomId),
          eq(schema.liveRoomParticipants.userId, req.user!.id),
          sql`${schema.liveRoomParticipants.leftAt} IS NULL`
        ));
      
      // Add system message about leaving
      await db.insert(schema.liveRoomMessages)
        .values({
          roomId,
          userId: req.user!.id,
          content: `${req.user!.username} left the room`,
          type: "system"
        });
      
      return res.json({ message: "Left the room successfully" });
    } catch (error) {
      console.error("Error leaving live room:", error);
      return res.status(500).json({ message: "Error leaving live room" });
    }
  });

  // GET /api/users/search - Search for users
  app.get(`${apiPrefix}/users/search`, async (req, res) => {
    try {
      const query = req.query.query as string || '';
      const role = req.query.role as string;
      
      // Simplify the query to avoid SQL issues
      let querySQL;
      
      if (role && role !== 'all' && ['founder', 'investor', 'mentor'].includes(role)) {
        // Search with role filter
        querySQL = sql`
          SELECT id, username, name, role, title, avatar_url as "avatarUrl", bio, company 
          FROM users 
          WHERE role = ${role}
          ${query ? sql`AND (
            username ILIKE ${'%' + query + '%'} OR
            name ILIKE ${'%' + query + '%'} OR
            company ILIKE ${'%' + query + '%'}
          )` : sql``}
          ORDER BY id DESC
          LIMIT 20
        `;
      } else if (query) {
        // Search without role filter
        querySQL = sql`
          SELECT id, username, name, role, title, avatar_url as "avatarUrl", bio, company 
          FROM users 
          WHERE 
            username ILIKE ${'%' + query + '%'} OR
            name ILIKE ${'%' + query + '%'} OR
            company ILIKE ${'%' + query + '%'}
          ORDER BY id DESC
          LIMIT 20
        `;
      } else {
        // No filters, just get recent users
        querySQL = sql`
          SELECT id, username, name, role, title, avatar_url as "avatarUrl", bio, company 
          FROM users 
          ORDER BY id DESC
          LIMIT 10
        `;
      }
      
      // Execute query and get results
      const result = await db.execute(querySQL);
      const users = result.rows || [];
      
      // Format response
      const formattedUsers = users.map((user: any) => ({
        id: user.id,
        username: user.username,
        name: user.name || user.username,
        role: user.role,
        title: user.title || (
          user.role === "founder" ? "Founder" : 
          user.role === "investor" ? "Investor" : "Mentor"
        ),
        avatarUrl: user.avatarUrl,
        bio: user.bio || "",
        company: user.company || "",
      }));
      
      return res.json(formattedUsers);
    } catch (error) {
      console.error("Error searching users:", error);
      return res.status(500).json({ message: "Error searching users" });
    }
  });

  // GET /api/users/:username - Get user by username
  app.get(`${apiPrefix}/users/:username`, async (req, res) => {
    try {
      const { username } = req.params;
      
      // Find user by username
      const user = await db.query.users.findFirst({
        where: eq(schema.users.username, username),
        columns: {
          password: false // Exclude password
        }
      });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get user's pitches if they're a founder
      const userPitches: any[] = [];
      if (user.role === "founder") {
        const founderPitches = await db.query.pitches.findMany({
          where: eq(schema.pitches.userId, user.id),
          orderBy: [desc(schema.pitches.createdAt)],
          limit: 5
        });
        
        // Add each pitch to the array
        founderPitches.forEach(pitch => {
          userPitches.push({
            id: pitch.id,
            title: pitch.title,
            description: pitch.description,
            category: pitch.category,
            status: pitch.status
          });
        });
      }
      
      // Format response with explicit type casting where needed
      const userProfile = {
        id: user.id,
        username: user.username,
        name: user.name || user.username,
        role: user.role,
        title: user.title,
        avatarUrl: user.avatarUrl,
        bio: user.bio || "",
        company: user.company || "",
        // Use an empty array as default since expertiseAreas might not exist in the schema
        expertiseAreas: [],
        pitches: userPitches,
        // These would be populated from real data in a full implementation
        connections: []
      };
      
      return res.json(userProfile);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      return res.status(500).json({ message: "Error fetching user profile" });
    }
  });

  // GET /api/mentors-investors/top - Get top mentors and investors
  app.get(`${apiPrefix}/mentors-investors/top`, async (req, res) => {
    try {
      // Get top mentors
      const mentors = await db.query.users.findMany({
        where: eq(schema.users.role, "mentor"),
        limit: 2
      });
      
      // Get top investors
      const investors = await db.query.users.findMany({
        where: eq(schema.users.role, "investor"),
        limit: 2
      });
      
      // Format mentors
      const formattedMentors = mentors.map(mentor => ({
        id: mentor.id,
        name: mentor.name || mentor.username,
        username: mentor.username,
        avatarUrl: mentor.avatarUrl,
        title: mentor.title || "Mentor",
        expertise: mentor.title?.split(" • ")[1] || "Product Design",
        bio: mentor.bio || "Experienced mentor with expertise in product design and startup strategy.",
        rating: 4.7 + Math.random() * 0.3, // Random rating between 4.7 and 5.0
        reviewCount: Math.floor(10 + Math.random() * 20) // Random between 10 and 30
      }));
      
      // Format investors
      const formattedInvestors = investors.map(investor => ({
        id: investor.id,
        name: investor.name || investor.username,
        username: investor.username,
        avatarUrl: investor.avatarUrl,
        title: investor.title || "Seed Stage",
        firm: investor.company || "Accel Partners",
        bio: investor.bio || "Investor focused on early-stage startups in SaaS and AI.",
        interests: ["SaaS", "AI", "FinTech"].sort(() => Math.random() - 0.5).slice(0, 2 + Math.floor(Math.random() * 2))
      }));
      
      return res.json({
        mentors: formattedMentors,
        investors: formattedInvestors
      });
    } catch (error) {
      console.error("Error fetching mentors and investors:", error);
      return res.status(500).json({ message: "Error fetching mentors and investors" });
    }
  });

  // GET /api/mentors - Get all mentors
  app.get(`${apiPrefix}/mentors`, async (req, res) => {
    try {
      const mentors = await db.query.users.findMany({
        where: eq(schema.users.role, "mentor")
      });
      
      const formattedMentors = mentors.map(mentor => ({
        id: mentor.id,
        name: mentor.name || mentor.username,
        username: mentor.username,
        avatarUrl: mentor.avatarUrl,
        title: mentor.title || "Mentor",
        expertise: mentor.title?.split(" • ")[1] || "Product Design",
        bio: mentor.bio || "Experienced mentor with expertise in product design and startup strategy.",
        rating: 4.5 + Math.random() * 0.5, // Random rating between 4.5 and 5.0
        reviewCount: Math.floor(10 + Math.random() * 30) // Random between 10 and 40
      }));
      
      return res.json(formattedMentors);
    } catch (error) {
      console.error("Error fetching mentors:", error);
      return res.status(500).json({ message: "Error fetching mentors" });
    }
  });

  // GET /api/investors - Get all investors
  app.get(`${apiPrefix}/investors`, async (req, res) => {
    try {
      const investors = await db.query.users.findMany({
        where: eq(schema.users.role, "investor")
      });
      
      const formattedInvestors = investors.map(investor => ({
        id: investor.id,
        name: investor.name || investor.username,
        username: investor.username,
        avatarUrl: investor.avatarUrl,
        title: investor.title || "Seed Stage",
        firm: investor.company || "Accel Partners",
        bio: investor.bio || "Investor focused on early-stage startups in SaaS and AI.",
        interests: ["SaaS", "AI", "FinTech", "HealthTech", "Climate Tech", "E-commerce", "Mobile Apps"]
          .sort(() => Math.random() - 0.5).slice(0, 2 + Math.floor(Math.random() * 3))
      }));
      
      return res.json(formattedInvestors);
    } catch (error) {
      console.error("Error fetching investors:", error);
      return res.status(500).json({ message: "Error fetching investors" });
    }
  });

  // GET /api/challenges - Get all challenges
  app.get(`${apiPrefix}/challenges`, async (req, res) => {
    try {
      const challenges = await db.query.challenges.findMany({
        with: {
          participants: true
        },
        orderBy: [
          // Active challenges first, then upcoming, then ended
          desc(sql`CASE WHEN ${schema.challenges.status} = 'active' THEN 2 WHEN ${schema.challenges.status} = 'upcoming' THEN 1 ELSE 0 END`),
          // For upcoming and ended challenges, sort by date
          asc(schema.challenges.startDate)
        ]
      });
      
      const formattedChallenges = challenges.map(challenge => ({
        id: challenge.id,
        title: challenge.title,
        description: challenge.description,
        prize: challenge.prize,
        startDate: challenge.startDate,
        endDate: challenge.endDate,
        status: challenge.status,
        participantCount: challenge.participants.length,
        userIsParticipating: req.user 
          ? challenge.participants.some(p => p.userId === req.user!.id)
          : false
      }));
      
      return res.json(formattedChallenges);
    } catch (error) {
      console.error("Error fetching challenges:", error);
      return res.status(500).json({ message: "Error fetching challenges" });
    }
  });

  // GET /api/challenges/:id - Get challenge details with leaderboard
  app.get(`${apiPrefix}/challenges/:id`, async (req, res) => {
    try {
      const challengeId = parseInt(req.params.id);
      if (isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const challenge = await db.query.challenges.findFirst({
        where: eq(schema.challenges.id, challengeId),
        with: {
          participants: {
            with: {
              pitch: {
                with: {
                  user: true
                }
              },
              user: true
            }
          }
        }
      });
      
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      // Sort participants by score/rank for leaderboard
      const leaderboard = challenge.participants
        .sort((a, b) => (b.score || 0) - (a.score || 0))
        .map((participant, index) => ({
          rank: participant.rank || index + 1,
          score: participant.score || 0,
          submissionDate: participant.submissionDate,
          pitch: {
            id: participant.pitch.id,
            title: participant.pitch.title,
            description: participant.pitch.description,
            category: participant.pitch.category,
            founder: {
              id: participant.pitch.user.id,
              name: participant.pitch.user.name || participant.pitch.user.username,
              username: participant.pitch.user.username,
              avatarUrl: participant.pitch.user.avatarUrl
            }
          }
        }));
      
      // Check if current user is participating
      const userIsParticipating = req.user 
        ? challenge.participants.some(p => p.userId === req.user!.id) 
        : false;
      
      const response = {
        id: challenge.id,
        title: challenge.title,
        description: challenge.description,
        prize: challenge.prize,
        startDate: challenge.startDate,
        endDate: challenge.endDate,
        status: challenge.status,
        participantCount: challenge.participants.length,
        userIsParticipating,
        leaderboard
      };
      
      return res.json(response);
    } catch (error) {
      console.error("Error fetching challenge details:", error);
      return res.status(500).json({ message: "Error fetching challenge details" });
    }
  });

  // POST /api/challenges/:id/join - Join a challenge
  app.post(`${apiPrefix}/challenges/:id/join`, requireAuth, async (req, res) => {
    try {
      const challengeId = parseInt(req.params.id);
      if (isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const joinSchema = z.object({
        pitchId: z.number()
      });
      
      const validData = joinSchema.parse(req.body);
      
      // Check if challenge exists and is active or upcoming
      const challenge = await db.query.challenges.findFirst({
        where: and(
          eq(schema.challenges.id, challengeId),
          or(
            eq(schema.challenges.status, "active"),
            eq(schema.challenges.status, "upcoming")
          )
        )
      });
      
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found or not open for participation" });
      }
      
      // Check if pitch exists and belongs to the user
      const pitch = await db.query.pitches.findFirst({
        where: and(
          eq(schema.pitches.id, validData.pitchId),
          eq(schema.pitches.userId, req.user!.id)
        )
      });
      
      if (!pitch) {
        return res.status(404).json({ message: "Pitch not found or you don't own it" });
      }
      
      // Check if already participating with this pitch
      const existingParticipation = await db.query.challengeParticipants.findFirst({
        where: and(
          eq(schema.challengeParticipants.challengeId, challengeId),
          eq(schema.challengeParticipants.pitchId, validData.pitchId)
        )
      });
      
      if (existingParticipation) {
        return res.status(400).json({ message: "You are already participating in this challenge with this pitch" });
      }
      
      // Add participant
      const newParticipant = await db.insert(schema.challengeParticipants)
        .values({
          challengeId,
          pitchId: validData.pitchId,
          userId: req.user!.id
        })
        .returning();
      
      return res.status(201).json({ message: "Successfully joined the challenge", participant: newParticipant[0] });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error joining challenge:", error);
      return res.status(500).json({ message: "Error joining challenge" });
    }
  });

  // GET /api/leaderboard - Get startup leaderboard
  app.get(`${apiPrefix}/leaderboard`, async (req, res) => {
    try {
      // Get top pitches by upvotes and views
      const topPitches = await db.query.pitches.findMany({
        where: eq(schema.pitches.status, "active"),
        orderBy: [
          desc(schema.pitches.upvotes),
          desc(schema.pitches.views)
        ],
        limit: 20,
        with: {
          user: {
            columns: {
              password: false
            }
          },
          comments: true,
          upvotes: true
        }
      });
      
      const leaderboard = topPitches.map((pitch, index) => ({
        rank: index + 1,
        id: pitch.id,
        title: pitch.title,
        description: pitch.description,
        category: pitch.category,
        imageSrc: pitch.imageSrc,
        upvotes: pitch.upvotes.length || 0,
        views: pitch.views || 0,
        comments: pitch.comments.length || 0,
        founder: {
          id: pitch.user.id,
          name: pitch.user.name || pitch.user.username,
          username: pitch.user.username,
          avatarUrl: pitch.user.avatarUrl
        },
        score: (pitch.upvotes.length * 10) + (pitch.views * 0.5) + (pitch.comments.length * 5)
      }));
      
      return res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      return res.status(500).json({ message: "Error fetching leaderboard" });
    }
  });

  // GET /api/nft-gallery - Get NFT gallery
  app.get(`${apiPrefix}/nft-gallery`, async (req, res) => {
    try {
      const nfts = await db.query.nfts.findMany({
        with: {
          pitch: {
            with: {
              user: {
                columns: {
                  password: false
                }
              }
            }
          },
          user: {
            columns: {
              password: false
            }
          }
        },
        orderBy: [desc(schema.nfts.mintedAt)]
      });
      
      // If we don't have NFTs yet, provide some demo data
      if (nfts.length === 0) {
        const mockNfts = [
          {
            id: 1,
            title: "EcoBox Green Packaging Solution",
            description: "Biodegradable packaging for e-commerce that decomposes in 30 days",
            imageUrl: "/nft-placeholder.svg",
            tokenId: "STARTUP-001",
            pitchId: 1,
            mintedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), // 5 days ago
            price: 1.2,
            creator: {
              id: 1,
              name: "Sarah Johnson",
              username: "sarahj",
              avatarUrl: "/avatars/founder-1.svg"
            },
            owner: {
              id: 1,
              name: "Sarah Johnson",
              username: "sarahj",
              avatarUrl: "/avatars/founder-1.svg"
            },
            isOwner: req.user?.id === 1,
            isCreator: req.user?.id === 1
          },
          {
            id: 2,
            title: "HealthTrack Wellness Monitoring System",
            description: "AI-powered health monitoring wearable device with predictive analytics",
            imageUrl: "/nft-placeholder.svg",
            tokenId: "STARTUP-002",
            pitchId: 2,
            mintedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), // 10 days ago
            price: 1.8,
            creator: {
              id: 2,
              name: "David Kim",
              username: "davidk",
              avatarUrl: "/avatars/founder-2.svg"
            },
            owner: {
              id: 2,
              name: "David Kim",
              username: "davidk",
              avatarUrl: "/avatars/founder-2.svg"
            },
            isOwner: req.user?.id === 2,
            isCreator: req.user?.id === 2
          },
          {
            id: 3,
            title: "EcoCharge Sustainable Energy Generator",
            description: "Solar-powered charging solution for remote locations",
            imageUrl: "/nft-placeholder.svg",
            tokenId: "STARTUP-003",
            pitchId: 3,
            mintedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15).toISOString(), // 15 days ago
            price: 2.5,
            creator: {
              id: 3,
              name: "Alex Chen",
              username: "alexc",
              avatarUrl: "/avatars/founder-3.svg"
            },
            owner: {
              id: 3,
              name: "Alex Chen",
              username: "alexc",
              avatarUrl: "/avatars/founder-3.svg"
            },
            isOwner: req.user?.id === 3,
            isCreator: req.user?.id === 3
          }
        ];
        
        return res.json(mockNfts);
      }
      
      const formattedNfts = nfts.map(nft => ({
        id: nft.id,
        title: nft.pitch.title,
        description: nft.pitch.description,
        imageUrl: "/nft-placeholder.svg", // Use our custom NFT placeholder
        tokenId: nft.tokenId || `STARTUP-${nft.id.toString().padStart(3, '0')}`,
        pitchId: nft.pitch.id,
        contractAddress: nft.contractAddress,
        blockchain: nft.blockchain,
        metadata: nft.metadata,
        mintedAt: nft.mintedAt,
        // Add a random price for demonstration
        price: parseFloat((0.5 + Math.random() * 2.5).toFixed(2)),
        pitch: {
          id: nft.pitch.id,
          title: nft.pitch.title,
          description: nft.pitch.description,
          category: nft.pitch.category,
          imageSrc: nft.pitch.imageSrc
        },
        owner: {
          id: nft.user.id,
          name: nft.user.name || nft.user.username,
          username: nft.user.username,
          avatarUrl: nft.user.avatarUrl || `/avatars/founder-${nft.user.id % 3 + 1}.svg` // Fallback avatar
        },
        creator: {
          id: nft.user.id,
          name: nft.user.name || nft.user.username,
          username: nft.user.username,
          avatarUrl: nft.user.avatarUrl || `/avatars/founder-${nft.user.id % 3 + 1}.svg` // Fallback avatar
        },
        isOwner: req.user?.id === nft.user.id,
        isCreator: req.user?.id === nft.user.id
      }));
      
      return res.json(formattedNfts);
    } catch (error) {
      console.error("Error fetching NFT gallery:", error);
      return res.status(500).json({ message: "Error fetching NFT gallery" });
    }
  });

  // GET /api/pitches/user/unminted - Get current user's pitches that haven't been minted as NFTs
  app.get(`${apiPrefix}/pitches/user/unminted`, requireAuth, async (req, res) => {
    try {
      // Find all pitches by the user
      const userPitches = await db.query.pitches.findMany({
        where: eq(schema.pitches.userId, req.user!.id),
        orderBy: [desc(schema.pitches.updatedAt)]
      });
      
      // Find all pitches that already have NFTs
      const mintedNfts = await db.query.nfts.findMany({
        where: eq(schema.nfts.userId, req.user!.id),
        columns: {
          pitchId: true
        }
      });
      
      // Get the pitch IDs that have been minted
      const mintedPitchIds = mintedNfts.map(nft => nft.pitchId);
      
      // Filter out pitches that have already been minted
      const unmintedPitches = userPitches.filter(pitch => !mintedPitchIds.includes(pitch.id));
      
      return res.json(unmintedPitches);
    } catch (error) {
      console.error("Error fetching unminted pitches:", error);
      return res.status(500).json({ message: "Error fetching unminted pitches" });
    }
  });

  // GET /api/nfts - Get NFTs with details
  app.get(`${apiPrefix}/nfts`, async (req, res) => {
    try {
      const userId = req.user?.id;
      
      const nfts = await db.query.nfts.findMany({
        with: {
          pitch: true,
          user: {
            columns: {
              password: false
            }
          }
        }
      });
      
      const formattedNfts = nfts.map(nft => {
        const metadata = nft.metadata as any;
        
        return {
          id: nft.id,
          tokenId: nft.tokenId,
          blockchain: nft.blockchain,
          contractAddress: nft.contractAddress,
          mintedAt: nft.mintedAt,
          pitchId: nft.pitchId,
          title: metadata?.name || nft.pitch.title,
          description: metadata?.description || nft.pitch.description,
          imageUrl: metadata?.image || nft.pitch.imageSrc || "/nft-placeholder.svg",
          attributes: metadata?.attributes || [],
          owner: {
            id: nft.user.id,
            username: nft.user.username,
            name: nft.user.name,
            avatarUrl: nft.user.avatarUrl
          },
          creator: {
            id: nft.pitch.userId,
            username: "founder" // Simplified, ideally would fetch actual creator data
          },
          isOwner: userId === nft.userId,
          isCreator: userId === nft.pitch.userId,
          price: Math.random() * 0.5 // Mock price for display purposes
        };
      });
      
      return res.json(formattedNfts);
    } catch (error) {
      console.error("Error fetching NFTs:", error);
      return res.status(500).json({ message: "Error fetching NFTs" });
    }
  });

  // POST /api/nfts/mint - Mint a new NFT for a pitch
  app.post(`${apiPrefix}/nfts/mint`, requireAuth, async (req, res) => {
    try {
      const mintSchema = z.object({
        pitchId: z.number(),
        title: z.string().min(3, "Title must be at least 3 characters"),
        description: z.string().min(10, "Description must be at least 10 characters"),
        imageUrl: z.string().optional(),
        blockchain: z.string().default("Polygon"),
        attributes: z.array(
          z.object({
            trait_type: z.string(),
            value: z.string()
          })
        ).optional()
      });
      
      const validData = mintSchema.parse(req.body);
      
      // Check if pitch exists and belongs to the user
      const pitch = await db.query.pitches.findFirst({
        where: and(
          eq(schema.pitches.id, validData.pitchId),
          eq(schema.pitches.userId, req.user!.id)
        )
      });
      
      if (!pitch) {
        return res.status(404).json({ message: "Pitch not found or you don't own it" });
      }
      
      // Check if pitch already has an NFT
      const existingNft = await db.query.nfts.findFirst({
        where: eq(schema.nfts.pitchId, validData.pitchId)
      });
      
      if (existingNft) {
        return res.status(400).json({ message: "This pitch already has an NFT minted for it" });
      }
      
      // Generate mock token data
      const tokenId = `STARENA-${Math.floor(Math.random() * 1000000)}`;
      const contractAddress = `0x${Array.from({length: 40}, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      
      // Create NFT metadata
      const nftMetadata = {
        name: validData.title,
        description: validData.description,
        image: validData.imageUrl || pitch.imageSrc || "/nft-placeholder.svg",
        attributes: validData.attributes || [
          {
            trait_type: "Category",
            value: pitch.category
          },
          {
            trait_type: "Created Date",
            value: pitch.createdAt.toISOString()
          }
        ]
      };
      
      // Mint NFT
      const newNft = await db.insert(schema.nfts)
        .values({
          pitchId: validData.pitchId,
          userId: req.user!.id,
          tokenId,
          contractAddress,
          blockchain: validData.blockchain,
          metadata: nftMetadata as any
        })
        .returning();
      
      return res.status(201).json(newNft[0]);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error minting NFT:", error);
      return res.status(500).json({ message: "Error minting NFT" });
    }
  });

  return httpServer;
}
