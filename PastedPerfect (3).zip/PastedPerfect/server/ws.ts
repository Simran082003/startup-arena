import { Server as HttpServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import * as schema from "@shared/schema";
import { LiveRoomState, LiveRoomSocketMessage } from "@shared/types";

// Track connected clients and room states
const clients = new Map<WebSocket, {
  userId?: number;
  username?: string;
  roomId?: number;
}>();

const rooms = new Map<number, LiveRoomState>();

export function setupWebSockets(server: HttpServer) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    // Add client to the map
    clients.set(ws, {});

    // Handle messages
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString()) as LiveRoomSocketMessage;
        
        if (!data.type) {
          return sendError(ws, "Invalid message format");
        }

        // Handle different message types
        switch (data.type) {
          case 'auth':
            handleAuth(ws, data);
            break;
          case 'join_room':
            await handleJoinRoom(ws, data);
            break;
          case 'leave_room':
            await handleLeaveRoom(ws, data);
            break;
          case 'chat_message':
            await handleChatMessage(ws, data);
            break;
          case 'reaction':
            await handleReaction(ws, data);
            break;
          case 'start_stream':
            await handleStartStream(ws, data);
            break;
          case 'end_stream':
            await handleEndStream(ws, data);
            break;
          default:
            sendError(ws, "Unknown message type");
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
        sendError(ws, "Error processing message");
      }
    });

    // Handle disconnections
    ws.on('close', async () => {
      const clientInfo = clients.get(ws);
      if (clientInfo && clientInfo.roomId) {
        await handleLeaveRoom(ws, { 
          type: 'leave_room',
          payload: { roomId: clientInfo.roomId },
          timestamp: new Date().toISOString(),
          senderId: clientInfo.userId || 0,
          senderName: clientInfo.username || 'Unknown'
        });
      }
      clients.delete(ws);
    });
  });

  console.log("WebSocket server initialized");
}

function sendError(ws: WebSocket, message: string) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'error',
      payload: { message },
      timestamp: new Date().toISOString()
    }));
  }
}

// Handle authentication message
function handleAuth(ws: WebSocket, data: LiveRoomSocketMessage) {
  const { userId, username } = data.payload;
  if (!userId || !username) {
    return sendError(ws, "Authentication requires userId and username");
  }

  // Store client info
  clients.set(ws, { ...clients.get(ws), userId, username });
  
  // Send success response
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'auth_success',
      payload: { userId, username },
      timestamp: new Date().toISOString()
    }));
  }
}

// Handle room join
async function handleJoinRoom(ws: WebSocket, data: LiveRoomSocketMessage) {
  const clientInfo = clients.get(ws);
  if (!clientInfo || !clientInfo.userId) {
    return sendError(ws, "You must authenticate first");
  }

  const { roomId } = data.payload;
  if (!roomId) {
    return sendError(ws, "Room ID is required");
  }

  try {
    // Get room from database
    const roomData = await storage.getLiveRoomById(roomId);
    if (!roomData) {
      return sendError(ws, "Room not found");
    }

    // Add user to room participants in DB if not already there
    try {
      await storage.addParticipantToRoom(
        roomId, 
        clientInfo.userId, 
        roomData.userId === clientInfo.userId ? 'host' : 'viewer'
      );
    } catch (err) {
      console.log("User might already be in the room", err);
    }

    // Update client info
    clients.set(ws, { ...clientInfo, roomId });

    // Initialize room state if not exists
    if (!rooms.has(roomId)) {
      const roomParticipants = roomData.participants
        .filter(p => p.leftAt === null)
        .map(p => ({
          userId: p.user.id,
          username: p.user.username,
          avatarUrl: p.user.avatarUrl,
          role: p.role
        }));

      const roomMessages = roomData.messages.map(m => ({
        id: m.id,
        userId: m.user.id,
        username: m.user.username,
        avatarUrl: m.user.avatarUrl,
        content: m.content,
        type: m.type as 'text' | 'reaction' | 'question' | 'system',
        timestamp: m.createdAt.toISOString()
      }));

      rooms.set(roomId, {
        id: roomId,
        title: roomData.title,
        status: roomData.status as 'scheduled' | 'live' | 'ended',
        presenterName: roomData.user.name || roomData.user.username,
        presenterAvatar: roomData.user.avatarUrl,
        presenterId: roomData.user.id,
        pitchId: roomData.pitchId || undefined,
        attendees: roomParticipants,
        messages: roomMessages,
        reactions: {},
        startTime: roomData.startTime?.toISOString(),
        endTime: roomData.endTime?.toISOString()
      });
    } else {
      // Add user to existing room state
      const room = rooms.get(roomId)!;
      if (!room.attendees.some(a => a.userId === clientInfo.userId)) {
        room.attendees.push({
          userId: clientInfo.userId,
          username: clientInfo.username || 'User',
          avatarUrl: undefined,
          role: roomData.userId === clientInfo.userId ? 'host' : 'viewer'
        });
      }
    }

    // Add system message
    const room = rooms.get(roomId)!;
    const joinMessage = {
      id: Date.now().toString(),
      userId: clientInfo.userId,
      username: clientInfo.username || 'User',
      content: `${clientInfo.username} joined the room`,
      type: 'system' as const,
      timestamp: new Date().toISOString()
    };
    room.messages.push(joinMessage);

    // Add system message to DB too
    await storage.addMessageToRoom(
      roomId,
      clientInfo.userId,
      `${clientInfo.username} joined the room`,
      'system'
    );

    // Send room state to the client
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'room_state',
        payload: room,
        timestamp: new Date().toISOString()
      }));
    }

    // Broadcast join to all clients in the room
    broadcastToRoom(roomId, {
      type: 'user_joined',
      payload: {
        user: {
          userId: clientInfo.userId,
          username: clientInfo.username,
          role: roomData.userId === clientInfo.userId ? 'host' : 'viewer'
        },
        message: joinMessage
      },
      timestamp: new Date().toISOString(),
      senderId: clientInfo.userId,
      senderName: clientInfo.username || 'Unknown'
    });

  } catch (error) {
    console.error("Error joining room:", error);
    sendError(ws, "Error joining room");
  }
}

// Handle room leave
async function handleLeaveRoom(ws: WebSocket, data: LiveRoomSocketMessage) {
  const clientInfo = clients.get(ws);
  if (!clientInfo || !clientInfo.userId || !clientInfo.roomId) {
    return;
  }

  const roomId = clientInfo.roomId;

  try {
    // Remove user from room participants in DB
    await storage.removeParticipantFromRoom(roomId, clientInfo.userId);

    // Update client info
    clients.set(ws, { ...clientInfo, roomId: undefined });

    // Update room state
    if (rooms.has(roomId)) {
      const room = rooms.get(roomId)!;
      
      // Remove user from attendees
      room.attendees = room.attendees.filter(a => a.userId !== clientInfo.userId);

      // Add system message
      const leaveMessage = {
        id: Date.now().toString(),
        userId: clientInfo.userId,
        username: clientInfo.username || 'User',
        content: `${clientInfo.username} left the room`,
        type: 'system' as const,
        timestamp: new Date().toISOString()
      };
      room.messages.push(leaveMessage);

      // Add system message to DB too
      await storage.addMessageToRoom(
        roomId,
        clientInfo.userId,
        `${clientInfo.username} left the room`,
        'system'
      );

      // Broadcast leave to all clients in the room
      broadcastToRoom(roomId, {
        type: 'user_left',
        payload: {
          userId: clientInfo.userId,
          message: leaveMessage
        },
        timestamp: new Date().toISOString(),
        senderId: clientInfo.userId,
        senderName: clientInfo.username || 'Unknown'
      });

      // Clean up empty rooms
      if (room.attendees.length === 0) {
        rooms.delete(roomId);
      }
    }
  } catch (error) {
    console.error("Error leaving room:", error);
  }
}

// Handle chat messages
async function handleChatMessage(ws: WebSocket, data: LiveRoomSocketMessage) {
  const clientInfo = clients.get(ws);
  if (!clientInfo || !clientInfo.userId || !clientInfo.roomId) {
    return sendError(ws, "You must join a room first");
  }

  const { content, type = 'text' } = data.payload;
  if (!content) {
    return sendError(ws, "Message content is required");
  }

  try {
    // Add message to database
    const dbMessage = await storage.addMessageToRoom(
      clientInfo.roomId,
      clientInfo.userId,
      content,
      type as 'text' | 'reaction' | 'question' | 'system'
    );

    // Add message to room state
    if (rooms.has(clientInfo.roomId)) {
      const room = rooms.get(clientInfo.roomId)!;
      
      const newMessage = {
        id: dbMessage.id,
        userId: clientInfo.userId,
        username: clientInfo.username || 'User',
        avatarUrl: undefined, // Would come from user data in a real implementation
        content,
        type: type as 'text' | 'reaction' | 'question' | 'system',
        timestamp: dbMessage.createdAt.toISOString()
      };
      
      room.messages.push(newMessage);

      // Broadcast message to all clients in the room
      broadcastToRoom(clientInfo.roomId, {
        type: 'new_message',
        payload: newMessage,
        timestamp: new Date().toISOString(),
        senderId: clientInfo.userId,
        senderName: clientInfo.username || 'Unknown'
      });
    }
  } catch (error) {
    console.error("Error sending chat message:", error);
    sendError(ws, "Error sending chat message");
  }
}

// Handle reactions
async function handleReaction(ws: WebSocket, data: LiveRoomSocketMessage) {
  const clientInfo = clients.get(ws);
  if (!clientInfo || !clientInfo.userId || !clientInfo.roomId) {
    return sendError(ws, "You must join a room first");
  }

  const { reactionType } = data.payload;
  if (!reactionType) {
    return sendError(ws, "Reaction type is required");
  }

  try {
    // Add reaction to room state
    if (rooms.has(clientInfo.roomId)) {
      const room = rooms.get(clientInfo.roomId)!;
      
      // Initialize reaction if doesn't exist
      if (!room.reactions[reactionType]) {
        room.reactions[reactionType] = {
          type: reactionType,
          count: 0,
          userIds: []
        };
      }
      
      // Add user to the reaction if not already there
      if (!room.reactions[reactionType].userIds.includes(clientInfo.userId)) {
        room.reactions[reactionType].count++;
        room.reactions[reactionType].userIds.push(clientInfo.userId);
      }

      // Also add as a message for history
      const reactionMessage = {
        id: Date.now().toString(),
        userId: clientInfo.userId,
        username: clientInfo.username || 'User',
        content: reactionType,
        type: 'reaction' as const,
        timestamp: new Date().toISOString()
      };
      room.messages.push(reactionMessage);

      // Add message to database
      await storage.addMessageToRoom(
        clientInfo.roomId,
        clientInfo.userId,
        reactionType,
        'reaction'
      );

      // Broadcast reaction to all clients in the room
      broadcastToRoom(clientInfo.roomId, {
        type: 'new_reaction',
        payload: {
          userId: clientInfo.userId,
          username: clientInfo.username,
          reactionType,
          count: room.reactions[reactionType].count
        },
        timestamp: new Date().toISOString(),
        senderId: clientInfo.userId,
        senderName: clientInfo.username || 'Unknown'
      });
    }
  } catch (error) {
    console.error("Error sending reaction:", error);
    sendError(ws, "Error sending reaction");
  }
}

// Handle stream start
async function handleStartStream(ws: WebSocket, data: LiveRoomSocketMessage) {
  const clientInfo = clients.get(ws);
  if (!clientInfo || !clientInfo.userId || !clientInfo.roomId) {
    return sendError(ws, "You must join a room first");
  }

  try {
    // Get room from database
    const roomData = await storage.getLiveRoomById(clientInfo.roomId);
    if (!roomData) {
      return sendError(ws, "Room not found");
    }

    // Check if user is the host
    if (roomData.userId !== clientInfo.userId) {
      return sendError(ws, "Only the host can start the stream");
    }

    // Update room status in database
    await storage.updateLiveRoomStatus(clientInfo.roomId, 'live');

    // Update room state
    if (rooms.has(clientInfo.roomId)) {
      const room = rooms.get(clientInfo.roomId)!;
      room.status = 'live';
      room.startTime = new Date().toISOString();

      // Add system message
      const startMessage = {
        id: Date.now().toString(),
        userId: clientInfo.userId,
        username: clientInfo.username || 'Host',
        content: 'The stream has started',
        type: 'system' as const,
        timestamp: new Date().toISOString()
      };
      room.messages.push(startMessage);

      // Add system message to DB too
      await storage.addMessageToRoom(
        clientInfo.roomId,
        clientInfo.userId,
        'The stream has started',
        'system'
      );

      // Broadcast stream start to all clients in the room
      broadcastToRoom(clientInfo.roomId, {
        type: 'stream_started',
        payload: {
          roomId: clientInfo.roomId,
          startTime: room.startTime,
          message: startMessage
        },
        timestamp: new Date().toISOString(),
        senderId: clientInfo.userId,
        senderName: clientInfo.username || 'Host'
      });
    }
  } catch (error) {
    console.error("Error starting stream:", error);
    sendError(ws, "Error starting stream");
  }
}

// Handle stream end
async function handleEndStream(ws: WebSocket, data: LiveRoomSocketMessage) {
  const clientInfo = clients.get(ws);
  if (!clientInfo || !clientInfo.userId || !clientInfo.roomId) {
    return sendError(ws, "You must join a room first");
  }

  try {
    // Get room from database
    const roomData = await storage.getLiveRoomById(clientInfo.roomId);
    if (!roomData) {
      return sendError(ws, "Room not found");
    }

    // Check if user is the host
    if (roomData.userId !== clientInfo.userId) {
      return sendError(ws, "Only the host can end the stream");
    }

    // Update room status in database
    await storage.updateLiveRoomStatus(clientInfo.roomId, 'ended');

    // Update room state
    if (rooms.has(clientInfo.roomId)) {
      const room = rooms.get(clientInfo.roomId)!;
      room.status = 'ended';
      room.endTime = new Date().toISOString();

      // Add system message
      const endMessage = {
        id: Date.now().toString(),
        userId: clientInfo.userId,
        username: clientInfo.username || 'Host',
        content: 'The stream has ended',
        type: 'system' as const,
        timestamp: new Date().toISOString()
      };
      room.messages.push(endMessage);

      // Add system message to DB too
      await storage.addMessageToRoom(
        clientInfo.roomId,
        clientInfo.userId,
        'The stream has ended',
        'system'
      );

      // Broadcast stream end to all clients in the room
      broadcastToRoom(clientInfo.roomId, {
        type: 'stream_ended',
        payload: {
          roomId: clientInfo.roomId,
          endTime: room.endTime,
          message: endMessage
        },
        timestamp: new Date().toISOString(),
        senderId: clientInfo.userId,
        senderName: clientInfo.username || 'Host'
      });

      // Clean up room state after some time
      setTimeout(() => {
        if (rooms.has(clientInfo.roomId)) {
          rooms.delete(clientInfo.roomId);
        }
      }, 60 * 60 * 1000); // 1 hour
    }
  } catch (error) {
    console.error("Error ending stream:", error);
    sendError(ws, "Error ending stream");
  }
}

// Utility to broadcast to all clients in a room
function broadcastToRoom(roomId: number, message: LiveRoomSocketMessage) {
  clients.forEach((clientInfo, client) => {
    if (clientInfo.roomId === roomId && client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  });
}
