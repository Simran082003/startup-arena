#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('📦 Setting up your local environment for Startup Arena...');

// Check if .env file exists
const envPath = path.join(process.cwd(), '.env');
if (!fs.existsSync(envPath)) {
  console.log('🔧 Creating .env file from template...');
  
  // Copy .env.example to .env
  const exampleEnvPath = path.join(process.cwd(), '.env.example');
  if (fs.existsSync(exampleEnvPath)) {
    fs.copyFileSync(exampleEnvPath, envPath);
    console.log('✅ Created .env file! Please edit it with your database credentials.');
  } else {
    console.log('❌ .env.example file not found. Creating .env file with basic structure...');
    const basicEnvContent = `# PostgreSQL Connection String
DATABASE_URL=postgresql://postgres:password@localhost:5432/startup_arena

# Session Secret
SESSION_SECRET=your-secret-session-key-change-this

# Node Environment
NODE_ENV=development

# Port (optional, defaults to 5000)
PORT=5000

# Local development flag
LOCAL_DEV=true`;
    
    fs.writeFileSync(envPath, basicEnvContent);
    console.log('✅ Created basic .env file! Please edit it with your database credentials.');
  }
} else {
  console.log('✓ .env file already exists.');
}

console.log('\n🚀 Local development setup:');
console.log('1. Edit the .env file with your database credentials');
console.log('2. Run your database migrations:');
console.log('   $ npm run db:push');
console.log('3. Seed your database:');
console.log('   $ npm run db:seed');
console.log('   To reset the database with fresh data, use:');
console.log('   $ FORCE_SEED=true npm run db:seed');
console.log('4. Start the dev server:');
console.log('   $ npm run dev');
console.log('\n✨ Happy coding! ✨');