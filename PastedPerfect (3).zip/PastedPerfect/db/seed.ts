import { db } from "./index";
import * as schema from "@shared/schema";
import { hash } from "bcrypt";

async function seed() {
  try {
    console.log("Starting database seed...");
    
    // Check if FORCE_SEED environment variable is set
    const forceSeed = process.env.FORCE_SEED === 'true';
    
    // Check if database has any users
    const existingUsers = await db.query.users.findMany({ limit: 1 });
    
    if (existingUsers.length > 0 && !forceSeed) {
      console.log("Database already has users, skipping seed");
      console.log("To force re-seeding, run with FORCE_SEED=true");
      return;
    }
    
    // If we're force seeding, clear existing data
    if (forceSeed && existingUsers.length > 0) {
      console.log("Force seeding enabled, clearing existing data...");
      // Delete in reverse order to respect foreign key constraints
      await db.delete(schema.nfts);
      await db.delete(schema.challengeParticipants);
      await db.delete(schema.challenges);
      await db.delete(schema.liveRoomMessages);
      await db.delete(schema.liveRoomParticipants);
      await db.delete(schema.liveRooms);
      await db.delete(schema.upvotes);
      await db.delete(schema.comments);
      await db.delete(schema.pitches);
      await db.delete(schema.connections);
      await db.delete(schema.users);
      console.log("Database cleared, proceeding with seed...");
    }
    
    // Create test users
    const hashedPassword = await hash("password123", 10);
    
    console.log("Creating users...");
    const users = await db.insert(schema.users)
      .values([
        {
          username: "founder1",
          password: hashedPassword,
          name: "Alex Chen",
          email: "alex@example.com",
          role: "founder",
          title: "Founder & CEO",
          bio: "Serial entrepreneur focused on climate tech solutions",
          avatarUrl: "/avatars/founder-1.svg"
        },
        {
          username: "founder2",
          password: hashedPassword,
          name: "Sarah Johnson",
          email: "sarah@example.com",
          role: "founder",
          title: "Co-founder",
          bio: "AI researcher turned entrepreneur",
          avatarUrl: "/avatars/founder-2.svg"
        },
        {
          username: "founder3",
          password: hashedPassword,
          name: "David Kim",
          email: "david@example.com",
          role: "founder",
          title: "CTO",
          bio: "Full-stack developer with 10+ years experience",
          avatarUrl: "/avatars/founder-3.svg"
        },
        {
          username: "investor1",
          password: hashedPassword,
          name: "Michael Chang",
          email: "michael@example.com",
          role: "investor",
          title: "Seed Stage",
          company: "Sequoia Capital",
          bio: "Partner at Sequoia Capital. Focuses on B2B SaaS, FinTech and AI startups.",
          avatarUrl: "/avatars/investor-1.svg"
        },
        {
          username: "investor2",
          password: hashedPassword,
          name: "Sophia Rodriguez",
          email: "sophia@example.com",
          role: "investor",
          title: "Series A",
          company: "Accel Partners",
          bio: "Managing Partner at Accel. Invested in 12 unicorn startups in health and climate.",
          avatarUrl: "/avatars/investor-2.svg"
        },
        {
          username: "mentor1",
          password: hashedPassword,
          name: "Jennifer Lee",
          email: "jennifer@example.com",
          role: "mentor",
          title: "Mentor • Product Design",
          bio: "Former Head of Design at Dropbox. Helped 25+ startups refine their product UX.",
          avatarUrl: "/avatars/mentor-1.svg"
        },
        {
          username: "mentor2",
          password: hashedPassword,
          name: "Robert Taylor",
          email: "robert@example.com",
          role: "mentor",
          title: "Mentor • Growth",
          bio: "Former CMO at Shopify. Expert in acquisition strategies for early-stage startups.",
          avatarUrl: "/avatars/mentor-2.svg"
        }
      ])
      .returning();
    
    console.log(`Created ${users.length} users`);
    
    // Create pitches
    console.log("Creating pitches...");
    const pitches = await db.insert(schema.pitches)
      .values([
        {
          userId: users[0].id, // Alex Chen
          title: "EcoCharge: Sustainable Phone Chargers",
          description: "Our biodegradable phone chargers reduce e-waste while maintaining high performance and durability.",
          category: "Climate Tech",
          status: "active",
          imageSrc: "/pitch-thumbnail.svg",
          tags: ["CleanTech", "Sustainable", "Hardware", "Consumer"],
          views: 345,
          upvotes: 132
        },
        {
          userId: users[1].id, // Sarah Johnson
          title: "TutorAI: Personalized Learning Assistant",
          description: "AI-powered tutoring platform that adapts to each student's learning style and pace.",
          category: "EdTech",
          status: "active",
          imageSrc: "/pitch-thumbnail.svg",
          tags: ["AI", "Education", "Machine Learning", "SaaS"],
          views: 289,
          upvotes: 98
        },
        {
          userId: users[2].id, // David Kim
          title: "HealthTrack: Smart Medication Manager",
          description: "IoT-enabled pill dispenser with companion app for medication management and health tracking.",
          category: "HealthTech",
          status: "active",
          imageSrc: "/pitch-thumbnail.svg",
          tags: ["IoT", "Healthcare", "Mobile", "Hardware"],
          views: 187,
          upvotes: 87
        },
        {
          userId: users[0].id, // Alex Chen
          title: "Task Flow: Project Management Simplified",
          description: "Task Flow revolutionizes project management by automating workflows and integrating with your favorite tools.",
          category: "SaaS",
          status: "active",
          imageSrc: "/pitch-thumbnail.svg",
          tags: ["Productivity", "B2B", "Collaboration"],
          views: 124,
          upvotes: 23
        },
        {
          userId: users[2].id, // David Kim
          title: "FinBlocks: Crypto For Everyone",
          description: "Democratizing crypto by making blockchain technologies accessible to all.",
          category: "FinTech",
          status: "active",
          imageSrc: "/pitch-thumbnail.svg",
          tags: ["Blockchain", "Cryptocurrency", "Finance", "Accessibility"],
          views: 423,
          upvotes: 156
        }
      ])
      .returning();
    
    console.log(`Created ${pitches.length} pitches`);
    
    // Create comments
    console.log("Creating comments...");
    const comments = await db.insert(schema.comments)
      .values([
        {
          pitchId: pitches[0].id,
          userId: users[3].id, // Michael (investor)
          content: "Love the sustainability angle. How are you addressing the challenge of biodegradable materials having shorter lifespans?"
        },
        {
          pitchId: pitches[0].id,
          userId: users[5].id, // Jennifer (mentor)
          content: "The product design looks clean! Have you considered different aesthetic options to appeal to various market segments?"
        },
        {
          pitchId: pitches[1].id,
          userId: users[6].id, // Robert (mentor)
          content: "Great concept! What's your go-to-market strategy for reaching educational institutions?"
        },
        {
          pitchId: pitches[2].id,
          userId: users[4].id, // Sophia (investor)
          content: "This solves a real problem in medication adherence. What's your business model and pricing strategy?"
        },
        {
          pitchId: pitches[3].id,
          userId: users[1].id, // Sarah (founder)
          content: "I've been using task management tools for years and they all have the same problems. How does Task Flow solve the prioritization issue?"
        }
      ])
      .returning();
    
    console.log(`Created ${comments.length} comments`);
    
    // Create upvotes
    console.log("Creating upvotes...");
    await db.insert(schema.upvotes)
      .values([
        { pitchId: pitches[0].id, userId: users[1].id },
        { pitchId: pitches[0].id, userId: users[3].id },
        { pitchId: pitches[0].id, userId: users[5].id },
        { pitchId: pitches[1].id, userId: users[0].id },
        { pitchId: pitches[1].id, userId: users[2].id },
        { pitchId: pitches[1].id, userId: users[4].id },
        { pitchId: pitches[2].id, userId: users[1].id },
        { pitchId: pitches[2].id, userId: users[3].id },
        { pitchId: pitches[3].id, userId: users[2].id },
        { pitchId: pitches[4].id, userId: users[0].id },
        { pitchId: pitches[4].id, userId: users[3].id },
        { pitchId: pitches[4].id, userId: users[5].id }
      ]);
    
    // Create live rooms
    console.log("Creating live rooms...");
    const liveRooms = await db.insert(schema.liveRooms)
      .values([
        {
          userId: users[2].id, // David Kim
          pitchId: pitches[4].id, // FinBlocks
          title: "FinBlocks: Crypto For Everyone",
          description: "Join us for a live demo of the FinBlocks platform and Q&A session",
          status: "live",
          thumbnailSrc: "/live-pitch.svg",
          startTime: new Date()
        },
        {
          userId: users[0].id, // Alex Chen
          pitchId: pitches[0].id, // EcoCharge
          title: "EcoCharge Demo & Investor Pitch",
          description: "Live demonstration of our sustainable charger prototypes",
          status: "live",
          thumbnailSrc: "/live-pitch.svg",
          startTime: new Date()
        },
        {
          userId: users[1].id, // Sarah Johnson
          pitchId: pitches[1].id, // TutorAI
          title: "The Future of AI in Education",
          description: "Join Sarah for a discussion on how AI is transforming education",
          status: "scheduled",
          thumbnailSrc: "/live-pitch.svg",
          startTime: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) // 3 days from now
        }
      ])
      .returning();
    
    console.log(`Created ${liveRooms.length} live rooms`);
    
    // Create challenges
    console.log("Creating challenges...");
    const challenges = await db.insert(schema.challenges)
      .values([
        {
          title: "Climate Tech Innovation",
          description: "Seeking breakthrough solutions for climate change mitigation and adaptation",
          prize: "$10,000 equity-free funding + mentorship",
          startDate: new Date(),
          endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
          status: "active"
        },
        {
          title: "AI for Good",
          description: "Using artificial intelligence to solve social and environmental challenges",
          prize: "Demo day with top VCs + $5,000 AWS credits",
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // Started 10 days ago
          endDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000), // 20 days from now
          status: "active"
        },
        {
          title: "FinTech Revolution",
          description: "Reimagining financial services for the digital age",
          prize: "$15,000 investment opportunity + industry mentorship",
          startDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // 15 days from now
          endDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days from now
          status: "upcoming"
        }
      ])
      .returning();
    
    console.log(`Created ${challenges.length} challenges`);
    
    // Add participants to challenges
    console.log("Adding challenge participants...");
    await db.insert(schema.challengeParticipants)
      .values([
        {
          challengeId: challenges[0].id,
          pitchId: pitches[0].id,
          userId: users[0].id,
          score: 87,
          rank: 1
        },
        {
          challengeId: challenges[1].id,
          pitchId: pitches[1].id,
          userId: users[1].id,
          score: 92,
          rank: 1
        }
      ]);
    
    // Create NFTs
    console.log("Creating NFTs...");
    await db.insert(schema.nfts)
      .values([
        {
          pitchId: pitches[0].id,
          userId: users[0].id,
          tokenId: "STARENA-123456",
          contractAddress: "0x1234567890abcdef1234567890abcdef12345678",
          blockchain: "Ethereum",
          metadata: {
            name: "EcoCharge: Sustainable Phone Chargers",
            description: "Our biodegradable phone chargers reduce e-waste while maintaining high performance and durability.",
            image: "/nft-placeholder.svg",
            attributes: [
              { trait_type: "Category", value: "Climate Tech" },
              { trait_type: "Created Date", value: pitches[0].createdAt }
            ]
          }
        }
      ]);
    
    console.log("Seed completed successfully!");
  } catch (error) {
    console.error("Error during database seed:", error);
  }
}

seed();
